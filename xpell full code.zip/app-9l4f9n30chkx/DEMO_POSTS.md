# Demo Posts for Testing Linked-Optima

## High-Scoring Posts (80%+)

### 1. Education Guide (Expected: 90%+)
```
How to 10x your LinkedIn reach:

I studied the top 100 creators. Here's what actually works:

1. Post 1x/day (consistency beats perfection)
2. Hook < 8 words with numbers or POV
3. Alternate short/long sentences (visual rhythm)
4. Add media (images > text-only)
5. Strategic comments on niche leaders

The algorithm rewards depth + clarity + value frontloading.

Start today.
```

### 2. Case Study (Expected: 92%+)
```
Dr. Caroline went from 20k to 200k followers.

Here's exactly what we did:

Month 1: Fixed her profile formula (I help [ICP] achieve [result])
Month 2: 5 Post Funnel (Awareness → Personal → Education → IP → Case Studies)
Month 3: Thought leader ads on top posts ($50/day)
Month 4: IRL content from conferences (AI-proof)

Revenue increased 10x.

Want the same playbook? DM me "GROW"
```

### 3. IP Framework (Expected: 88%+)
```
Our SERVE framework for social selling:

Most people spam. We build relationships.

S - Show up consistently (daily posts)
E - Educate your ICP (solve real problems)
R - Relate through stories (be human)
V - Value > transactions (give first)
E - Engage strategically (20 connects/day)

Result? 7-figure pipeline from LinkedIn alone.

Steal this framework.
```

## Medium-Scoring Posts (60-79%)

### 4. Personal Story (Expected: 75%+)
```
Why I started this company:

2019. Burned out. 80-hour weeks for someone else's dream.

I decided to build something that mattered.

Today we help 500+ founders scale without losing their soul.

Your origin story is your unfair advantage. Share it.
```

### 5. Awareness Post (Expected: 70%+)
```
I failed for 3 years straight.

Then I found the one thing that actually works for SaaS growth.

No ads. No cold outreach. Just pure value loop.

The secret? Show up consistently. Educate your ICP. Relate through stories.

Value > transactions. Always.
```

## Low-Scoring Posts (Below 60%)

### 6. Poor Hook Example (Expected: 40-50%)
```
I wanted to share some thoughts about LinkedIn marketing strategies that have been working really well for me lately.

Here are some tips:
- Be consistent
- Engage with others
- Post good content

Hope this helps!
```

### 7. Spam Example (Expected: 30-40%)
```
🚨 LIMITED TIME OFFER 🚨

Click here NOW to get my FREE course on LinkedIn growth!

Act fast before this deal expires!

Buy now and transform your business guaranteed!

Link in comments 👇
```

## Testing Checklist

Use these posts to verify:
- ✅ Hook length detection (≤8 words)
- ✅ Numbers in hook bonus
- ✅ POV/Personal angle detection
- ✅ Post type classification (5 Post Funnel)
- ✅ SERVE framework element detection
- ✅ Visual rhythm analysis
- ✅ CTA presence
- ✅ Spam pattern detection
- ✅ Case study metrics recognition
- ✅ IP framework identification

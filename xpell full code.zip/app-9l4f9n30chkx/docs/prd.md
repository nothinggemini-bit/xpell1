# It's Better Requirements Document

## 1. Application Overview

### 1.1 Application Name
It's Better

### 1.2 Application Description
A Glass-Box AI dashboard SaaS tool that predicts LinkedIn post virality scores using a single-layer mathematical model based on 2026 algorithm patterns including Hook length, Rhythm, Keywords, and the 360 Brew framework. The platform integrates profile optimization, 5-post funnel strategy, SERVE selling methodology, and IRL-to-URL content workflows. Features user authentication with Google Sign-In integration, post history tracking, image analysis, detailed performance breakdowns, A/B testing arena, visual text heatmap, niche-specific analysis, follower-based scoring adjustments, gamification elements, AI-powered interactive search for post-analysis Q&A, and AI-generated content detection.

### 1.3 Training Data Foundation
The AI model has been trained on thousands of LinkedIn posts from leading content creators across multiple niches, including but not limited to:

**B2B Marketing & Strategy**: Ann Handley, Neil Patel, Matt Barker, Sophie Miller, Aakash Gupta, Shama Hyder, Elena Verna, Jason Miller, Caroline Farley, Lee Odden, Rachel Miller, Giovanna Castro, Cassandra Jowett, Rachel Helfman, Danielle Farage

**Entrepreneurship & Growth**: Gary Vaynerchuk, Ankur Warikoo, Raj Shamani, Bill Gates, Richard Branson, Alex Hormozi, Justin Welsh, Codie Sanchez, Jackie Hermes, Pradnyesh Gumaste, Savannah Peterson

**Career & Personal Branding**: Niharikaa Kaur Sodhi, AJ Eckstein, Austin Belcak, Madeline Mann, Andrew Seaman, Sho Dewan, Wonsulting (Jonathan Javier), Valerie Le, Liz Ryan, Hanna Goefft, Lissa Appiah

**Leadership & Innovation**: Simon Sinek, Dora Vanourek, George Stern, Lara Acosta, Misha Collins, Adam Grant, Satya Nadella, Arianna Huffington, Brené Brown, Jeff Weiner, Carol Stewart

**Design & Creative Strategy**: Zander Whitehurst, James Martin, Debbie Millman, Tim Brown, Chris Do, Adham Dannaway, Luke Wroblewski, Abi Connick, Matt Przegietka, Sarah Doody, Aneta Kmiecik, Tibi David, Lena Kul, Christopher Nguyen, Samaneh Dehghanpour, Davar Azarbeygui, James Barnard, Jan Mráz, Tom Scott, Adrian Kulesho, Vijay Verma, Vitaly Friedman, Tobias van Schneider, Simonas Maciulis, Trevor Nielsen, Pablo Stanley, Jack Chitty, Filippos Protogeridis, Edward Chechique, Zhenya Rynzhuk, Mitchell Clements, Saptarshi Prakash, Emilie Mazurek, Julie Zhuo, Jakob Nielsen, Stephanie Walter, Juan J. Ramirez, Harish Sivaramakrishnan, John Maeda, Nick Babich, Jeremy Mura, Michal Malewicz, Ioana Teleanu, Steve Schoger, Femke van Schoonhoven, India Simpson, Samir Hossain

**Logistics & Supply Chain**: Sheri Hinish, Lora Cecere, Dhruvil Sanghvi, Radu Palamariu, Kelli Saunders, Richard Wilding, Yossi Sheffi, Brenda Lopes

**Cybersecurity & Data Privacy**: Kevin Mitnick, Shira Rubinoff, John Hammond, Marcus Hutchins, Clint Gibler, Katie Nickels, Troy Hunt

**Human Resources & Future of Work**: Josh Bersin, Anshuman Das, Shannon Mayer, Sofia Theodorou

**Artificial Intelligence & Data Engineering**: Andreas Kretz, Cassie Kozyrkov, Andrew Ng, Allie K. Miller, Andrej Karpathy, Bernard Marr, Fei-Fei Li, Megan Lieu

**Sales & Revenue Operations**: Cynthia Barnes, Jed Mahrle, Morgan Ingram, Daniel Disney, Becc Holland, Will Aitken, Belal Batrawy, Thibaut Souyris

**Customer Success**: Lincoln Murphy, Kristi Faltorusso

**Legal, Compliance & Ethics**: Tom Fox, Cecilia Bondestam, Olga V. Mack

**Mental Health & Workplace Wellness**: Liz Fosslien, Amy Morin, Pooja Lakshmin MD, Dr. Julie Smith, Daniel Goleman, Gretchen Rubin, Dr. Amantha Imber, Kelly McGonigal, Meris Gebhardt

**Operations & Business Efficiency**: Justin Wright, Mariana Castro, Nate Kondamuri

**Fintech & Cryptoeconomics**: Lex Sokolin, Theodora Lau, Spiros Margaris

**Real Estate & Urban Planning**: Dror Poleg, Beth Azor, Moses Kagan

The analysis encompasses comprehensive metrics including statistics, content quality, niche alignment, views, impressions, comments, likes, support interactions, and reposts. Over 34,000+ viral posts have been analyzed to identify patterns that predict 89% success rate based on first-hour engagement.

### 1.4 Niche-Specific Creator Mapping
After user completes login, display a dedicated column showing which creators from the training dataset are relevant to the user's selected niche/industry. This mapping helps users understand which thought leaders' content patterns are being used to analyze their posts.

Mapping structure:
- **B2B Marketing & Strategy**: Ann Handley, Neil Patel, Matt Barker, Sophie Miller, Aakash Gupta, Shama Hyder, Elena Verna, Jason Miller, Caroline Farley, Lee Odden, Rachel Miller, Giovanna Castro, Cassandra Jowett, Rachel Helfman, Danielle Farage
- **Entrepreneurship & Growth**: Gary Vaynerchuk, Ankur Warikoo, Raj Shamani, Bill Gates, Richard Branson, Alex Hormozi, Justin Welsh, Codie Sanchez, Jackie Hermes, Pradnyesh Gumaste, Savannah Peterson
- **Career & Personal Branding**: Niharikaa Kaur Sodhi, AJ Eckstein, Austin Belcak, Madeline Mann, Andrew Seaman, Sho Dewan, Wonsulting (Jonathan Javier), Valerie Le, Liz Ryan, Hanna Goefft, Lissa Appiah
- **Leadership & Innovation**: Simon Sinek, Dora Vanourek, George Stern, Lara Acosta, Misha Collins, Adam Grant, Satya Nadella, Arianna Huffington, Brené Brown, Jeff Weiner, Carol Stewart
- **Design & Creative Strategy**: Zander Whitehurst, James Martin, Debbie Millman, Tim Brown, Chris Do, Adham Dannaway, Luke Wroblewski, Abi Connick, Matt Przegietka, Sarah Doody, Aneta Kmiecik, Tibi David, Lena Kul, Christopher Nguyen, Samaneh Dehghanpour, Davar Azarbeygui, James Barnard, Jan Mráz, Tom Scott, Adrian Kulesho, Vijay Verma, Vitaly Friedman, Tobias van Schneider, Simonas Maciulis, Trevor Nielsen, Pablo Stanley, Jack Chitty, Filippos Protogeridis, Edward Chechique, Zhenya Rynzhuk, Mitchell Clements, Saptarshi Prakash, Emilie Mazurek, Julie Zhuo, Jakob Nielsen, Stephanie Walter, Juan J. Ramirez, Harish Sivaramakrishnan, John Maeda, Nick Babich, Jeremy Mura, Michal Malewicz, Ioana Teleanu, Steve Schoger, Femke van Schoonhoven, India Simpson, Samir Hossain
- **Logistics & Supply Chain**: Sheri Hinish, Lora Cecere, Dhruvil Sanghvi, Radu Palamariu, Kelli Saunders, Richard Wilding, Yossi Sheffi, Brenda Lopes
- **Cybersecurity & Data Privacy**: Kevin Mitnick, Shira Rubinoff, John Hammond, Marcus Hutchins, Clint Gibler, Katie Nickels, Troy Hunt
- **Human Resources & Future of Work**: Josh Bersin, Anshuman Das, Shannon Mayer, Sofia Theodorou
- **Artificial Intelligence & Data Engineering**: Andreas Kretz, Cassie Kozyrkov, Andrew Ng, Allie K. Miller, Andrej Karpathy, Bernard Marr, Fei-Fei Li, Megan Lieu
- **Sales & Revenue Operations**: Cynthia Barnes, Jed Mahrle, Morgan Ingram, Daniel Disney, Becc Holland, Will Aitken, Belal Batrawy, Thibaut Souyris
- **Customer Success**: Lincoln Murphy, Kristi Faltorusso
- **Legal, Compliance & Ethics**: Tom Fox, Cecilia Bondestam, Olga V. Mack
- **Mental Health & Workplace Wellness**: Liz Fosslien, Amy Morin, Pooja Lakshmin MD, Dr. Julie Smith, Daniel Goleman, Gretchen Rubin, Dr. Amantha Imber, Kelly McGonigal, Meris Gebhardt
- **Operations & Business Efficiency**: Justin Wright, Mariana Castro, Nate Kondamuri
- **Fintech & Cryptoeconomics**: Lex Sokolin, Theodora Lau, Spiros Margaris
- **Real Estate & Urban Planning**: Dror Poleg, Beth Azor, Moses Kagan

## 2. Visual Design Requirements

### 2.1 Theme
Cyber-Professional aesthetic with immersive 3D visual effects

### 2.2 Color Scheme
- Background: Deep Charcoal (#0F1115) with subtle mesh gradient
- Accents: Electric Blue (#2563EB) for data points, Signal Green (#10B981) for Viral scores, Warning Orange for Bad Hooks
- Heatmap Colors: Red (#EF4444/20) for long sentences, Green (#10B981/20) for punchy sentences, Yellow (#F59E0B/20) for weak words

### 2.3 Layout
- Landing page: Full-screen 3D hero section with application name only
- Scroll-triggered content reveal with ScrollFloat animation effect
- Bento Grid layout for dashboard
- Glassmorphism effect cards (blur-md, white/5 opacity, 1px border white/10)
- Split-screen view for A/B testing arena

### 2.4 Typography
- Inter font for text
- JetBrains Mono font for data/numbers

### 2.5 Motion
- LiquidEther: WebGL-based fluid simulation effect applied as background layer at outer page level across entire application
- ScrollFloat: Scroll-triggered text reveal animation with character-by-character entrance, applied globally wherever cursor moves
- Framer-motion for smooth transitions when score updates
- Scanning animation for A/B test comparison
- Glow effect on Analyze button when user types
- **Analysis Countdown Animation**: 30-second reverse countdown (30→0) with calendar page-flip effect (pages flipping from bottom to top or top to bottom), displayed during analysis process; countdown automatically stops and disappears once viral score calculation completes, even if 30 seconds have not elapsed

### 2.6 Interactive Effects
- LiquidEther: WebGL-based fluid simulation effect with dynamic color splashes following mouse movement, applied as full-page background layer at outer page level across entire application
- TargetCursor: Custom animated cursor with rotating corner brackets that track and frame interactive elements on hover
- SplitText Animation: Text reveal animation with staggered character/word entrance effects triggered on scroll
- ScrollFloat Animation: Character-by-character floating entrance effect triggered by scroll position and cursor movement, applied globally across all text elements wherever cursor moves

### 2.7 Training Data Marquee
- Horizontal scrolling marquee line displayed prominently on dashboard
- Text content: This platform is trained with 1000+ posts and has analyzed statistics + content quality + niche alignment + views + impressions + comments + likes + support interactions + reposts
- Styling: Continuous auto-scroll animation, glassmorphism background, subtle glow effect
- Position: Below header or above main dashboard content area
- Animation: Smooth infinite loop with no gaps

### 2.8 Analysis Countdown Timer
- **Trigger**: Countdown starts immediately when user clicks Analyze Reach button
- **Duration**: 30 seconds reverse countdown (30→29→28...→1→0)
- **Visual Effect**: Calendar page-flip animation with each number change
  - Animation style: Pages flipping from bottom to top or top to bottom (like tearing calendar pages)
  - Smooth 3D rotation effect for each page flip
  - Depth and shadow effects to enhance realism
- **Display Position**: Prominently displayed in center or near score gauge area during analysis
- **Behavior**: 
  - Countdown runs in parallel with AI analysis process
  - Automatically stops and disappears as soon as viral score calculation completes
  - If analysis finishes before 30 seconds, countdown immediately stops at current number and fades out
  - If analysis takes longer than 30 seconds, countdown completes at 0 and disappears, while analysis continues
- **Styling**: Large, bold numbers with glassmorphism background, consistent with cyber-professional theme

### 2.9 AI Insights Visual Enhancement
- **Background Effect**: Subtle gradient glow background with animated light particles
- **Color Scheme**: Electric Blue (#2563EB) to Signal Green (#10B981) gradient overlay
- **Animation**: Soft pulsing glow effect synchronized with content reveal
- **Styling Details**:
  - Glassmorphism card with enhanced backdrop blur (blur-lg)
  - Gradient border with animated shimmer effect
  - Inner glow shadow for depth perception
  - Floating light particles in background using CSS animations or WebGL
- **Implementation**: Apply to all AI Insights sections including Hook-Refiner, 5 Flaw Audit, Hashtag Suggestions, and AI-Powered Improvement Insights

## 3. Core Features

### 3.1 Landing Page Experience
- First viewport: Full-screen display showing only It's Better application name with 3D visual depth effect
- LiquidEther effect active as background layer at outer page level across entire landing page
- Scroll interaction: When user scrolls down, ScrollFloat animation triggers character-by-character text reveal
- Second viewport: Content from uploaded image ({F40BBFFA-A301-46BC-B01B-7246992E4F0E}.png) appears after scroll animation completes
- Smooth scroll transitions between sections
- ScrollFloat effect follows cursor movement globally across all text elements

### 3.2 User Authentication System
- Sign up page collecting:
  - Name (required, minimum 2 characters)
  - Email (required, valid email format validation)
  - Password (required, minimum 8 characters, must contain at least one uppercase letter, one lowercase letter, one number)
  - LinkedIn follower count (required, must be a positive number)
  - Current role/job title
  - Industry/niche (required for niche-specific creator mapping)
  - Other personal information
- **Google Sign-Up/Login Integration**:
  - OSS Google login button displayed on both Sign Up and Login pages
  - One-click authentication via Google account
  - Automatic profile data population from Google account (name, email)
  - User still required to provide LinkedIn follower count and industry/niche after Google authentication
  - Session management for Google-authenticated users
- Login page for returning users
- User session management
- Input validation requirements:
  - Email format check: Must match standard email pattern (example@domain.com)
  - Password strength check: Minimum 8 characters with uppercase, lowercase, and number requirements
  - Name length check: Minimum 2 characters required
  - LinkedIn follower count check: Must be a non-negative integer
  - Real-time validation feedback with error messages displayed below input fields
- Post-login display: Show niche-specific creator column based on user's selected industry/niche

### 3.3 Viral Score Calculation Model (Enhanced Strictness with Follower-Based Adjustments)
- Local TypeScript/Python function: calculateViralScore(text, images, niche, followerCount)
- Single-layer mathematical model using Linear Logic with AI-powered deep analysis
- **Follower-Based Score Adjustment**:
  - System automatically fetches LinkedIn follower count from user profile
  - Score adjustments applied based on follower tiers:
    + Less than 500 followers: -4% score adjustment
    + 2,000 to 12,000 followers: +4% score adjustment
    + 12,000 to 40,000 followers: +7% score adjustment
    + 40,000 to 100,000 followers: +10% score adjustment
    + 100,000+ followers: +15% score adjustment
  - Follower-based adjustment applied after base score calculation
  - Adjustment displayed separately in score breakdown with explanation
  - Final score still capped at 90% maximum
  - **Adjustable Follower Count Box**: Users can manually adjust their follower count in a dedicated input box to see how different follower tiers affect their viral score in real-time
- **Analysis Process with Countdown Timer**:
  - User clicks Analyze Reach button
  - 30-second reverse countdown timer starts immediately with calendar page-flip animation
  - AI analysis runs in parallel with countdown
  - Countdown automatically stops and disappears once score calculation completes
  - If analysis finishes before 30 seconds, countdown stops at current number and fades out
  - If analysis exceeds 30 seconds, countdown completes at 0 and disappears while analysis continues
- Enhanced scoring strictness:
  - Score range: 0-90% (90% capped as maximum achievable)
  - Score distribution targets:
    - 90%+: Reserved for top 5-10% of posts only (extremely rare, near-perfect execution)
    - 80-89%: Good posts with strong fundamentals (top 15-20%)
    - 70-79%: Decent posts with room for improvement (top 30-40%)
    - 60-69%: Average posts with multiple improvement areas (middle 20-30%)
    - Below 60%: Posts requiring significant optimization
  - AI analysis depth: Each post undergoes comprehensive multi-factor evaluation
- Formula: Score = (Hook_Weight * Hook_Quality) + (Rhythm_Weight * Readability_Score) + (360_Brew_Weight * Content_Depth) + (Media_Weight * Image_Quality) + (Niche_Weight * Keyword_Match) + (Paragraph_Structure_Weight * Line_to_Paragraph_Ratio) + (Follower_Adjustment) + Bias
- Scoring rules (stricter thresholds):
  - First sentence < 8 words containing numbers or POV: +25 points (reduced from +30)
  - Alternating short/long sentences (visual rhythm): +15 points (reduced from +20)
  - Frontloaded value in first lines: +20 points (reduced from +25)
  - Theme consistency across profile/posts/comments: +12 points (reduced from +15)
  - Strategic niche-aligned comments: +8 points (reduced from +10)
  - Profile authority optimization: +15 points (reduced from +20)
  - Clarity/story/depth (360 Brew reasoning): +25 points (reduced from +30)
  - Media inclusion (images/video): +12 points (reduced from +15)
  - Story types (origin/adversity/customer): +15 points (reduced from +20)
  - Optimal line-to-paragraph ratio (2-3 lines per paragraph): +10 points
  - Niche-specific keyword bonus: Variable points based on target audience (stricter matching)
  - Penalties (increased severity): Keyword stuffing (-20), random topics (-15), lazy engagement (-10), promo blasts (-25), wrong niche lingo (-15), long paragraphs > 4 lines (-10 per occurrence), wall of text (-20)
- AI-powered analysis factors:
  - Semantic coherence and logical flow
  - Emotional resonance and authenticity
  - Value proposition clarity
  - Audience alignment precision
  - Engagement trigger effectiveness
  - Content uniqueness and originality

### 3.4 Hook A/B Testing Arena (Module 1)
- New navigation tab: Hook Lab
- Split-screen layout with two text input areas side-by-side
- Central Fight! button to trigger comparison
- Input validation requirements:
  - Hook Option A: Required field, minimum 5 characters, maximum 200 characters
  - Hook Option B: Required field, minimum 5 characters, maximum 200 characters
  - Both hooks must contain text before Fight! button becomes active
  - Real-time character count display for each hook input
  - Error message display if validation fails
- Scanning animation on both sides when analysis starts
- Winner highlighted with Green Borders, loser with Red Borders
- Score Delta display showing point difference and reason
- Example: Option B is +12 points better because it uses a Number
- Probability spread calculation: Option B is 15% more likely to stop the scroll
- AI-powered improvement suggestions for both hooks

### 3.5 Readability X-Ray Visual Heatmap (Module 2)
- Toggle switch: X-Ray Mode in main editor
- Real-time text highlighting with color-coded overlays:
  - Red highlight (bg-red-500/20): Sentences > 20 words (Too long, kills retention)
  - Green highlight (bg-green-500/20): Sentences < 7 words (Punchy, good for skimming)
  - Yellow highlight (bg-yellow-500/20): Passive voice or weak words (think, believe, hope, maybe)
- Heads Up Display (HUD) visual style
- Regex-based sentence analysis running in browser
- Paragraph length analysis: Flag paragraphs > 4 lines as readability issues

### 3.6 Niche-Specific Dictionary (Module 3)
- Dropdown selector: Target Audience near score display
- Options:
  - General
  - SaaS/Tech
  - Student/Career
  - Design/Creative
- Dynamic keyword weighting in scorer.ts:
  - SaaS/Tech keywords: MRR, B2B, Scale, Exit, Revenue, Churn
  - Student/Career keywords: Hired, Resume, GPA, Offer, Internship, Learning
  - Design/Creative keywords: UI/UX, Figma, Space, Color, Portfolio, Aesthetic
- Niche mismatch warning: Wrong Lingo: You are using student terms for a SaaS audience
- Context-aware scoring adjustments

### 3.7 Consistency Streak Gamification (Module 4)
- GitHub-style contribution graph on user profile
- Daily analysis tracking: Each day user analyzes a post, square turns green
- Streak counter in top right corner: 🔥 4 Day Streak
- Encourages daily platform usage

### 3.8 Image Analysis Integration (Enhanced with Impression Predictor)
- **Image Upload Section**:
  - Positioned directly below Drafting Board section on dashboard
  - Multiple image upload support with drag-and-drop functionality
  - Image preview thumbnails displayed after upload
  - Remove/replace individual images option
  - Maximum file size validation and format validation (JPEG, PNG, GIF)
- **Image Analysis with Impression Predictor**:
  - AI analyzes each uploaded image for:
    + Relevance to post content
    + Visual quality and professional appearance
    + Infographic effectiveness
    + Color scheme alignment with brand
    + Text readability (if image contains text)
  - **Impression Boost Predictor**: Each image receives predicted impression increase percentage
    + Display format: Image contributes +X% to overall impressions
    + Calculation based on image quality score, relevance score, and historical performance data
    + Aggregated impression boost displayed in overall score breakdown
  - Individual image scores contribute to overall viral score
  - AI-powered image improvement suggestions for each uploaded image
  - Comparison feature: Shows predicted score difference with vs without images
- **Image Performance Display**:
  - Each image rated individually with percentage score
  - Impression boost prediction displayed prominently for each image
  - Suggestions for additional/alternative images
  - AI insights: How image selection can be improved to maximize impressions
  - Visual indicator showing which image contributes most to impression boost

### 3.9 Detailed Performance Breakdown (Enhanced with Follower Adjustment)
- **Follower-Based Score Adjustment Display**:
  - Dedicated section showing follower count tier and corresponding adjustment
  - Visual representation of adjustment impact on final score
  - Explanation text: Your follower count (X followers) adds/reduces Y% to your viral score
  - Breakdown showing base score vs adjusted score
  - **Adjustable Follower Count Box**: Input box allowing users to manually adjust follower count to see real-time score changes based on different follower tiers
- Hook Quality Analysis:
  - Hook effectiveness percentage
  - Hook type identification
  - Alternative hook suggestions
  - AI insights: How this hook can be improved
- Paragraph-by-Paragraph Ranking:
  - Individual paragraph scores
  - Improvement suggestions for each paragraph
  - Line-to-paragraph ratio analysis for each paragraph
  - AI insights: How each paragraph can be optimized
- Image Performance Analysis (Enhanced):
  - Each image rated individually with impression boost prediction
  - Suggestions for additional/alternative images
  - AI insights: How image selection can be improved to maximize impressions
  - Aggregated impression boost from all images
- Component Percentage Breakdown:
  - Hook Quality %
  - Initial Paragraph %
  - Body Content %
  - Rhythm %
  - 360 Brew %
  - Media Quality % (with impression boost contribution)
  - Story Type %
  - Niche Alignment %
  - Paragraph Structure %
  - Follower Adjustment %

### 3.10 Hook-Refiner Module
- Automatically identifies the Hook (first 2 lines of post)
- Provides 3 better alternative hooks:
  - **Controversial Hook**: Polarizing statement designed to spark debate
  - **Data-driven Hook**: Numbers/statistics-based opening
  - **Story-based Hook**: Personal narrative or anecdote opening
- Each alternative includes:
  - Full hook text
  - Predicted engagement boost percentage
  - Reasoning for why it performs better
  - AI insights: How to further optimize each alternative
- Display format: Side-by-side comparison cards with original hook vs 3 alternatives

### 3.11 The 5 Flaw Audit
- Identifies exactly 5 specific flaws in user's post
- Flaw categories analyzed:
  1. **Visual Friction**: Detects wall of text issues (paragraphs > 3 lines flagged)
  2. **Me-Monster**: Analyzes self-centric vs audience-centric language ratio
  3. **Weak CTA**: Evaluates ending effectiveness for comment generation
  4. **Rhythm**: Checks sentence length variation and repetition patterns
  5. **Clarity**: Identifies missing So What? factor and value proposition
- Output format:
  - Flaw title with severity indicator (Critical/High/Medium)
  - Specific location in post (line numbers or paragraph reference)
  - Brutally honest but actionable explanation
  - Concrete fix suggestion with example
  - AI insights: How to systematically eliminate this flaw
- Tone: Professional yet punchy, direct feedback without sugar-coating

### 3.12 See More Button Predictor (Enhanced)
- **Dotted Line Indicator**: Displays a dotted line in the text editor at approximately 210-220 characters (including spaces) to indicate where LinkedIn's See More truncation occurs on the general feed
- **Dynamic Visibility**: The dotted line disappears when the user's text exceeds the truncation point, providing clear visual feedback
- **Character Position Calculation**: Calculates exact character position where LinkedIn See More button appears
- Standard LinkedIn truncation: ~210-220 characters on desktop, ~140 on mobile
- **Visual Indicator Specifications**:
  - Dotted line style: 2px dashed line in Warning Orange color
  - Positioned horizontally across the text editor at the truncation point
  - Label text: See More (~210 chars) displayed near the line
  - Line disappears with smooth fade-out animation when text exceeds truncation point
- Warning badge if hook doesn't complete before cutoff
- Flaw flagging: If hook extends past See More button, automatically flagged in 5 Flaw Audit
- Display: Character count with See More position marker
- AI insights: How to restructure content for optimal visibility

### 3.13 Scanning Score Calculator (Enhanced)
- Formula: Scanning Score = Total Lines / Paragraphs
- Readability threshold: Average paragraph > 3 lines triggers Readability Flaw
- Optimal range: 2-3 lines per paragraph for maximum readability
- Real-time calculation displayed alongside Viral Score
- Visual representation:
  - Green zone: 2-3 lines per paragraph (Optimal)
  - Yellow zone: 3-4 lines per paragraph (Acceptable)
  - Red zone: > 4 lines per paragraph (Poor readability - people avoid reading long paragraphs, limiting post reach)
- Integration with X-Ray Mode for visual paragraph length highlighting
- Penalty system: Each paragraph > 4 lines reduces overall score
- AI insights: How to break down long paragraphs for better engagement

### 3.14 Hashtag Suggestion Engine (Enhanced)
- AI-powered hashtag recommendations based on:
  - Post content analysis
  - Niche category selection
  - Trending topics in user's industry
  - Historical performance data from training dataset
- Suggests 3-5 optimal hashtags per post
- Display format:
  - Hashtag text with predicted reach estimate
  - Relevance score (0-100%)
  - Usage frequency indicator (Trending/Popular/Niche)
  - AI insights: How this hashtag can be optimized or replaced
- Hashtag categories:
  - Industry-specific (e.g., #B2BMarketing, #DesignThinking)
  - Engagement-focused (e.g., #MondayMotivation, #ThoughtLeadership)
  - Niche-aligned based on selected target audience
- One-click copy functionality for suggested hashtags
- AI-powered alternative hashtag suggestions with reasoning

### 3.15 AI-Powered Improvement Insights
- Comprehensive AI analysis providing actionable insights for every component:
  - **Hook Optimization**: Specific suggestions on how to make the hook more compelling
  - **Paragraph Structure**: Detailed guidance on breaking down long paragraphs and improving line-to-paragraph ratio
  - **Content Flow**: Recommendations for improving logical progression and readability
  - **Engagement Triggers**: Suggestions for adding elements that drive comments and shares
  - **Niche Alignment**: Specific keyword and tone adjustments for target audience
  - **Visual Elements**: Image selection and placement recommendations with impression boost predictions
  - **CTA Enhancement**: Specific ways to strengthen call-to-action effectiveness
  - **Rhythm Optimization**: Sentence structure variations for better scanning
  - **Follower Growth Strategy**: Recommendations for leveraging current follower tier and growing to next tier
- Each insight includes:
  - Current issue identification
  - Impact on viral score
  - Specific improvement suggestion
  - Example implementation
  - Expected score boost

### 3.16 Improvement Recommendations Page (Enhanced)
- Dedicated section showing:
  - Better hook alternatives with examples (includes 3 Hook-Refiner alternatives with AI insights)
  - Paragraph rewrite suggestions with line-to-paragraph ratio optimization
  - Image replacement recommendations with impression boost predictions and AI insights
  - Rhythm improvement tips
  - Content depth enhancement suggestions
  - Niche-specific optimization tips
  - Overall optimization strategy
  - The 5 Flaw Audit results with actionable fixes and AI insights
  - Scanning Score improvement recommendations with paragraph restructuring examples
  - Suggested hashtags with performance predictions and AI-powered alternatives
  - AI-powered improvement insights for all components
  - Follower-based optimization strategies for current tier

### 3.17 Post History Tracking (Enhanced with Follower Adjustment Data)
- User dashboard displaying:
  - All previously analyzed posts with full text content
  - Historical viral scores for each post (including follower adjustment)
  - Timestamps of analysis
  - Ability to view complete past results including detailed breakdowns
  - Search functionality to find specific posts by keywords or content
  - Filter options: by date range, by score range, by niche category, by follower tier at time of analysis
  - Sort options: by date (newest/oldest), by score (highest/lowest), by analysis count
  - Pagination for large history datasets
  - Quick preview cards showing post snippet, score, follower adjustment, and date
  - Click to expand full analysis details including component breakdowns and impression predictions
  - Export history data functionality
  - Delete individual history entries option

### 3.18 Training Data
- Hardcoded JSON file: training_data.json
- Contains representative rows of Golden Posts examples including:
  - The POV Story
  - The Contrarian Take
  - The Paradox Hook
  - The Bold How-To
  - The Numbers-Driven Post
  - 5 Post Funnel examples: Awareness (quotable ideas), Personal (stories), Education (A-to-B guides), IP (frameworks), Conversion (case studies like Dr. Caroline from 20k to 200k followers)
  - 360 Brew algorithm mastery posts
  - IRL-to-URL content examples
  - SERVE selling methodology posts
  - Revenue-focused strategy posts with proprietary data carousels
  - Creator-specific patterns from 34,000+ analyzed viral posts
  - Engagement metrics: impressions, likes, comments, reposts, support interactions
  - Niche-specific performance data across all creator categories
  - Follower-tier performance benchmarks
  - Image-based impression boost historical data
- Display in Learned Patterns marquee on dashboard

### 3.19 Profile as Landing Page
- Headline formula: I am [job title] that helps [ICP] achieve [result] by [action]
- Featured section with newsletter subscription and inquiry form
- Deplatform strategy to own audience

### 3.20 5 Post Funnel Strategy
- Awareness: Quotable ideas
- Personal: Stories
- Education: A-to-B guides
- IP: How we do it frameworks
- Conversion: Real case studies (e.g., Dr. Caroline from 20k to 200k followers)

### 3.21 Pre-validated Content System
- Study top books/videos on topics (e.g., Atomic Habits for delegation)
- Remix for brand
- Post daily via 3-page doc (ICP + topics)

### 3.22 SERVE Selling Methodology
- Show up consistently
- Educate
- Relate
- Value > transactions
- Engage
- Social selling (comment on ICP)
- Clear positioning

### 3.23 IRL-to-URL Content
- Capture events/conferences for AI-proof content
- Example: Top BDRs talk for $15 sign

### 3.24 Media Strategy
- Images/B-roll > text-only
- Infographics savable
- Video 1x/week
- Workflow for office shots
- Horizontal 90s-5m videos > vertical

### 3.25 Story Types
- Origin: Why started
- Adversity: Overcome challenge
- Customer cases
- Share personal interests humanely

### 3.26 Outreach System
- 20 connections/day → profile viewers → engagers (Trigify/Heyreach)
- Value Looms first

### 3.27 Ads Strategy
- Boost top organics as thought leader ads ($30-100/day)
- Add PS CTA post-run

### 3.28 Repurpose Strategy
- Opus clips podcasts
- Carousels for dwell/share
- Events/newsletters

### 3.29 Double Down Strategy
- Shield/exports analyze winners
- Proprietary/survey data carousels

### 3.30 Engagement Strategy
- Thoughtful comments double visibility
- Carrot ads personalize
- Stanley AI voice match

### 3.31 AI-Powered Interactive Search
- **Feature Name**: AI Search Assistant
- **Trigger**: Available after user clicks Analyze Reach button and analysis completes
- **Functionality**:
  - Interactive search interface positioned prominently on dashboard after analysis
  - Users can ask follow-up questions about their analyzed post
  - AI provides contextual answers based on the specific post analysis results
  - Question types supported:
    + Why did my post receive this score?
    + How can I improve my hook?
    + What are the best hashtags for my niche?
    + Why is my paragraph structure flagged?
    + How can I increase my impression boost?
    + What changes would increase my viral score the most?
    + How does my follower count affect my score?
    + Which image performs best and why?
- **UI Components**:
  - Search input field with placeholder text: Ask me anything about your post analysis...
  - Submit button or Enter key to send question
  - Conversation history display showing Q&A pairs
  - Clear conversation button to reset chat
  - Suggested questions displayed as clickable chips for quick access
- **AI Response Features**:
  - Contextual answers referencing specific analysis components
  - Actionable recommendations with examples
  - Links to relevant sections of the analysis breakdown
  - Follow-up question suggestions based on user's query
  - Real-time typing indicator during AI response generation
- **Integration Points**:
  - Access to full post analysis data (scores, breakdowns, insights)
  - Reference to training data patterns and best practices
  - Connection to Hook-Refiner, 5 Flaw Audit, and other module results
  - Ability to reference uploaded images and their performance
- **Display Position**:
  - Positioned below main score gauge or in dedicated tab
  - Collapsible panel to save screen space when not in use
  - Persistent across dashboard navigation after analysis
- **Styling**:
  - Glassmorphism card design consistent with platform theme
  - Electric Blue accent for user questions
  - Signal Green accent for AI responses
  - Smooth fade-in animation for new messages
  - Scrollable conversation history with auto-scroll to latest message

### 3.32 AI-Generated Content Detection (NEW)
- **Feature Name**: AI Content Detector
- **Trigger**: Automatically runs during post analysis after user clicks Analyze Reach button
- **Detection Algorithm**: Multi-factor analysis based on 2026 AI detection patterns:
  - **Robotic Structure & Formatting Detection**:
    + Identifies rigid Hook-Body-CTA formula patterns
    + Analyzes sentence length uniformity (lack of burstiness)
    + Detects perfect spacing and zero typos/casual grammar quirks
  - **Language Tics & Buzzwords Detection**:
    + Scans for corporate bingo words: delve, unlock, unleash, navigate, landscape, dynamic, multifaceted, transformative, tapestry
    + Identifies cliché phrases: In today's fast-paced digital world, It's important to note that
    + Detects over-the-top enthusiasm patterns: excited to share, humbled to announce
  - **Experience Gap Analysis**:
    + Identifies vague anecdotes lacking specific details
    + Detects lack of strong opinions or controversial stances
    + Checks for fact hallucinations or unsourced statistics
  - **Visual & Technical Indicators**:
    + Analyzes emoji overload and placement patterns (emojis as bullet points, exact end-of-paragraph placement)
    + Detects emoji-keyword mirroring (💡 with idea, 💼 with business)
  - **Em Dash Obsession Detection**:
    + Counts em dash usage frequency (> 2 em dashes in short post = red flag)
    + Identifies double definition patterns using em dashes
    + Detects perfect symmetry in em dash spacing
  - **Emoji Usage Patterns**:
    + Identifies keyword mirroring (emoji matches specific word)
    + Detects bullet point replacement with professional emojis (✅, ➡️, 🔵)
    + Analyzes emoji placement logic (exclusively at sentence end)
  - **Human Touch Absence**:
    + Detects lack of low-utility personal details
    + Identifies absence of self-deprecation or genuine vulnerability
    + Checks for missing sarcasm, slang, sentence fragments, or contradictions
- **AI Detection Score Display**:
  - **Visual Representation**: Horizontal gradient scale from left (green) to right (red)
  - **Score Range**: 0-100% AI likelihood
    + 0-20%: Likely Human (Green zone)
    + 21-50%: Possibly Human with AI assistance (Yellow zone)
    + 51-80%: Likely AI-generated (Orange zone)
    + 81-100%: Highly likely AI-generated (Red zone)
  - **Indicator Position**: Marker on the gradient scale showing exact AI likelihood percentage
  - **Color Gradient**: Smooth transition from Signal Green (#10B981) on left to Warning Red (#EF4444) on right
- **Detailed AI Detection Breakdown**:
  - **Specific Indicators Identified**: List of detected AI patterns with examples from the post
  - **Pattern Explanations**: Brief explanation of why each detected pattern suggests AI generation
  - **Humanization Suggestions**: Actionable recommendations to make the post sound more human:
    + Add specific personal details (dates, names, locations)
    + Include self-deprecating humor or genuine vulnerability
    + Use sentence fragments and varied sentence lengths
    + Add contradictions or mid-thought changes
    + Replace corporate buzzwords with conversational language
    + Use emojis more naturally (stacking, mid-sentence placement)
    + Reduce em dash usage and perfect formatting
- **Display Position**:
  - Positioned in the diagnostics panel below the main viral score gauge
  - Displayed as a dedicated section after analysis completes
  - Collapsible section to save space when not needed
- **Styling**:
  - Glassmorphism card design consistent with platform theme
  - Gradient scale with clear color transitions
  - Bold percentage display at marker position
  - List format for detected indicators with icons
  - Actionable suggestions displayed as numbered list
- **Integration with Overall Analysis**:
  - AI detection score does not directly affect viral score calculation
  - Serves as supplementary insight for content authenticity
  - Humanization suggestions integrated into AI-Powered Improvement Insights
  - Stored in post history for tracking AI detection trends over time

### 3.33 Strengths & Weaknesses Analysis (NEW)
- **Feature Name**: Strengths & Weaknesses Analysis
- **Trigger**: Automatically runs during post analysis after user clicks Analyze Reach button
- **Display Position**: Positioned directly below AI Detection Analysis section in the diagnostics panel
- **Layout**: Split-screen card design with two columns:
  - **Left Column**: Strengths (with green checkmark icon)
  - **Right Column**: Weaknesses (with red X icon)
- **Content Structure**:
  - **Strengths Section**:
    + Lists 3-5 key strengths identified in the post
    + Each strength displayed with green checkmark icon
    + Examples: Interactive and unique challenge concept, Strong attention-grabbing hook, Clear incentive for participation, Relatable to optimization mindset of entrepreneurs
  - **Weaknesses Section**:
    + Lists 3-5 key weaknesses identified in the post
    + Each weakness displayed with red X icon
    + Examples: Inconsistent grammar/capitalization/punctuation, Poor readability due to dense sentences, CTA is fragmented and not as compelling, Mobile optimization disclaimer is poorly placed
- **Analysis Logic**:
  - AI-powered analysis identifies specific strengths and weaknesses based on:
    + Hook effectiveness
    + Content structure and readability
    + Grammar and formatting consistency
    + CTA clarity and placement
    + Mobile optimization considerations
    + Engagement trigger effectiveness
    + Niche alignment and audience relevance
- **Styling**:
  - Glassmorphism card design consistent with platform theme
  - Split-screen layout with clear visual separation
  - Green accent color for Strengths section
  - Red accent color for Weaknesses section
  - Icon-based bullet points for each item
  - Collapsible section to save space when not needed
- **Integration Points**:
  - Positioned directly below AI Detection Analysis section
  - Feeds into AI-Powered Improvement Insights module
  - Stored in post history for tracking improvement trends
  - Referenced in Improvement Recommendations page

### 3.34 Paragraph Structure Analysis (NEW)
- **Feature Name**: Paragraph Structure Analysis
- **Trigger**: Automatically runs during post analysis after user clicks Analyze Reach button
- **Display Position**: Positioned directly below Strengths & Weaknesses Analysis section in the diagnostics panel
- **Layout**: Single card with three key metrics displayed horizontally:
  - **Paragraphs**: Total number of paragraphs in the post
  - **Avg Lines/Para**: Average number of lines per paragraph
  - **Long Paras**: Number of paragraphs exceeding 4 lines
- **Metrics Display**:
  - Large, bold numbers for each metric (JetBrains Mono font)
  - Descriptive labels below each number
  - Color-coded indicators:
    + Green: Optimal paragraph structure (Avg Lines/Para: 2-3)
    + Yellow: Acceptable paragraph structure (Avg Lines/Para: 3-4)
    + Red: Poor paragraph structure (Avg Lines/Para: > 4 or Long Paras > 0)
- **Recommendation Section**:
  - Positioned below the metrics display
  - Displays actionable recommendation text in Warning Orange color
  - Example: The paragraph about the tool's technical details is too dense. Break it into 2-3 shorter paragraphs or use bullet points to highlight the key aspects (e.g., no bloated libraries, no server lag). The final disclaimer about mobile optimization also functions as a small paragraph and needs to be integrated more smoothly.
- **Analysis Logic**:
  - Calculates total number of paragraphs
  - Calculates average lines per paragraph (Total Lines / Paragraphs)
  - Counts paragraphs exceeding 4 lines
  - Generates specific recommendations for improving paragraph structure
  - Identifies dense paragraphs and suggests breaking them down
  - Recommends bullet points or shorter paragraphs for better readability
- **Styling**:
  - Glassmorphism card design consistent with platform theme
  - Horizontal layout for metrics display
  - Large, bold numbers with descriptive labels
  - Color-coded indicators for visual feedback
  - Recommendation text in Warning Orange with clear formatting
  - Collapsible section to save space when not needed
- **Integration Points**:
  - Positioned directly below Strengths & Weaknesses Analysis section
  - Feeds into Scanning Score Calculator (Module 3.13)
  - Referenced in The 5 Flaw Audit (Visual Friction flaw)
  - Stored in post history for tracking paragraph structure trends
  - Integrated into AI-Powered Improvement Insights module

### 3.35 User Roles

#### Role A: The Creator (User)
- Sign up/login to access platform via email/password or Google authentication
- View niche-specific creator column after login completion
- Input text into Drafting Board
- Upload images in dedicated section below Drafting Board
- View impression boost predictions for each uploaded image
- **Adjust follower count manually in dedicated input box to see real-time score changes**
- Click Analyze Reach to see score (capped at 90%, with stricter distribution and follower-based adjustment)
- **View 30-second countdown timer with calendar page-flip animation during analysis**
- **View dotted line indicator at ~210-220 characters showing LinkedIn See More truncation point**
- **View AI-generated content detection score with gradient scale and humanization suggestions**
- **View Strengths & Weaknesses Analysis with specific identified strengths and weaknesses**
- **View Paragraph Structure Analysis with metrics and actionable recommendations**
- View detailed breakdown of all components with AI-powered insights and follower adjustment
- **Use AI Search Assistant to ask follow-up questions about analysis results**
- Access Hook-Refiner for 3 alternative hooks with AI optimization suggestions
- Review The 5 Flaw Audit with specific actionable fixes and AI insights
- Check See More Button position and warnings with AI restructuring suggestions
- Monitor Scanning Score for readability with paragraph optimization recommendations
- Receive AI-powered hashtag suggestions with alternatives and reasoning
- Access comprehensive AI-powered improvement insights for all components including image optimization
- Access post history with full text content, analysis details, and follower adjustment data
- Search, filter, and sort historical posts
- View improvement recommendations with AI insights and impression predictions
- Use Hook Lab for A/B testing with AI suggestions
- Toggle X-Ray Mode for readability heatmap with paragraph length analysis
- Select target audience niche
- Track consistency streak
- Cannot see or modify algorithm weights

#### Role B: The Architect (Admin)
- Access via hidden Simulate Admin Mode toggle
- View Algorithm Tuner panel with sliders
- Adjust weights (e.g., Video Scripts vs Text importance, 360 Brew factors, Media priority, Story types, Niche weighting, Paragraph structure weight, Follower adjustment multipliers)
- Real-time score calculation updates
- Adjust strictness parameters for score distribution
- Configure follower tier thresholds and adjustment percentages

## 4. Page Structure

### 4.1 Landing Page
- First Section (Viewport 1):
  - Full-screen hero section
  - Application name It's Better displayed with 3D depth effect
  - LiquidEther WebGL fluid simulation active as background layer at outer page level
  - ScrollFloat effect active on cursor movement across all text elements
  - Minimal UI, focus on brand name
  - Scroll indicator to guide user interaction
- Second Section (Viewport 2):
  - ScrollFloat animation triggers on scroll and follows cursor movement across all text elements
  - Character-by-character text reveal effect
  - Content from uploaded image {F40BBFFA-A301-46BC-B01B-7246992E4F0E}.png displays
  - Smooth transition from hero to content section
  - LiquidEther effect continues as background layer at outer page level

### 4.2 Authentication Pages
- Sign Up Page:
  - Name field (required, minimum 2 characters validation)
  - Email field (required, email format validation)
  - Password field (required, minimum 8 characters with uppercase, lowercase, number validation)
  - LinkedIn follower count field (required, positive number validation)
  - Current role/job title field
  - Industry/niche field (required for niche-specific creator mapping)
  - Additional personal information fields
  - **Google Sign-Up Button**: OSS Google login integration for one-click authentication
  - Real-time validation error messages
  - LiquidEther effect as background layer at outer page level
- Login Page:
  - Email field (required, email format validation)
  - Password field (required)
  - **Google Login Button**: OSS Google login integration for one-click authentication
  - Real-time validation error messages
  - LiquidEther effect as background layer at outer page level
- Post-Login Display:
  - Niche-specific creator column showing relevant thought leaders from training dataset
  - Creator names mapped to user's selected industry/niche

### 4.3 Header
- Logo It's Better (top left)
- Navigation: Dashboard, Hook Lab, History, Profile
- Streak counter (top right): 🔥 4 Day Streak
- Admin Mode Toggle (top right, for admin users)

### 4.4 Training Data Marquee Section
- Positioned below header or above main dashboard content
- Horizontal scrolling marquee with continuous animation
- Text content: This platform is trained with 1000+ posts and has analyzed statistics + content quality + niche alignment + views + impressions + comments + likes + support interactions + reposts
- Glassmorphism background styling
- Subtle glow effect for emphasis
- Infinite loop animation with smooth transitions

### 4.5 Main Dashboard (Split View)
- LiquidEther effect as background layer at outer page level across entire dashboard

#### Left Panel: Input Area
- Clean, distraction-free text editor (Drafting Board)
- **See More Button Dotted Line Indicator**:
  - Dotted line displayed at approximately 210-220 characters (including spaces)
  - Line style: 2px dashed line in Warning Orange color
  - Label text: See More (~210 chars) displayed near the line
  - Dynamic visibility: Line disappears with smooth fade-out animation when text exceeds truncation point
- X-Ray Mode toggle switch
- Paragraph length highlighting (red for > 4 lines)
- **Image Upload Section**:
  - Positioned directly below Drafting Board
  - Drag-and-drop upload area with visual feedback
  - Multiple image preview thumbnails
  - Remove/replace individual images functionality
  - File size and format validation messages
  - Upload progress indicators
- Analyze Reach button with glow effect when user types

#### Right Panel: Diagnostics
- **Analysis Countdown Timer Display**:
  - Prominently positioned near score gauge or in center area
  - 30-second reverse countdown (30→0) with calendar page-flip animation
  - Starts immediately when Analyze Reach button is clicked
  - Automatically stops and disappears once score calculation completes
  - Large, bold numbers with glassmorphism styling
  - 3D page-flip effect (bottom-to-top or top-to-bottom)
- Target Audience dropdown selector (General, SaaS/Tech, Student/Career, Design/Creative)
- Score Gauge: Large radial progress circle showing Viral Probability (0-90% maximum, stricter distribution)
- **Follower Adjustment Display**:
  - Follower count tier badge (e.g., 2K-12K Followers)
  - Adjustment percentage indicator (e.g., +4% Boost)
  - Visual representation of adjustment impact
  - Explanation tooltip
  - **Adjustable Follower Count Input Box**: Allows users to manually adjust follower count to see real-time score changes based on different follower tiers
- Scanning Score display with color-coded readability indicator (Green: 2-3 lines, Yellow: 3-4 lines, Red: > 4 lines)
- **AI-Generated Content Detection Section**:
  - Positioned below Scanning Score or in dedicated collapsible section
  - **Gradient Scale Display**:
    + Horizontal gradient bar from green (left) to red (right)
    + Marker indicating AI likelihood percentage (0-100%)
    + Color zones: Green (0-20%), Yellow (21-50%), Orange (51-80%), Red (81-100%)
    + Bold percentage display at marker position
  - **Detected AI Indicators List**:
    + Specific patterns identified (e.g., Em dash overuse, Corporate buzzwords, Perfect formatting)
    + Brief explanation for each detected pattern
    + Examples from the analyzed post
  - **Humanization Suggestions**:
    + Numbered list of actionable recommendations
    + Specific examples of how to make content sound more human
    + Integration with AI-Powered Improvement Insights
  - Glassmorphism card styling consistent with platform theme
  - Collapsible section to save space when not needed
- **Strengths & Weaknesses Analysis Section (NEW)**:
  - Positioned directly below AI Detection Analysis section
  - Split-screen card design with two columns:
    + **Left Column**: Strengths (with green checkmark icons)
    + **Right Column**: Weaknesses (with red X icons)
  - Lists 3-5 key strengths and weaknesses identified in the post
  - Glassmorphism card styling consistent with platform theme
  - Collapsible section to save space when not needed
- **Paragraph Structure Analysis Section (NEW)**:
  - Positioned directly below Strengths & Weaknesses Analysis section
  - Single card with three key metrics displayed horizontally:
    + **Paragraphs**: Total number of paragraphs
    + **Avg Lines/Para**: Average lines per paragraph
    + **Long Paras**: Number of paragraphs exceeding 4 lines
  - Color-coded indicators (Green/Yellow/Red) based on paragraph structure quality
  - Recommendation section with actionable text in Warning Orange color
  - Glassmorphism card styling consistent with platform theme
  - Collapsible section to save space when not needed
- **AI Search Assistant Section**:
  - Positioned below score gauge or in dedicated collapsible panel
  - Search input field with placeholder: Ask me anything about your post analysis...
  - Submit button for sending questions
  - Conversation history display with Q&A pairs
  - Suggested question chips for quick access
  - Clear conversation button
  - Glassmorphism card styling with Electric Blue/Signal Green accents
  - Smooth fade-in animations for new messages
  - Auto-scroll to latest message in conversation
- **Image Performance Section**:
  - Individual image scores with thumbnails
  - Impression boost prediction for each image (e.g., +12% impressions)
  - Aggregated impression boost from all images
  - AI-powered improvement suggestions for each image
  - Visual indicator showing highest-performing image
- AI-Powered Improvement Insights section:
  - Hook optimization suggestions
  - Paragraph structure recommendations
  - Content flow improvements
  - Engagement trigger suggestions
  - Niche alignment adjustments
  - Visual element recommendations with impression predictions
  - CTA enhancement tips
  - Rhythm optimization guidance
  - Follower growth strategy recommendations
  - **Enhanced Visual Styling**: Subtle gradient glow background with animated light particles, Electric Blue to Signal Green gradient overlay, soft pulsing glow effect, glassmorphism card with enhanced backdrop blur, gradient border with animated shimmer effect, inner glow shadow for depth perception
- Hook-Refiner section:
  - Original hook display
  - 3 alternative hooks (Controversial, Data-driven, Story-based)
  - Engagement boost predictions for each alternative
  - AI insights for further optimization
  - **Enhanced Visual Styling**: Subtle gradient glow background with animated light particles
- The 5 Flaw Audit section:
  - 5 specific flaws with severity indicators
  - Location references and actionable fixes
  - AI insights for systematic flaw elimination
  - **Enhanced Visual Styling**: Subtle gradient glow background with animated light particles
- Hashtag Suggestions section:
  - 3-5 recommended hashtags
  - Relevance scores and reach estimates
  - One-click copy functionality
  - AI-powered alternative suggestions
  - **Enhanced Visual Styling**: Subtle gradient glow background with animated light particles
- Detailed Component Breakdown:
  - Hook Quality: Percentage score with rating and AI insights
  - Initial Paragraph: Percentage score with rating and AI insights
  - Each subsequent paragraph: Individual percentage scores with line-to-paragraph ratio analysis and AI insights
  - Rhythm Analysis: Percentage score with AI insights
  - 360 Brew Score: Percentage score with AI insights
  - Media Quality: Individual image ratings with impression boost predictions and AI insights
  - Story Type: Percentage score with AI insights
  - Niche Alignment: Percentage score with AI insights
  - Paragraph Structure: Percentage score with AI insights
  - Follower Adjustment: Percentage adjustment with tier explanation
- Checklist: Dynamic feedback items
- Why Box: Explanation of math rules triggering the score
- Pattern Recognition Display: Show which training data pattern the post matches

### 4.6 Hook Lab (A/B Testing Arena)
- Split-screen layout
- Left side: Hook Option A text input (required, 5-200 characters validation)
- Right side: Hook Option B text input (required, 5-200 characters validation)
- Character count display for each input
- Central Fight! button (disabled until both inputs are valid)
- Validation error messages
- Scanning animation on both sides during analysis
- Winner display with green/red borders
- Score Delta and probability spread display
- AI-powered improvement suggestions for both hooks
- LiquidEther effect as background layer at outer page level

### 4.7 Improvement Recommendations Page (Enhanced)
- Hook Alternatives Section (includes Hook-Refiner results with AI insights)
- AI-Powered Improvement Insights for all components
- The 5 Flaw Audit detailed breakdown with AI insights
- Paragraph Improvement Section with line-to-paragraph ratio optimization
- **Image Recommendations with Impression Predictions**:
  - Current image performance analysis
  - Alternative image suggestions with predicted impression boost
  - AI insights for maximizing visual impact
  - Comparison: Current vs recommended images impression predictions
- Scanning Score optimization tips with paragraph restructuring examples
- Hashtag strategy recommendations with AI-powered alternatives
- Niche Optimization
- **Follower Growth Strategy**:
  - Current tier analysis and optimization tips
  - Recommendations for reaching next follower tier
  - Expected score boost from tier advancement
- Overall Optimization Strategy
- LiquidEther effect as background layer at outer page level

### 4.8 History Page
- Header section with page title and summary statistics
- Search bar with real-time filtering by post content or keywords
- Filter controls:
  - Date range picker (from date - to date)
  - Score range slider (0-90%)
  - Niche category dropdown (All, General, SaaS/Tech, Student/Career, Design/Creative)
  - Follower tier filter: All, <500, 2K-12K, 12K-40K, 40K-100K, 100K+
  - Apply Filters and Clear Filters buttons
- Sort controls:
  - Dropdown with options: Newest First, Oldest First, Highest Score, Lowest Score
- Post history grid/list display:
  - Preview cards showing:
    - Post text snippet (first 150 characters)
    - Viral score with color-coded badge
    - Follower adjustment indicator
    - Analysis timestamp
    - Niche category tag
    - Quick action buttons: View Details, Re-analyze, Delete
  - Click on card to expand full analysis modal showing:
    - Complete post text
    - Full component breakdown
    - Follower adjustment details
    - Image performance with impression predictions
    - Hook-Refiner alternatives with AI insights
    - The 5 Flaw Audit results with AI insights
    - Scanning Score with optimization recommendations
    - Hashtag suggestions with AI alternatives
    - AI-powered improvement insights for all components
    - Improvement recommendations
    - Original analysis timestamp
- Pagination controls at bottom
- Export History button (CSV/JSON format)
- Empty state message when no history exists
- LiquidEther effect as background layer at outer page level

### 4.9 Profile Page
- User information display
- LinkedIn follower count display with tier badge
- Niche-specific creator column showing relevant thought leaders
- GitHub-style contribution graph
- Streak statistics
- Historical performance metrics
- Follower tier progression tracking
- LiquidEther effect as background layer at outer page level

### 4.10 Admin Panel (Conditional)
- Algorithm Tuner with weight adjustment sliders
- Strictness parameter controls for score distribution
- **Follower Adjustment Configuration**:
  - Tier threshold sliders
  - Adjustment percentage controls for each tier
  - Real-time preview of adjustment impact
- Rendered only when Admin Mode toggle is active
- LiquidEther effect as background layer at outer page level

## 5. Content Strategy Integration

### 5.1 Supported Hook Styles
- Paradox (e.g., Regret improving)
- Bold how-to
- Counterintuitive
- Emotional bait
- Numbers-driven
- Quotable ideas (Awareness)
- Controversial (polarizing statements)
- Data-driven (statistics-based)
- Story-based (personal narratives)

### 5.2 Post Structure Analysis (Enhanced)
- POV hook structure (< 8 words)
- KISS body (step-by-step/problem-mistake-fix)
- Strong CTA evaluation
- Rhythm analysis (short/long sentence alternation)
- F-pattern scanning optimization
- Frontloaded value detection
- Theme consistency check
- Paragraph-by-paragraph quality assessment
- Line-to-paragraph ratio analysis (optimal: 2-3 lines per paragraph)
- Readability heatmap visualization
- See More button position awareness with dotted line indicator
- Scanning Score calculation with penalties for long paragraphs
- AI-powered structural optimization recommendations

### 5.3 Framework Recognition
- SMPV framework (Skill + Market + Problem + Value)
- 4-3-2-1 content system
- Outlier Content + Omni-Channel Flywheel
- SLA framework (Story-Lesson-Actionable-PS)
- 5 Post Funnel (Awareness, Personal, Education, IP, Conversion)
- SERVE Selling (Show up, Educate, Relate, Value, Engage)
- 360 Brew (Clarity/Depth/Value reasoning)
- Lara Acosta's 8-10 word hook rules with numbers/colons/lists

### 5.4 Algorithm Avoidance Patterns (Enhanced)
- Keyword stuffing detection
- Hack/spam identification
- Random topic flagging
- Lazy engagement detection
- Promo blast identification
- Niche mismatch detection
- Wall of text identification (Visual Friction)
- Long paragraph detection (> 4 lines per paragraph)
- Me-Monster language patterns
- Weak CTA detection
- Poor line-to-paragraph ratio (> 4 lines average)

### 5.5 Viral Factors from Training Data (Enhanced)
- Hook impact: 54% engagement boost from optimized hooks
- Structure predictability: 4.2x performance from listicles/parenthesis re-hooks
- Engagement signals: Comments predict 89% virality, first-hour engagement critical
- Format/Visuals: 2-3x reach from videos/images/carousels
- **Image Impression Boost**: High-quality images increase impressions by 15-40% based on relevance and visual appeal
- Niche fit: 4x performance for niche-aligned content
- Controlled vulnerability: 4.2x outperformance vs perfection
- Optimal posting: Tuesday/Wednesday +47% better performance
- Character count: 800-1200 chars optimal, 3.4x from stories
- Numbers/questions in hooks: 2.1x comments
- Personal stories: 3.4x engagement
- Paragraph structure: 2-3 lines per paragraph increases readability by 60%
- Short paragraphs: Posts with optimal line-to-paragraph ratio see 40% higher completion rates
- **Follower Authority**: Posts from accounts with 12K+ followers receive 25-50% higher organic reach due to LinkedIn algorithm prioritization

## 6. Interactive Visual Effects Implementation

### 6.1 LiquidEther Component
- WebGL-based fluid simulation effect applied as full-page background layer at outer page level across entire application
- Configuration parameters:
  - mouseForce: 20
  - cursorSize: 100
  - isViscous: false
  - viscous: 30
  - iterationsViscous: 32
  - iterationsPoisson: 32
  - dt: 0.014
  - BFECC: true
  - resolution: 0.5
  - isBounce: false
  - colors: ['#5227FF', '#FF9FFC', '#B19EEF']
  - autoDemo: true
  - autoSpeed: 0.5
  - autoIntensity: 2.2
  - takeoverDuration: 0.25
  - autoResumeDelay: 1000
  - autoRampDuration: 0.6
- Mouse interaction triggers dynamic color splashes
- Touch support for mobile devices
- Automatic color generation and updates
- Applied globally as background layer at outer page level across all pages and sections
- Positioned as fixed background layer behind all content at outer page level
- Automatic demo mode with smooth transitions between user control and auto-animation
- **Integration Location**: Outer page wrapper component (e.g., App.tsx or root layout component) to ensure effect spans entire application

### 6.2 TargetCursor Component
- Custom animated cursor with rotating corner brackets
- Targets interactive elements via CSS selector: .cursor-target
- Configuration parameters:
  - spinDuration: 2 seconds
  - hoverDuration: 0.2 seconds
  - hideDefaultCursor: true
  - parallaxOn: true
- Behavior:
  - Idle state: Continuous 360° rotation
  - Hover state: Brackets expand to frame target element
  - Click state: Scale down animation
  - Scroll tracking: Maintains target lock during page scroll
- Applied to all interactive elements (buttons, links, input fields)
- Mobile detection: Automatically disabled on touch devices

### 6.3 SplitText Animation Component
- Scroll-triggered text reveal animation
- Configuration parameters:
  - delay: 50ms between character animations
  - duration: 1.25 seconds
  - ease: power3.out
  - splitType: chars (characters), words, or lines
  - from: { opacity: 0, y: 40 }
  - to: { opacity: 1, y: 0 }
  - threshold: 0.1 (10% visibility trigger)
  - rootMargin: -100px
- Applied to:
  - Main headings and titles
  - Section introductions
  - Key messaging text
  - Dashboard labels and descriptions
- Font loading detection ensures proper text splitting
- Callback support for animation completion events

### 6.4 ScrollFloat Animation Component
- Character-by-character floating entrance effect
- Configuration parameters:
  - animationDuration: 1 second
  - ease: back.inOut(2)
  - scrollStart: center bottom+=50%
  - scrollEnd: bottom bottom-=40%
  - stagger: 0.03 seconds between characters
- Animation properties:
  - Initial state: opacity 0, yPercent 120, scaleY 2.3, scaleX 0.7
  - Final state: opacity 1, yPercent 0, scaleY 1, scaleX 1
  - transformOrigin: 50% 0%
- Scroll-triggered activation using GSAP ScrollTrigger
- Applied globally across all text elements wherever cursor moves
- Supports custom scroll container reference

### 6.5 Analysis Countdown Timer Animation Component
- **Component Name**: CountdownTimer
- **Animation Type**: Calendar page-flip effect with 3D rotation
- **Configuration Parameters**:
  - duration: 30 seconds (reverse countdown from 30 to 0)
  - flipDirection: bottom-to-top or top-to-bottom (configurable)
  - flipDuration: 0.6 seconds per number change
  - ease: power2.inOut
  - perspective: 1000px for 3D effect
  - rotationAxis: X-axis rotation for flip effect
  - shadowIntensity: Dynamic shadow during flip animation
- **Animation Properties**:
  - Initial state: Current number displayed with full opacity
  - Flip transition: 3D rotation effect simulating calendar page tear
  - Final state: Next number (n-1) revealed after flip completes
  - Depth effect: Perspective transform creates realistic page-flip illusion
  - Shadow effect: Dynamic shadow follows flip motion for enhanced realism
- **Behavior**:
  - Trigger: Starts immediately when Analyze Reach button is clicked
  - Countdown sequence: 30→29→28...→1→0
  - Parallel execution: Runs simultaneously with AI analysis process
  - Auto-stop condition: Stops and fades out as soon as viral score calculation completes
  - Incomplete countdown handling: If analysis finishes before reaching 0, countdown stops at current number and disappears
  - Overtime handling: If analysis exceeds 30 seconds, countdown completes at 0 and disappears while analysis continues
- **Display Styling**:
  - Position: Center or near score gauge area on dashboard
  - Size: Large, bold numbers (minimum 48px font size)
  - Background: Glassmorphism effect (blur-md, white/5 opacity, 1px border white/10)
  - Color scheme: Consistent with cyber-professional theme (Electric Blue accents)
  - Visibility: High contrast for clear readability during analysis
- **Technical Implementation**:
  - Library: GSAP for smooth 3D animations
  - Transform properties: rotateX for page-flip effect, translateZ for depth
  - State management: React state to track current countdown number and analysis completion status
  - Cleanup: Automatic removal from DOM after fade-out animation completes

### 6.6 See More Dotted Line Indicator Component (NEW)
- **Component Name**: SeeMoreIndicator
- **Visual Design**:
  - Dotted line style: 2px dashed line in Warning Orange (#F59E0B)
  - Positioned horizontally across the text editor at approximately 210-220 characters (including spaces)
  - Label text: See More (~210 chars) displayed near the line in small font
  - Line spans full width of text editor area
- **Dynamic Behavior**:
  - Appears when text length is below 210 characters
  - Disappears with smooth fade-out animation (0.3 seconds) when text exceeds 210-220 characters
  - Reappears with fade-in animation if text is reduced below 210 characters
  - Real-time character count tracking to trigger visibility changes
- **Position Calculation**:
  - Calculates exact vertical position based on character count and line height
  - Adjusts position dynamically as user types
  - Accounts for line breaks and paragraph spacing
- **Integration Points**:
  - Integrated into Drafting Board text editor component
  - Works in conjunction with See More Button Predictor logic (seeMoreCalculator.ts)
  - Coordinates with X-Ray Mode for visual consistency
- **Styling**:
  - Z-index positioned above text but below cursor and selection highlights
  - Semi-transparent to avoid obstructing text readability
  - Consistent with cyber-professional theme color scheme
- **Technical Implementation**:
  - CSS border-style: dashed for dotted line effect
  - React state to track character count and line visibility
  - GSAP or CSS transitions for smooth fade-in/fade-out animations
  - Event listeners for text input changes to update position and visibility

### 6.7 Interactive Elements Styling
- All clickable elements receive .cursor-target class
- Includes:
  - Navigation links
  - Buttons (Analyze Reach, Fight!, etc.)
  - Input fields
  - Dropdown selectors
  - Toggle switches
  - Card elements
  - History items
  - Google Sign-Up/Login buttons
  - Image upload area
  - AI Search Assistant submit button
  - Suggested question chips
  - Adjustable follower count input box
- Hover states enhanced with cursor tracking
- Click feedback integrated with cursor animations

## 7. Technical Deliverables

### 7.1 Frontend Components
- App.tsx (main application with LiquidEther integration at outer page level)
- Component files for:
  - LandingPage (with 3D hero section, ScrollFloat integration, and LiquidEther background at outer page level)
  - Authentication (SignUp, Login with LiquidEther background at outer page level, input validation, Google authentication integration, and niche-specific creator mapping)
  - GoogleAuthButton (OSS Google login integration component)
  - Text Editor with X-Ray Mode, See More dotted line indicator, and paragraph length highlighting
  - **SeeMoreIndicator (NEW)**: Dotted line component displaying LinkedIn See More truncation point at ~210-220 characters with dynamic visibility
  - **Image Upload Section**: Drag-and-drop upload area with preview, validation, and remove functionality
  - **Image Performance Display**: Individual image scores with impression boost predictions
  - Score Gauge (with stricter distribution display and follower adjustment indicator)
  - **Follower Adjustment Badge**: Displays follower tier and adjustment percentage
  - **Adjustable Follower Count Input Box (NEW)**: Allows users to manually adjust follower count to see real-time score changes
  - Scanning Score Display (with enhanced color-coded zones)
  - **CountdownTimer**: 30-second reverse countdown with calendar page-flip animation, auto-stop on analysis completion
  - **AI Content Detector Display (NEW)**: Gradient scale showing AI likelihood percentage (0-100%) with detected indicators and humanization suggestions
  - **Strengths & Weaknesses Analysis Display (NEW)**: Split-screen card showing identified strengths (green checkmarks) and weaknesses (red X icons)
  - **Paragraph Structure Analysis Display (NEW)**: Card displaying paragraph metrics (Paragraphs, Avg Lines/Para, Long Paras) with color-coded indicators and actionable recommendations
  - **AI Search Assistant**: Interactive search interface for post-analysis Q&A with conversation history, suggested questions, and contextual AI responses
  - AI-Powered Improvement Insights Display (enhanced with image optimization and follower growth strategies, plus enhanced visual styling with gradient glow background and animated light particles)
  - Hook-Refiner Display (3 alternative hooks with AI insights, plus enhanced visual styling)
  - The 5 Flaw Audit Display (with AI insights, plus enhanced visual styling)
  - Hashtag Suggestions Display (with AI alternatives, plus enhanced visual styling)
  - Detailed Breakdown Display (with AI insights for each component and follower adjustment)
  - Checklist
  - Admin Panel (with strictness controls and follower adjustment configuration)
  - Header with Streak Counter
  - Training Data Marquee
  - Niche-Specific Creator Column
  - Pattern Recognition Display
  - Percentage Breakdown Visualization (enhanced with follower adjustment)
  - History List with Search, Filter, and Sort functionality (enhanced with follower tier filter)
  - History Card Component (preview and expanded view with AI insights and follower adjustment data)
  - History Filter Controls (enhanced with follower tier filter)
  - History Search Bar
  - Improvement Recommendations (enhanced with AI insights, image predictions, and follower growth strategies)
  - Hook Lab (A/B Testing Arena with input validation and AI suggestions)
  - Readability Heatmap Overlay (with paragraph length analysis)
  - Niche Selector Dropdown
  - Contribution Graph
  - LiquidEther (WebGL fluid simulation background layer integrated at outer page level)
  - TargetCursor (animated cursor tracker)
  - SplitText (scroll-triggered text animation)
  - ScrollFloat (character-by-character floating animation with cursor tracking, applied globally wherever cursor moves)
  - InputValidator (reusable validation component for forms)
  - ParagraphAnalyzer (line-to-paragraph ratio calculator and visualizer)

### 7.2 Logic Files
- scorer.ts: Enhanced viral score calculation logic with stricter thresholds, AI-powered deep analysis, paragraph structure weighting, follower-based adjustment, and 90% cap with proper distribution
- **followerAdjuster.ts**: Calculates follower-based score adjustments based on tier thresholds, includes logic for manual follower count adjustment
- **countdownController.ts**: Manages countdown timer state, triggers start/stop based on analysis completion, handles parallel execution with AI analysis process
- **aiSearchEngine.ts**: Handles AI-powered interactive search functionality, processes user questions, generates contextual responses based on analysis data, manages conversation history
- **aiContentDetector.ts (NEW)**: Multi-factor AI detection algorithm analyzing robotic structure, language tics, experience gaps, visual indicators, em dash usage, emoji patterns, and human touch absence; generates AI likelihood score (0-100%) and humanization suggestions
- **strengthsWeaknessesAnalyzer.ts (NEW)**: Identifies 3-5 key strengths and weaknesses in the post based on hook effectiveness, content structure, grammar, CTA clarity, mobile optimization, engagement triggers, and niche alignment
- **paragraphStructureAnalyzer.ts (ENHANCED)**: Calculates paragraph metrics (total paragraphs, average lines per paragraph, long paragraphs count), generates actionable recommendations for improving paragraph structure, identifies dense paragraphs and suggests breaking them down
- aiInsightsGenerator.ts: AI-powered improvement insights generation for all components (enhanced with image optimization and follower growth strategies)
- hookRefiner.ts: Generates 3 alternative hooks (Controversial, Data-driven, Story-based) with engagement predictions and AI optimization insights
- flawAuditor.ts: Identifies 5 specific flaws (Visual Friction, Me-Monster, Weak CTA, Rhythm, Clarity) with actionable fixes and AI insights
- seeMoreCalculator.ts: Calculates See More button position (~210-220 chars desktop, ~140 mobile), validates hook completion, provides AI restructuring suggestions, and controls dotted line indicator visibility
- scanningScoreCalculator.ts: Enhanced readability score calculation using Total Lines / Paragraphs formula with penalties for long paragraphs and AI optimization recommendations
- hashtagSuggester.ts: AI-powered hashtag recommendation engine with alternatives and reasoning
- **imageAnalyzer.ts (ENHANCED)**: Image quality and relevance analysis with impression boost prediction and AI improvement suggestions
- **impressionPredictor.ts**: Calculates predicted impression increase percentage for each uploaded image
- auth.ts: User authentication logic with niche-specific creator mapping, follower count storage, and Google authentication integration
- googleAuth.ts: OSS Google login authentication logic and session management
- heatmapAnalyzer.ts: Regex-based sentence analysis for readability heatmap with paragraph length detection
- nicheKeywords.ts: Niche-specific keyword dictionaries and weighting logic
- streakTracker.ts: Daily activity tracking and streak calculation
- validator.ts: Input validation logic including email format, password strength, character length, number validation, and image file validation
- historyManager.ts: Post history storage, retrieval, search, filter (enhanced with follower tier filter), and sort logic
- nicheCreatorMapper.ts: Maps user's selected niche to relevant creators from training dataset
- **supabaseClient.ts**: Supabase connection configuration and client initialization

### 7.3 Data Files
- training_data.json: Expanded golden post examples including:
  - 5 Post Funnel examples
  - 360 Brew algorithm posts
  - IRL-to-URL content
  - SERVE selling methodology
  - Revenue-focused strategies
  - 34,000+ analyzed viral posts from leading creators
  - Engagement metrics (impressions, likes, comments, reposts, support)
  - Niche-specific performance patterns
  - Creator-specific viral formulas
  - Hook type performance data
  - Optimal posting times and character counts
  - Paragraph structure performance data
  - **Follower-tier performance benchmarks**
  - **Image-based impression boost historical data**
  - **AI-generated content detection patterns and indicators**
- users.json: User account data storage with niche/industry information, LinkedIn follower count, follower tier, and Google authentication data
- history.json: User post history storage with full text content, scores, timestamps, niche categories, detailed analysis results, Hook-Refiner alternatives, 5 Flaw Audit results, Scanning Scores, hashtag suggestions, follower adjustment data, image performance data with impression predictions, AI-generated content detection scores, Strengths & Weaknesses Analysis results, Paragraph Structure Analysis results, and AI-powered improvement insights
- niche_keywords.json: Keyword dictionaries for each target audience
- streak_data.json: User daily activity and streak records
- validation_rules.json: Centralized validation rules and error messages (enhanced with image validation rules)
- hashtag_database.json: Trending hashtags by niche with performance metrics
- niche_creator_mapping.json: Maps each niche/industry to relevant creators from training dataset
- score_distribution_config.json: Configuration for stricter score distribution thresholds
- **follower_tier_config.json**: Configuration for follower tier thresholds and adjustment percentages
- **impression_boost_data.json**: Historical data on image-based impression boost by image type and quality
- **ai_search_context.json**: Contextual data and response templates for AI Search Assistant
- **ai_detection_patterns.json (NEW)**: Comprehensive database of AI-generated content patterns including:
  - Robotic structure indicators (Hook-Body-CTA formula, uniform sentence length, perfect spacing)
  - Language tics and buzzwords (corporate bingo words, cliché phrases, over-the-top enthusiasm)
  - Experience gap markers (vague anecdotes, lack of opinion, hallucination factors)
  - Visual and technical indicators (emoji overload, comment test patterns)
  - Em dash obsession patterns (double definition, mid-sentence pivot, perfect symmetry)
  - Emoji usage patterns (keyword mirroring, bullet point replacement, placement logic)
  - Human touch absence indicators (low-utility details, self-deprecation, sarcasm/slang, contradictions)
  - Scoring weights for each pattern category
  - Humanization suggestion templates
- **strengths_weaknesses_templates.json (NEW)**: Templates and criteria for identifying post strengths and weaknesses across multiple dimensions (hook, structure, grammar, CTA, mobile optimization, engagement, niche alignment)

### 7.4 Animation Libraries
- GSAP (GreenSock Animation Platform) for advanced animations
- GSAP ScrollTrigger plugin for scroll-based animations
- GSAP SplitText plugin for text splitting and animation
- Framer Motion for React component animations
- WebGL for fluid simulation effects
- Three.js for 3D rendering and WebGL management

### 7.5 Conditional Rendering
- Admin Panel visibility based on toggle state
- History page accessible only to logged-in users
- Niche-specific creator column displayed after login completion
- Training data marquee displayed on dashboard
- **Countdown timer displayed only during active analysis process**
- **Countdown timer auto-hides upon analysis completion**
- **See More dotted line indicator displayed when text is below 210 characters**
- **See More dotted line indicator disappears when text exceeds 210-220 characters**
- **AI Content Detector section displayed after analysis completes**
- **Strengths & Weaknesses Analysis section displayed after analysis completes**
- **Paragraph Structure Analysis section displayed after analysis completes**
- **AI Search Assistant displayed only after analysis completes**
- **Image upload section displayed on dashboard**
- **Image performance display shown after analysis with impression predictions**
- **Follower adjustment badge displayed in score breakdown**
- **Adjustable follower count input box displayed in follower adjustment section**
- AI-powered improvement insights displayed after analysis (enhanced with image optimization and follower growth strategies)
- Improvement recommendations displayed after analysis (enhanced with image predictions and follower growth strategies)
- X-Ray Mode heatmap overlay toggle with paragraph length highlighting
- Hook Lab tab in navigation
- Streak counter display
- Niche mismatch warnings
- See More button warning badge (if hook extends past cutoff)
- Scanning Score color-coded indicators (Green: 2-3 lines, Yellow: 3-4 lines, Red: > 4 lines)
- Paragraph length warnings (> 4 lines flagged)
- Hook-Refiner alternatives display with AI insights
- The 5 Flaw Audit section visibility with AI insights
- Hashtag suggestions display with AI alternatives
- Mobile detection for cursor effects (disabled on touch devices)
- Font loading detection for text animations
- Landing page scroll-triggered content reveal
- ScrollFloat effect activation on cursor movement across all text elements globally
- LiquidEther background layer rendered at outer page level on all pages
- Validation error messages display based on input state
- Fight! button disabled state until both hook inputs are valid
- History search results display
- History filter active state indicators (enhanced with follower tier filter)
- Empty state message when no history matches filters
- Pagination controls based on total history count
- Google authentication button display on Sign Up and Login pages
- AI Search Assistant conversation history display
- Suggested question chips visibility
- AI Content Detector gradient scale and detected indicators visibility
- Humanization suggestions display
- Strengths & Weaknesses Analysis split-screen display
- Paragraph Structure Analysis metrics and recommendations display

### 7.6 Image Assets
- {F40BBFFA-A301-46BC-B01B-7246992E4F0E}.png: Content image displayed in landing page second viewport after ScrollFloat animation
- {EC6EE972-DA5D-4F38-AA9A-8F7BEF6F34ED}.png: Reference image showing Creator Training Database with niche-specific creator mapping

### 7.7 LiquidEther Integration Requirements
- LiquidEther component must be integrated at the outer page level as a fixed background layer (z-index below content)
- Applied globally across all pages at outer page level: Landing, Authentication, Dashboard, Hook Lab, History, Profile, Admin Panel
- Container styling at outer page level: position fixed, top 0, left 0, width 100%, height 100%, pointer-events none for background layer
- Content layers must have transparent or semi-transparent backgrounds to allow LiquidEther effect visibility
- Automatic pause/resume based on page visibility and intersection observer
- Responsive resize handling with debounced updates
- Performance optimization: automatic rendering pause when page not visible
- Implementation location: Outer page wrapper component (e.g., App.tsx or root layout component) to ensure effect spans entire application
- **Import statement**: import LiquidEther from './LiquidEther';
- **Usage**: Place LiquidEther component at the root level of App.tsx or main layout component, outside all page content containers

### 7.8 Input Validation Requirements
- Authentication Pages:
  - Email validation: Must match standard email regex pattern
  - Password validation: Minimum 8 characters, at least one uppercase, one lowercase, one number
  - Name validation: Minimum 2 characters
  - LinkedIn follower count validation: Must be non-negative integer
  - Industry/niche validation: Required field for creator mapping
  - Real-time validation feedback with inline error messages
  - Google authentication: Automatic validation bypass for email/password when using Google login
- Hook Lab:
  - Hook Option A validation: Required field, 5-200 characters
  - Hook Option B validation: Required field, 5-200 characters
  - Character count display for both inputs
  - Fight! button disabled until both inputs pass validation
  - Clear error messaging for validation failures
- **Image Upload**:
  - File format validation: JPEG, PNG, GIF only
  - File size validation: Maximum 5MB per image
  - Multiple image upload support with individual validation
  - Real-time validation feedback with error messages
  - Preview generation after successful validation
- **AI Search Assistant**:
  - Question input validation: Minimum 3 characters required
  - Maximum question length: 500 characters
  - Real-time character count display
  - Submit button disabled until input passes validation
  - Error message for empty or invalid questions
- **Adjustable Follower Count Input Box (NEW)**:
  - Input validation: Must be non-negative integer
  - Minimum value: 0
  - Maximum value: 10,000,000 (10 million)
  - Real-time validation feedback
  - Error message for invalid input (non-numeric, negative, exceeds max)
  - Automatic score recalculation on valid input change
- Validation error message styling: Red text, displayed below input field, fade-in animation
- Success state styling: Green border on valid input fields

### 7.9 History Management Requirements
- Data persistence: All analyzed posts stored in history.json with user association
- Storage structure per history entry:
  - Unique entry ID
  - User ID reference
  - Full post text content
  - Uploaded image references with impression predictions
  - Viral score (with stricter distribution)
  - Follower count at time of analysis
  - Follower tier at time of analysis
  - Follower adjustment percentage
  - Component breakdown scores (including paragraph structure)
  - Hook-Refiner alternatives (3 hooks with predictions and AI insights)
  - The 5 Flaw Audit results (5 flaws with fixes and AI insights)
  - Scanning Score (with paragraph length analysis)
  - Hashtag suggestions (3-5 hashtags with metrics and AI alternatives)
  - Image performance data with impression boost predictions
  - **AI-generated content detection score (0-100%)**
  - **Detected AI indicators list**
  - **Humanization suggestions**
  - **Strengths & Weaknesses Analysis results (3-5 strengths and weaknesses)**
  - **Paragraph Structure Analysis results (metrics and recommendations)**
  - AI-powered improvement insights for all components (enhanced with image optimization and follower growth strategies)
  - Niche category
  - Analysis timestamp
  - Improvement recommendations
- Search functionality:
  - Real-time search across post text content
  - Keyword matching with highlighting
  - Case-insensitive search
- Filter functionality:
  - Date range filtering with calendar picker
  - Score range filtering with slider (0-90%)
  - Niche category filtering with dropdown
  - **Follower tier filtering**: All, <500, 2K-12K, 12K-40K, 40K-100K, 100K+
  - Multiple filters can be applied simultaneously
- Sort functionality:
  - Sort by date (ascending/descending)
  - Sort by score (ascending/descending)
  - Default sort: newest first
- Pagination:
  - Display 10 entries per page
  - Page navigation controls
  - Total count display
- Export functionality:
  - Export filtered results to CSV or JSON
  - Include all entry details in export (including follower adjustment, image performance data, AI detection scores, Strengths & Weaknesses Analysis, and Paragraph Structure Analysis)
- Delete functionality:
  - Individual entry deletion with confirmation dialog
  - Soft delete with recovery option (optional)
- Performance optimization:
  - Lazy loading for large datasets
  - Debounced search input
  - Cached filter results

### 7.10 Enhanced Module Integration Requirements
- AI-Powered Improvement Insights Module (ENHANCED):
  - Generate comprehensive insights for all components after analysis
  - Provide specific, actionable recommendations with examples
  - Calculate expected score boost for each suggestion
  - **Include image optimization recommendations with impression predictions**
  - **Include follower growth strategy recommendations**
  - Display insights in dedicated section on dashboard
  - Include insights in history storage and export
  - **Enhanced Visual Styling**: Subtle gradient glow background with animated light particles, Electric Blue to Signal Green gradient overlay, soft pulsing glow effect, glassmorphism card with enhanced backdrop blur, gradient border with animated shimmer effect, inner glow shadow for depth perception, floating light particles in background using CSS animations or WebGL
- Hook-Refiner Module:
  - Automatic hook extraction (first 2 lines)
  - Generate 3 alternatives using AI model trained on 34k+ viral posts
  - Calculate engagement boost predictions based on hook type performance data
  - Generate AI-powered optimization insights for each alternative
  - Display side-by-side comparison with original hook
  - **Enhanced Visual Styling**: Subtle gradient glow background with animated light particles
- The 5 Flaw Audit Module:
  - Run 5 specific flaw checks on every analysis
  - Provide line-number references for each flaw
  - Generate brutally honest but actionable feedback
  - Generate AI-powered insights for systematic flaw elimination
  - Professional yet punchy tone in explanations
  - **Enhanced Visual Styling**: Subtle gradient glow background with animated light particles
- See More Button Predictor (Enhanced):
  - Calculate character position for LinkedIn truncation
  - **Display dotted line indicator at ~210-220 characters in text editor**
  - **Dotted line disappears when text exceeds truncation point**
  - Flag as flaw if hook extends past cutoff
  - Support both desktop (~210-220 chars) and mobile (~140 chars) calculations
  - Generate AI-powered restructuring suggestions
- Scanning Score Calculator (Enhanced):
  - Real-time calculation: Total Lines / Paragraphs
  - Color-coded display (Green: 2-3 lines, Yellow: 3-4 lines, Red: > 4 lines)
  - Integration with X-Ray Mode for visual feedback
  - Flag Readability Flaw if average > 3 lines per paragraph
  - Apply penalties for paragraphs > 4 lines
  - Generate AI-powered paragraph restructuring recommendations
- Hashtag Suggestion Engine:
  - AI-powered recommendations based on content + niche + trends
  - Display 3-5 hashtags with relevance scores and reach estimates
  - One-click copy functionality
  - Generate AI-powered alternative hashtag suggestions with reasoning
  - Integration with training data for performance predictions
  - **Enhanced Visual Styling**: Subtle gradient glow background with animated light particles
- Niche-Specific Creator Mapping:
  - Display relevant creators after user login completion
  - Map user's selected industry/niche to creators from training dataset
  - Show creator names in dedicated column on profile page
  - Update mapping when user changes niche selection
- Training Data Marquee:
  - Display horizontal scrolling marquee on dashboard
  - Show training data statistics and metrics
  - Continuous animation with glassmorphism styling
  - Position below header or above main content area
- **Countdown Timer Module**:
  - Trigger countdown immediately when Analyze Reach button is clicked
  - Display 30-second reverse countdown with calendar page-flip animation
  - Run countdown in parallel with AI analysis process
  - Auto-stop and fade out as soon as viral score calculation completes
  - Handle incomplete countdown scenarios (analysis finishes before 30 seconds)
  - Handle overtime scenarios (analysis exceeds 30 seconds)
  - Integrate with scorer.ts to detect analysis completion status
  - Provide visual feedback during analysis process
- **Google Authentication Module**:
  - Integrate OSS Google login on Sign Up and Login pages
  - One-click authentication flow
  - Automatic profile data population from Google account
  - Session management for Google-authenticated users
  - Fallback to traditional email/password authentication
  - Post-authentication data collection (LinkedIn follower count, industry/niche)
- **Follower-Based Scoring Module (Enhanced)**:
  - Fetch LinkedIn follower count from user profile
  - Calculate follower tier based on configured thresholds
  - Apply score adjustment based on follower tier
  - Display follower adjustment in score breakdown
  - **Provide adjustable follower count input box for real-time score simulation**
  - **Recalculate score dynamically when user adjusts follower count**
  - Store follower data in history for tracking tier progression
  - Admin controls for configuring tier thresholds and adjustment percentages
- **Image Upload and Analysis Module**:
  - Drag-and-drop image upload functionality
  - Multiple image support with individual validation
  - Image preview with remove/replace options
  - AI-powered image analysis for quality and relevance
  - Impression boost prediction for each image
  - Aggregated impression boost calculation
  - Display image performance in score breakdown
  - AI-powered image improvement suggestions
  - Integration with overall viral score calculation
- **AI Search Assistant Module**:
  - Interactive search interface for post-analysis Q&A
  - Natural language question processing
  - Contextual AI responses based on analysis data
  - Conversation history management
  - Suggested questions generation
  - Real-time typing indicator during response generation
  - Integration with all analysis components (scores, breakdowns, insights)
  - Reference to training data patterns and best practices
  - Clear conversation functionality
  - Collapsible panel for space optimization
- **AI-Generated Content Detection Module (NEW)**:
  - Multi-factor analysis algorithm detecting AI-generated content patterns
  - Pattern categories analyzed:
    + Robotic structure and formatting (Hook-Body-CTA formula, uniform sentence length, perfect spacing)
    + Language tics and buzzwords (corporate bingo words, cliché phrases, over-the-top enthusiasm)
    + Experience gap (vague anecdotes, lack of opinion, fact hallucinations)
    + Visual and technical indicators (emoji overload, comment test patterns)
    + Em dash obsession (double definition, mid-sentence pivot, perfect symmetry)
    + Emoji usage patterns (keyword mirroring, bullet point replacement, placement logic)
    + Human touch absence (low-utility details, self-deprecation, sarcasm/slang, contradictions)
  - AI likelihood score calculation (0-100%)
  - Gradient scale display from green (human) to red (AI)
  - Detected indicators list with explanations
  - Humanization suggestions generation
  - Integration with AI-Powered Improvement Insights
  - Storage in post history for tracking trends
  - Display in dedicated section after analysis completes
- **Strengths & Weaknesses Analysis Module (NEW)**:
  - Automatically identifies 3-5 key strengths in the post
  - Automatically identifies 3-5 key weaknesses in the post
  - Analysis based on multiple dimensions:
    + Hook effectiveness
    + Content structure and readability
    + Grammar and formatting consistency
    + CTA clarity and placement
    + Mobile optimization considerations
    + Engagement trigger effectiveness
    + Niche alignment and audience relevance
  - Split-screen display with green checkmarks for strengths and red X icons for weaknesses
  - Integration with AI-Powered Improvement Insights
  - Storage in post history for tracking improvement trends
  - Display in dedicated section after analysis completes
- **Paragraph Structure Analysis Module (NEW)**:
  - Calculates total number of paragraphs in the post
  - Calculates average lines per paragraph (Total Lines / Paragraphs)
  - Counts paragraphs exceeding 4 lines
  - Generates specific recommendations for improving paragraph structure
  - Identifies dense paragraphs and suggests breaking them down
  - Recommends bullet points or shorter paragraphs for better readability
  - Color-coded indicators (Green/Yellow/Red) based on paragraph structure quality
  - Integration with Scanning Score Calculator and The 5 Flaw Audit
  - Storage in post history for tracking paragraph structure trends
  - Display in dedicated section after analysis completes

### 7.11 Stricter Scoring System Implementation (Enhanced with Follower Adjustment)
- Score distribution enforcement:
  - 90%+: Top 5-10% of posts only (near-perfect execution required)
  - 80-89%: Top 15-20% of posts (strong fundamentals)
  - 70-79%: Top 30-40% of posts (decent with improvement areas)
  - 60-69%: Middle 20-30% of posts (average quality)
  - Below 60%: Requires significant optimization
- AI-powered deep analysis for each post:
  - Semantic coherence evaluation
  - Emotional resonance detection
  - Value proposition clarity assessment
  - Audience alignment precision measurement
  - Engagement trigger effectiveness analysis
  - Content uniqueness scoring
  - **Image quality and relevance assessment**
  - **AI-generated content pattern detection**
- Reduced base point values for all scoring rules
- Increased penalty severity for violations
- Paragraph structure penalties: -10 points per paragraph > 4 lines
- Wall of text penalty: -20 points for poor overall structure
- **Follower-based adjustment applied after base score calculation**
- **Real-time score recalculation when user adjusts follower count manually**
- Admin controls for adjusting strictness parameters and follower tier configurations
- Real-time score recalculation with stricter thresholds and follower adjustment

### 7.12 Countdown Timer Implementation Requirements
- **Component Structure**:
  - Standalone React component: CountdownTimer.tsx
  - Props: onComplete (callback function), analysisStatus (boolean)
  - State management: currentNumber (30→0), isActive (boolean), isVisible (boolean)
- **Animation Implementation**:
  - GSAP library for 3D page-flip animation
  - Transform properties: rotateX(-180deg to 0deg for bottom-to-top flip)
  - Perspective: 1000px for 3D depth effect
  - Animation duration: 0.6 seconds per number change
  - Easing function: power2.inOut for smooth transitions
- **Timing Logic**:
  - setInterval with 1-second intervals for countdown progression
  - useEffect hook to monitor analysisStatus prop changes
  - Cleanup function to clear interval on component unmount
  - Auto-stop condition: analysisStatus === true triggers countdown stop
- **Visual Styling**:
  - Container: Glassmorphism card with backdrop-blur-md
  - Number display: Font size 64px, font-weight 700, JetBrains Mono font
  - Background: rgba(255, 255, 255, 0.05) with 1px border rgba(255, 255, 255, 0.1)
  - Color: Electric Blue (#2563EB) for countdown numbers
  - Shadow: Dynamic box-shadow following flip animation
- **Integration Points**:
  - Trigger: Analyze Reach button onClick event
  - Position: Centered overlay or positioned near Score Gauge component
  - Z-index: Above dashboard content but below modals
  - Fade-out animation: 0.5 seconds opacity transition on completion
- **Edge Case Handling**:
  - Early completion: Stop countdown immediately, trigger fade-out
  - Overtime: Complete countdown to 0, disappear, allow analysis to continue
  - User navigation: Pause countdown if user leaves dashboard page
  - Multiple analyses: Reset countdown state on new analysis trigger
- **Performance Optimization**:
  - Use requestAnimationFrame for smooth animation rendering
  - Debounce analysisStatus checks to avoid excessive re-renders
  - Lazy load GSAP animation library only when countdown is active
  - Clean up event listeners and intervals on component unmount

### 7.13 Google Authentication Integration Requirements
- **Authentication Flow**:
  - Display Google Sign-Up/Login button on both Sign Up and Login pages
  - Use OSS Google login method for authentication
  - Redirect to Google OAuth consent screen
  - Receive authentication token and user profile data
  - Create or retrieve user account in system
  - Establish user session with token management
- **Data Handling**:
  - Automatically populate name and email from Google account
  - Prompt user to provide LinkedIn follower count after Google authentication
  - Prompt user to select industry/niche for creator mapping
  - Store Google authentication token securely
  - Link Google account to user profile in users.json
- **UI Components**:
  - GoogleAuthButton component with Google branding
  - Loading state during authentication process
  - Error handling for failed authentication attempts
  - Success feedback after successful login
- **Security Requirements**:
  - Secure token storage and transmission
  - Session timeout and refresh token handling
  - CSRF protection for authentication requests
  - Secure API endpoints for Google authentication
- **Fallback Handling**:
  - Traditional email/password authentication remains available
  - Clear separation between Google-authenticated and email-authenticated users
  - Account linking option for users who want to add Google authentication to existing accounts
- **Post-Authentication Flow**:
  - Redirect to dashboard after successful authentication
  - Display niche-specific creator column based on selected industry
  - Enable all platform features immediately after authentication completion

### 7.14 Supabase Backend Integration
- **Supabase Configuration**:
  - Project URL: https://cgaavihuckojsrolsapn.supabase.co
  - Publishable Key: sb_publishable_6Wg7fS0XmLaM6Mjo-daS1w_tELGDRCd
  - Direct Connection String: postgresql://postgres:[YOUR-PASSWORD]@db.cgaavihuckojsrolsapn.supabase.co:5432/postgres
- **Backend Connection Setup**:
  - Create supabaseClient.ts file to initialize Supabase client
  - Configure authentication with provided publishable key
  - Set up database connection using direct connection string
  - Implement secure environment variable management for sensitive credentials
- **Database Schema Requirements**:
  - Users table: Store user account data (name, email, LinkedIn follower count, follower tier, industry/niche, Google auth data)
  - Posts table: Store analyzed post history (post text, scores, timestamps, component breakdowns, follower adjustment data, image performance data, AI detection scores, Strengths & Weaknesses Analysis, Paragraph Structure Analysis)
  - Streaks table: Store daily activity tracking and streak records
  - Training_data table: Store golden post examples and performance metrics
  - Hashtags table: Store trending hashtags by niche with performance data
  - **Images table**: Store uploaded images with analysis results and impression predictions
  - **Follower_tiers table**: Store follower tier configuration and adjustment percentages
  - **AI_detection_patterns table (NEW)**: Store AI-generated content detection patterns, indicators, and scoring weights
  - **Strengths_weaknesses_templates table (NEW)**: Store templates and criteria for identifying post strengths and weaknesses
- **API Integration Points**:
  - User authentication: Sign up, login, Google OAuth integration
  - Post analysis: Store and retrieve analysis results with follower adjustment, image performance data, AI detection scores, Strengths & Weaknesses Analysis, and Paragraph Structure Analysis
  - History management: Search, filter (including follower tier filter), sort, and export post history
  - Streak tracking: Update and retrieve daily activity data
  - Niche creator mapping: Retrieve relevant creators based on user's industry
  - **Image upload and storage: Store uploaded images and retrieve analysis results**
  - **Follower tier management: Retrieve and update follower tier configurations**
  - **AI detection pattern retrieval: Fetch AI detection patterns and scoring weights**
  - **Strengths & Weaknesses template retrieval: Fetch templates and criteria for analysis**
- **Security Implementation**:
  - Row Level Security (RLS) policies for user data isolation
  - Secure API key management
  - Authentication token validation
  - HTTPS-only connections
  - Input sanitization and validation
  - **Image file validation and secure storage**
- **Real-time Features**:
  - Real-time score updates during analysis
  - Live streak counter updates
  - Instant history synchronization across devices
  - **Real-time image upload progress tracking**
  - **Real-time score recalculation when follower count is adjusted**
- **Migration from JSON Files**:
  - Migrate users.json data to Supabase Users table (including follower count and tier)
  - Migrate history.json data to Supabase Posts table (including follower adjustment, image performance data, AI detection scores, Strengths & Weaknesses Analysis, and Paragraph Structure Analysis)
  - Migrate streak_data.json to Supabase Streaks table
  - Migrate training_data.json to Supabase Training_data table
  - Migrate hashtag_database.json to Supabase Hashtags table
  - **Migrate follower_tier_config.json to Supabase Follower_tiers table**
  - **Migrate impression_boost_data.json to Supabase**
  - **Migrate ai_detection_patterns.json to Supabase AI_detection_patterns table**
  - **Migrate strengths_weaknesses_templates.json to Supabase Strengths_weaknesses_templates table**
- **Error Handling**:
  - Connection failure fallback mechanisms
  - Retry logic for failed requests
  - User-friendly error messages
  - Logging for debugging and monitoring
  - **Image upload failure handling with retry mechanism**

### 7.15 Follower-Based Scoring Implementation Requirements (Enhanced)
- **Follower Tier Configuration**:
  - Tier 1: Less than 500 followers → -4% adjustment
  - Tier 2: 2,000 to 12,000 followers → +4% adjustment
  - Tier 3: 12,000 to 40,000 followers → +7% adjustment
  - Tier 4: 40,000 to 100,000 followers → +10% adjustment
  - Tier 5: 100,000+ followers → +15% adjustment
  - Admin-configurable thresholds and adjustment percentages
- **Score Calculation Logic**:
  - Fetch user's LinkedIn follower count from profile
  - Determine follower tier based on count
  - Calculate base viral score using existing algorithm
  - Apply follower adjustment: Adjusted Score = Base Score * (1 + Adjustment Percentage)
  - Ensure final score does not exceed 90% cap
  - Store both base score and adjusted score in history
  - **Real-time recalculation when user manually adjusts follower count**
- **UI Display Requirements**:
  - Follower tier badge displayed prominently in score breakdown
  - Adjustment percentage shown with visual indicator (e.g., +4% Boost)
  - Explanation tooltip: Your follower count (X followers) adds/reduces Y% to your viral score
  - Breakdown showing: Base Score → Follower Adjustment → Final Score
  - Color-coded tier badges (e.g., Bronze for <500, Silver for 2K-12K, Gold for 12K-40K, Platinum for 40K-100K, Diamond for 100K+)
  - **Adjustable Follower Count Input Box**:
    + Positioned in follower adjustment section
    + Input field with validation (non-negative integer, max 10,000,000)
    + Real-time score recalculation on valid input change
    + Visual feedback showing score change as user adjusts follower count
    + Reset button to restore original follower count from profile
- **History Integration**:
  - Store follower count at time of analysis
  - Store follower tier at time of analysis
  - Store adjustment percentage applied
  - Enable filtering by follower tier in history page
  - Track follower tier progression over time
- **Admin Controls**:
  - Sliders to adjust tier thresholds
  - Input fields to modify adjustment percentages
  - Real-time preview of adjustment impact on sample scores
  - Save/reset configuration buttons
- **Data Persistence**:
  - Store follower tier configuration in follower_tier_config.json or Supabase Follower_tiers table
  - Update user profile with current follower tier
  - Log tier changes for analytics

### 7.16 Image Upload and Analysis Implementation Requirements
- **Upload Functionality**:
  - Drag-and-drop upload area positioned below Drafting Board
  - Click-to-upload alternative for users who prefer traditional file selection
  - Multiple image upload support (up to 5 images per post)
  - Real-time upload progress indicators
  - Image preview thumbnails after successful upload
  - Remove/replace individual images functionality
- **Validation Requirements**:
  - File format validation: Accept only JPEG, PNG, GIF
  - File size validation: Maximum 5MB per image
  - Total upload size limit: 20MB for all images combined
  - Dimension validation: Minimum 200x200 pixels, maximum 4000x4000 pixels
  - Real-time validation feedback with error messages
- **Image Analysis Logic**:
  - AI-powered analysis for each uploaded image:
    + Relevance to post content (0-100% score)
    + Visual quality assessment (resolution, clarity, composition)
    + Professional appearance evaluation
    + Color scheme alignment with brand (if applicable)
    + Text readability (if image contains text)
    + Infographic effectiveness (if applicable)
  - Calculate individual image score (0-100%)
  - Predict impression boost percentage for each image
  - Aggregate impression boost from all images
- **Impression Boost Calculation**:
  - Formula: Impression Boost = (Image Quality Score * Relevance Score * Historical Performance Factor) / 100
  - Historical Performance Factor based on training data:
    + High-quality infographics: 1.4x multiplier
    + Professional photos: 1.3x multiplier
    + Screenshots with annotations: 1.2x multiplier
    + Generic stock photos: 1.1x multiplier
    + Low-quality images: 0.9x multiplier
  - Display predicted impression increase as percentage (e.g., +18% impressions)
- **UI Display Requirements**:
  - Image Performance Section in diagnostics panel
  - Individual image cards showing:
    + Thumbnail preview
    + Quality score (0-100%)
    + Relevance score (0-100%)
    + Predicted impression boost (e.g., +12%)
    + AI-powered improvement suggestions
  - Aggregated impression boost displayed prominently
  - Visual indicator showing highest-performing image
  - Comparison feature: Score with vs without images
- **Integration with Viral Score**:
  - Image quality contributes to Media Quality component (existing)
  - Impression boost prediction displayed separately in breakdown
  - Overall score calculation includes image contribution
  - AI insights include image optimization recommendations
- **History Storage**:
  - Store uploaded image references in history
  - Store individual image scores and impression predictions
  - Store aggregated impression boost
  - Enable filtering and sorting by image performance in history
- **Performance Optimization**:
  - Lazy loading for image previews
  - Compressed image storage
  - Asynchronous image analysis to avoid blocking UI
  - Caching of analysis results for re-analyzed posts

### 7.17 AI Search Assistant Implementation Requirements
- **Component Structure**:
  - Standalone React component: AISearchAssistant.tsx
  - Props: analysisData (object containing all analysis results), isVisible (boolean)
  - State management: conversationHistory (array), currentQuestion (string), isLoading (boolean), suggestedQuestions (array)
- **Question Processing Logic**:
  - Natural language processing to understand user intent
  - Context extraction from current analysis data
  - Question categorization (hook, paragraph, image, score, general)
  - Reference to relevant analysis components based on question type
- **Response Generation**:
  - AI-powered contextual responses using analysis data
  - Specific references to scores, breakdowns, and insights
  - Actionable recommendations with examples
  - Follow-up question suggestions based on user query
  - Real-time typing indicator during response generation
- **Suggested Questions**:
  - Dynamic generation based on analysis results
  - Common question templates:
    + Why did my post receive this score?
    + How can I improve my hook?
    + What are the best hashtags for my niche?
    + Why is my paragraph structure flagged?
    + How can I increase my impression boost?
    + What changes would increase my viral score the most?
    + How does my follower count affect my score?
    + Which image performs best and why?
  - Clickable chips for quick question submission
- **Conversation Management**:
  - Store conversation history in component state
  - Display Q&A pairs in chronological order
  - Auto-scroll to latest message
  - Clear conversation functionality
  - Persistent conversation across dashboard navigation (optional)
- **UI Components**:
  - Search input field with placeholder text
  - Submit button (disabled until input is valid)
  - Conversation history container with scrollable area
  - Message bubbles (user questions in Electric Blue, AI responses in Signal Green)
  - Suggested question chips displayed prominently
  - Clear conversation button
  - Collapsible panel toggle for space optimization
- **Integration Points**:
  - Access to full analysis data (scores, breakdowns, insights, follower adjustment, image performance)
  - Reference to training data patterns and best practices
  - Connection to Hook-Refiner, 5 Flaw Audit, Scanning Score, and other module results
  - Ability to reference uploaded images and their performance
- **Display Position**:
  - Positioned below main score gauge or in dedicated tab
  - Collapsible panel to save screen space when not in use
  - Persistent across dashboard navigation after analysis
- **Styling**:
  - Glassmorphism card design consistent with platform theme
  - Electric Blue accent for user questions
  - Signal Green accent for AI responses
  - Smooth fade-in animation for new messages
  - Scrollable conversation history with auto-scroll to latest message
- **Validation**:
  - Minimum question length: 3 characters
  - Maximum question length: 500 characters
  - Real-time character count display
  - Submit button disabled until input passes validation
  - Error message for empty or invalid questions
- **Performance Optimization**:
  - Debounced input handling
  - Lazy loading of conversation history
  - Caching of common question responses
  - Asynchronous response generation to avoid blocking UI

### 7.18 AI-Generated Content Detection Implementation Requirements (NEW)
- **Component Structure**:
  - Standalone React component: AIContentDetector.tsx
  - Props: postText (string), analysisData (object)
  - State management: aiScore (0-100), detectedIndicators (array), humanizationSuggestions (array), isVisible (boolean)
- **Detection Algorithm Logic**:
  - Multi-factor analysis processing:
    + **Robotic Structure Detection**:
      - Identify Hook-Body-CTA formula patterns
      - Analyze sentence length uniformity (calculate variance)
      - Detect perfect spacing and zero typos/casual grammar quirks
    + **Language Tics Detection**:
      - Scan for corporate buzzwords: delve, unlock, unleash, navigate, landscape, dynamic, multifaceted, transformative, tapestry
      - Identify cliché phrases: In today's fast-paced digital world, It's important to note that
      - Detect over-the-top enthusiasm patterns: excited to share, humbled to announce
    + **Experience Gap Analysis**:
      - Identify vague anecdotes lacking specific details (dates, names, locations)
      - Detect lack of strong opinions or controversial stances
      - Check for fact hallucinations or unsourced statistics
    + **Visual & Technical Indicators**:
      - Analyze emoji overload and placement patterns
      - Detect emoji-keyword mirroring (💡 with idea, 💼 with business)
    + **Em Dash Obsession Detection**:
      - Count em dash usage frequency (> 2 em dashes = red flag)
      - Identify double definition patterns using em dashes
      - Detect perfect symmetry in em dash spacing
    + **Emoji Usage Patterns**:
      - Identify keyword mirroring
      - Detect bullet point replacement with professional emojis (✅, ➡️, 🔵)
      - Analyze emoji placement logic (exclusively at sentence end)
    + **Human Touch Absence**:
      - Detect lack of low-utility personal details
      - Identify absence of self-deprecation or genuine vulnerability
      - Check for missing sarcasm, slang, sentence fragments, or contradictions
  - AI likelihood score calculation:
    + Weighted scoring based on detected patterns
    + Score range: 0-100%
    + Thresholds: 0-20% (Likely Human), 21-50% (Possibly Human with AI), 51-80% (Likely AI), 81-100% (Highly likely AI)
- **UI Display Requirements**:
  - **Gradient Scale Display**:
    + Horizontal gradient bar from Signal Green (#10B981) on left to Warning Red (#EF4444) on right
    + Smooth color transition across gradient
    + Marker indicating AI likelihood percentage (0-100%)
    + Bold percentage display at marker position
    + Color zones: Green (0-20%), Yellow (21-50%), Orange (51-80%), Red (81-100%)
  - **Detected AI Indicators Section**:
    + List format with icons for each detected pattern
    + Pattern name and brief explanation
    + Examples from the analyzed post
    + Severity indicator (Low/Medium/High)
  - **Humanization Suggestions Section**:
    + Numbered list of actionable recommendations
    + Specific examples of how to make content sound more human
    + Expected impact on AI detection score
    + Integration with AI-Powered Improvement Insights
- **Integration Points**:
  - Access to full post text for pattern analysis
  - Reference to ai_detection_patterns.json for scoring weights
  - Connection to AI-Powered Improvement Insights module
  - Storage in post history for tracking AI detection trends
  - Display in dedicated section after analysis completes
- **Display Position**:
  - Positioned below Scanning Score or in dedicated collapsible section
  - Collapsible panel to save space when not needed
  - Persistent across dashboard navigation after analysis
- **Styling**:
  - Glassmorphism card design consistent with platform theme
  - Gradient scale with clear color transitions
  - Bold percentage display at marker position
  - List format for detected indicators with icons
  - Actionable suggestions displayed as numbered list
  - Smooth fade-in animation when section appears
- **Data Persistence**:
  - Store AI detection score in post history
  - Store detected indicators list
  - Store humanization suggestions
  - Enable filtering and sorting by AI detection score in history
- **Performance Optimization**:
  - Asynchronous pattern analysis to avoid blocking UI
  - Caching of detection results for re-analyzed posts
  - Debounced analysis trigger
  - Lazy loading of ai_detection_patterns.json

### 7.19 See More Dotted Line Indicator Implementation Requirements (NEW)
- **Component Structure**:
  - Standalone React component: SeeMoreIndicator.tsx
  - Props: textContent (string), characterLimit (number, default 210)
  - State management: isVisible (boolean), linePosition (number)
- **Visual Design Specifications**:
  - Line style: 2px dashed border in Warning Orange (#F59E0B)
  - Line width: Full width of text editor area
  - Label text: See More (~210 chars) displayed near the line
  - Label styling: Small font size (12px), Warning Orange color, positioned to the right of the line
  - Z-index: Positioned above text but below cursor and selection highlights
  - Semi-transparent to avoid obstructing text readability
- **Dynamic Behavior Logic**:
  - Character count tracking:
    + Real-time monitoring of text input changes
    + Calculate character count including spaces
    + Trigger visibility changes based on character count
  - Visibility rules:
    + Appears when text length is below 210 characters
    + Disappears with smooth fade-out animation (0.3 seconds) when text exceeds 210-220 characters
    + Reappears with fade-in animation if text is reduced below 210 characters
  - Position calculation:
    + Calculate exact vertical position based on character count and line height
    + Adjust position dynamically as user types
    + Account for line breaks and paragraph spacing
- **Integration Points**:
  - Integrated into Drafting Board text editor component
  - Works in conjunction with See More Button Predictor logic (seeMoreCalculator.ts)
  - Coordinates with X-Ray Mode for visual consistency
- **Animation Specifications**:
  - Fade-in animation: 0.3 seconds, ease-in-out
  - Fade-out animation: 0.3 seconds, ease-in-out
  - Position transition: 0.2 seconds, ease-out (when line moves due to text changes)
- **Technical Implementation**:
  - CSS border-style: dashed for dotted line effect
  - React state to track character count and line visibility
  - GSAP or CSS transitions for smooth fade-in/fade-out animations
  - Event listeners for text input changes to update position and visibility
  - useEffect hook to monitor textContent prop changes
  - Cleanup function to remove event listeners on component unmount
- **Edge Case Handling**:
  - Handle rapid typing: Debounce position updates to avoid excessive re-renders
  - Handle paste operations: Immediately recalculate position and visibility
  - Handle line breaks: Adjust position calculation to account for multi-line text
  - Handle empty text: Hide indicator when text is empty
- **Performance Optimization**:
  - Debounce character count updates (100ms delay)
  - Use requestAnimationFrame for smooth position updates
  - Memoize position calculation to avoid redundant computations
  - Lazy render: Only render when text editor is active

### 7.20 Adjustable Follower Count Input Box Implementation Requirements (NEW)
- **Component Structure**:
  - Integrated into Follower Adjustment Display section
  - Input field component: AdjustableFollowerInput.tsx
  - Props: currentFollowerCount (number), onFollowerCountChange (callback function)
  - State management: inputValue (number), isValid (boolean), errorMessage (string)
- **UI Design Specifications**:
  - Input field styling:
    + Width: 150px
    + Height: 40px
    + Border: 1px solid Electric Blue (#2563EB)
    + Background: Glassmorphism effect (blur-md, white/5 opacity)
    + Font: JetBrains Mono, 16px
    + Placeholder text: Enter follower count
  - Label text: Adjust Follower Count displayed above input field
  - Reset button: Small button next to input field to restore original follower count
  - Visual feedback:
    + Green border when input is valid
    + Red border when input is invalid
    + Error message displayed below input field in red text
- **Validation Logic**:
  - Input validation rules:
    + Must be non-negative integer
    + Minimum value: 0
    + Maximum value: 10,000,000 (10 million)
    + No decimal points allowed
    + No special characters allowed
  - Real-time validation:
    + Validate on every input change
    + Display error message immediately if validation fails
    + Disable score recalculation until input is valid
  - Error messages:
    + Please enter a valid number (for non-numeric input)
    + Follower count cannot be negative (for negative values)
    + Follower count cannot exceed 10,000,000 (for values > 10 million)
- **Score Recalculation Logic**:
  - Trigger recalculation on valid input change:
    + Debounce input changes (500ms delay) to avoid excessive recalculations
    + Call followerAdjuster.ts to calculate new follower tier and adjustment
    + Call scorer.ts to recalculate viral score with new follower adjustment
    + Update all score displays in real-time
  - Visual feedback during recalculation:
    + Loading spinner or animation near score gauge
    + Smooth transition animation for score change
    + Highlight follower adjustment section to show updated values
- **Integration Points**:
  - Positioned in Follower Adjustment Display section below follower tier badge
  - Connected to followerAdjuster.ts for tier calculation
  - Connected to scorer.ts for score recalculation
  - Updates all score-related displays (Score Gauge, Component Breakdown, etc.)
  - Does not affect stored follower count in user profile (simulation only)
- **Reset Functionality**:
  - Reset button restores original follower count from user profile
  - Triggers score recalculation with original follower count
  - Clears any error messages
  - Visual feedback: Button glow effect on hover
- **Technical Implementation**:
  - React controlled input component
  - useState hook for input value and validation state
  - useEffect hook to trigger recalculation on valid input change
  - Debounce function to delay recalculation (lodash.debounce or custom implementation)
  - Event handlers for input change, blur, and reset button click
  - Cleanup function to clear debounce timer on component unmount
- **Performance Optimization**:
  - Debounce input changes to avoid excessive recalculations
  - Memoize recalculation function to avoid redundant computations
  - Use React.memo to prevent unnecessary re-renders
  - Lazy load followerAdjuster.ts and scorer.ts only when needed
- **Edge Case Handling**:
  - Handle paste operations: Validate pasted content immediately
  - Handle rapid typing: Debounce validation and recalculation
  - Handle empty input: Display error message and disable recalculation
  - Handle browser autofill: Validate autofilled values

### 7.21 Strengths & Weaknesses Analysis Implementation Requirements (NEW)
- **Component Structure**:
  - Standalone React component: StrengthsWeaknessesAnalysis.tsx
  - Props: postText (string), analysisData (object)
  - State management: strengths (array), weaknesses (array), isVisible (boolean)
- **Analysis Logic**:
  - AI-powered analysis identifying 3-5 key strengths and weaknesses
  - Analysis dimensions:
    + **Hook Effectiveness**: Evaluates hook quality, attention-grabbing power, and clarity
    + **Content Structure**: Assesses paragraph organization, readability, and logical flow
    + **Grammar & Formatting**: Checks for consistency in grammar, capitalization, punctuation
    + **CTA Clarity**: Evaluates call-to-action effectiveness and placement
    + **Mobile Optimization**: Assesses mobile-friendliness and disclaimer placement
    + **Engagement Triggers**: Identifies elements that drive comments and shares
    + **Niche Alignment**: Evaluates relevance to target audience and industry
  - Strength identification criteria:
    + Interactive and unique concepts
    + Strong attention-grabbing hooks
    + Clear incentives for participation
    + Relatable content for target audience
    + Effective use of storytelling or data
  - Weakness identification criteria:
    + Inconsistent grammar, capitalization, or punctuation
    + Poor readability due to dense sentences or long paragraphs
    + Fragmented or weak CTAs
    + Poorly placed disclaimers or mobile optimization issues
    + Lack of engagement triggers or niche misalignment
- **UI Display Requirements**:
  - **Split-Screen Layout**:
    + Left column: Strengths section with green checkmark icons
    + Right column: Weaknesses section with red X icons
    + Equal width for both columns
    + Clear visual separation between columns
  - **Strengths Section**:
    + Section title: Strengths with green checkmark icon
    + List of 3-5 strengths with green checkmark icons
    + Each strength displayed as a separate line item
    + Concise, actionable descriptions
  - **Weaknesses Section**:
    + Section title: Weaknesses with red X icon
    + List of 3-5 weaknesses with red X icons
    + Each weakness displayed as a separate line item
    + Concise, actionable descriptions
- **Integration Points**:
  - Positioned directly below AI Detection Analysis section in diagnostics panel
  - Feeds into AI-Powered Improvement Insights module
  - Stored in post history for tracking improvement trends
  - Referenced in Improvement Recommendations page
  - Connected to The 5 Flaw Audit for cross-validation
- **Display Position**:
  - Positioned directly below AI Detection Analysis section
  - Collapsible section to save space when not needed
  - Persistent across dashboard navigation after analysis
- **Styling**:
  - Glassmorphism card design consistent with platform theme
  - Split-screen layout with clear visual separation
  - Green accent color (#10B981) for Strengths section
  - Red accent color (#EF4444) for Weaknesses section
  - Icon-based bullet points for each item
  - Smooth fade-in animation when section appears
- **Data Persistence**:
  - Store strengths list in post history
  - Store weaknesses list in post history
  - Enable filtering and sorting by strengths/weaknesses in history
- **Performance Optimization**:
  - Asynchronous analysis to avoid blocking UI
  - Caching of analysis results for re-analyzed posts
  - Debounced analysis trigger
  - Lazy loading of strengths_weaknesses_templates.json

### 7.22 Paragraph Structure Analysis Implementation Requirements (NEW)
- **Component Structure**:
  - Standalone React component: ParagraphStructureAnalysis.tsx
  - Props: postText (string), analysisData (object)
  - State management: paragraphCount (number), avgLinesPerPara (number), longParasCount (number), recommendation (string), isVisible (boolean)
- **Analysis Logic**:
  - **Paragraph Metrics Calculation**:
    + Total Paragraphs: Count total number of paragraphs in the post
    + Avg Lines/Para: Calculate average lines per paragraph (Total Lines / Paragraphs)
    + Long Paras: Count paragraphs exceeding 4 lines
  - **Recommendation Generation**:
    + Identify dense paragraphs (> 4 lines)
    + Suggest breaking down long paragraphs into 2-3 shorter paragraphs
    + Recommend using bullet points to highlight key aspects
    + Identify poorly placed disclaimers or small paragraphs that need integration
    + Generate specific, actionable recommendations with examples
  - **Color-Coded Indicators**:
    + Green: Optimal paragraph structure (Avg Lines/Para: 2-3)
    + Yellow: Acceptable paragraph structure (Avg Lines/Para: 3-4)
    + Red: Poor paragraph structure (Avg Lines/Para: > 4 or Long Paras > 0)
- **UI Display Requirements**:
  - **Metrics Display**:
    + Horizontal layout with three key metrics
    + Large, bold numbers (JetBrains Mono font, minimum 32px)
    + Descriptive labels below each number
    + Color-coded indicators based on paragraph structure quality
  - **Recommendation Section**:
    + Positioned below metrics display
    + Displays actionable recommendation text in Warning Orange color
    + Specific examples and suggestions for improvement
    + Clear formatting with line breaks for readability
- **Integration Points**:
  - Positioned directly below Strengths & Weaknesses Analysis section in diagnostics panel
  - Feeds into Scanning Score Calculator (Module 3.13)
  - Referenced in The 5 Flaw Audit (Visual Friction flaw)
  - Stored in post history for tracking paragraph structure trends
  - Integrated into AI-Powered Improvement Insights module
- **Display Position**:
  - Positioned directly below Strengths & Weaknesses Analysis section
  - Collapsible section to save space when not needed
  - Persistent across dashboard navigation after analysis
- **Styling**:
  - Glassmorphism card design consistent with platform theme
  - Horizontal layout for metrics display
  - Large, bold numbers with descriptive labels
  - Color-coded indicators for visual feedback (Green/Yellow/Red)
  - Recommendation text in Warning Orange (#F59E0B) with clear formatting
  - Smooth fade-in animation when section appears
- **Data Persistence**:
  - Store paragraph count in post history
  - Store average lines per paragraph in post history
  - Store long paragraphs count in post history
  - Store recommendation text in post history
  - Enable filtering and sorting by paragraph structure metrics in history
- **Performance Optimization**:
  - Asynchronous analysis to avoid blocking UI
  - Caching of analysis results for re-analyzed posts
  - Debounced analysis trigger
  - Memoize calculation functions to avoid redundant computations

## 8. Additional Requirements

### 8.1 Removed Features
- **See More Character Count Display**: The character count display showing See More (695 chars) has been removed from the UI. The dotted line indicator at ~210-220 characters replaces this functionality.

### 8.2 Enhanced Features
- **See More Button Predictor**: Now includes a dotted line indicator at ~210-220 characters in the text editor, which disappears when text exceeds the truncation point.
- **Follower-Based Scoring**: Now includes an adjustable follower count input box allowing users to simulate score changes based on different follower tiers in real-time.
- **AI-Generated Content Detection**: New feature providing comprehensive analysis of AI-generated content patterns with gradient scale display, detected indicators, and humanization suggestions.
- **Strengths & Weaknesses Analysis (NEW)**: New feature identifying 3-5 key strengths and weaknesses in the post with split-screen display and actionable insights.
- **Paragraph Structure Analysis (NEW)**: New feature displaying paragraph metrics (Paragraphs, Avg Lines/Para, Long Paras) with color-coded indicators and actionable recommendations.
- **AI Insights Visual Enhancement**: All AI Insights sections (Hook-Refiner, 5 Flaw Audit, Hashtag Suggestions, AI-Powered Improvement Insights) now feature enhanced visual styling with subtle gradient glow background, animated light particles, Electric Blue to Signal Green gradient overlay, soft pulsing glow effect, glassmorphism card with enhanced backdrop blur, gradient border with animated shimmer effect, inner glow shadow for depth perception, and floating light particles in background using CSS animations or WebGL.

### 8.3 User Experience Enhancements
- **Real-Time Feedback**: Users receive immediate visual feedback when adjusting follower count, with smooth score transitions and highlighted sections.
- **Visual Clarity**: The dotted line indicator provides clear visual guidance on LinkedIn's See More truncation point without cluttering the UI with character counts.
- **AI Transparency**: The AI Content Detector provides users with insights into how their content may be perceived as AI-generated, helping them create more authentic posts.
- **Comprehensive Analysis**: The Strengths & Weaknesses Analysis and Paragraph Structure Analysis provide users with a holistic view of their post's performance across multiple dimensions.
- **Enhanced Visual Appeal**: The improved AI Insights visual styling creates a more immersive and engaging user experience with subtle animations and gradient effects.

### 8.4 Performance Considerations
- **Debounced Recalculations**: All real-time score recalculations are debounced to prevent excessive computations and ensure smooth UI performance.
- **Lazy Loading**: Heavy components (AI detection, image analysis, Strengths & Weaknesses Analysis, Paragraph Structure Analysis) are lazy-loaded to improve initial page load times.
- **Caching**: Analysis results are cached to avoid redundant computations when users re-analyze the same content.

## 9. Reference Files
- {F40BBFFA-A301-46BC-B01B-7246992E4F0E}.png: Content image for landing page second viewport
- {EC6EE972-DA5D-4F38-AA9A-8F7BEF6F34ED}.png: Reference image showing Creator Training Database with niche-specific creator mapping
# 🚀 Quick Fix: Enable Google Sign-In (2 Steps)

## The Error You're Seeing

```
"Unsupported provider: provider is not enabled"
```

**Translation**: Google OAuth is turned OFF in your Supabase project.

---

## Fix It Now (5 Minutes)

### STEP 1: Get Google Credentials

1. Go to: https://console.cloud.google.com/
2. Create a project (or select existing)
3. Go to: **APIs & Services** → **Credentials**
4. Click: **Create Credentials** → **OAuth 2.0 Client ID**
5. Choose: **Web application**
6. Add this redirect URI:
   ```
   https://upxgbldhftcjldbgdehu.supabase.co/auth/v1/callback
   ```
7. **Copy** the Client ID and Client Secret

### STEP 2: Enable in Supabase

1. Go to: https://supabase.com/dashboard
2. Select project: **upxgbldhftcjldbgdehu**
3. Go to: **Authentication** → **Providers**
4. Find **Google** and click it
5. Toggle: **Enable Sign in with Google** → ON
6. Paste: Your Client ID and Client Secret
7. Click: **Save**

### STEP 3: Test

1. Refresh your app (Ctrl+Shift+R)
2. Click "Continue with Google"
3. ✅ It works!

---

## Detailed Instructions

See: `FIX_GOOGLE_SIGNIN_ERROR.md` for step-by-step guide with screenshots.

---

## Still Not Working?

### Common Issues:

**Issue**: "redirect_uri_mismatch"  
**Fix**: Make sure redirect URI is EXACTLY:
```
https://upxgbldhftcjldbgdehu.supabase.co/auth/v1/callback
```

**Issue**: "Access blocked"  
**Fix**: Configure OAuth consent screen in Google Cloud Console

**Issue**: Still getting "provider is not enabled"  
**Fix**: 
- Make sure you clicked "Save" in Supabase
- Wait 1-2 minutes
- Hard refresh your app (Ctrl+Shift+R)

---

## What You Need

- [ ] Google Cloud Console account (free)
- [ ] Supabase Dashboard access
- [ ] 5 minutes of your time

---

## The Result

After setup, clicking "Continue with Google" will:

1. Redirect to Google's login page
2. Ask for permission
3. Redirect back to your app
4. Log you in automatically
5. Create your profile

---

**Need help?** Check the detailed guide: `FIX_GOOGLE_SIGNIN_ERROR.md`

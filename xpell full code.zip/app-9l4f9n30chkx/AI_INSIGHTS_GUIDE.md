# AI Insights Feature Guide - Xpell

## Overview

Xpell's AI Insights feature uses Gemini 2.5 Flash, trained on 34,000+ viral LinkedIn posts from top creators, to provide comprehensive post analysis and improvement suggestions.

## How It Works

### 1. Analysis Process

When you click "Analyze Reach" with AI-Powered Analysis enabled:

1. **Post Submission**: Your post content is sent to the AI analysis engine
2. **AI Processing**: Gemini 2.5 Flash analyzes your post (takes up to 30 seconds)
3. **Countdown Timer**: Visual 30-second countdown shows analysis progress
4. **Results Display**: Both Standard and AI Insights tabs are populated
5. **Comparison**: Switch between tabs to compare standard vs AI analysis

### 2. What AI Analyzes

#### Viral Score (0-100%)
- **90-100%**: EXCEPTIONAL posts (top 5-10% of all content)
- **80-89%**: Very good posts with minor flaws
- **70-79%**: Good posts with noticeable improvements needed
- **60-69%**: Average posts with several flaws
- **50-59%**: Below average, needs significant work
- **0-49%**: Poor posts with major issues

**Note**: AI uses strict grading. Most posts score 60-75%. Only truly exceptional posts get 90%+.

#### Grade Classification
- Exceptional
- Excellent
- Very Good
- Good
- Fair
- Poor

#### Viral Potential
- Very High
- High
- Medium
- Low

### 3. Analysis Components

#### Key Insights (3 specific insights)
Example:
- ✓ Strong opening hook captures attention immediately
- ✓ Good use of personal storytelling
- ✓ Clear value proposition for the reader

#### Strengths
What your post does well:
- Engaging hook
- Clear structure
- Strong CTA
- Good formatting

#### Weaknesses
Areas needing improvement:
- Hook could be more specific
- Paragraphs too long
- Missing hashtags
- Weak call-to-action

#### Paragraph Analysis
- **Total Paragraphs**: Count of paragraphs in your post
- **Avg Lines/Para**: Average lines per paragraph
- **Long Paras**: Number of paragraphs with >4 lines
- **Recommendation**: Specific advice for paragraph structure

#### Improvement Suggestions

**🎣 Hook Improvement**
How to improve your first 2 lines to capture attention

**📝 Structure Improvement**
How to improve paragraph structure and flow

**✨ Formatting Improvement**
Specific formatting improvements (line breaks, emojis, spacing)

**💬 CTA Improvement**
How to improve your call-to-action

**# Hashtag Suggestions**
3 recommended hashtags for your niche

### 4. Reasoning
2-3 sentences explaining why the AI gave this score

## Requirements

### Authentication Required
- **Why**: AI analysis uses advanced processing and stores your analysis history
- **Benefits**: 
  - Personalized insights based on your niche
  - Analysis history tracking
  - Improved recommendations over time
- **Fallback**: Standard analysis available without login

### AI-Powered Analysis Toggle
- **Location**: Below niche selector (only visible when logged in)
- **Default**: Enabled
- **Purpose**: Control whether to use AI analysis or standard analysis only

## User Interface

### AI Insights Tab
- **Location**: Right panel, next to "Standard" tab
- **Always Clickable**: Tab is always accessible
- **Empty State**: 
  - Not logged in: Shows sign-in prompt
  - Logged in: Shows "AI Insights will appear here after analyzing your post"

### Visual Indicators
- **Sparkles Icon**: Appears on tab when AI analysis is available
- **Color Coding**:
  - Success (green): Strengths, key insights
  - Warning (orange): Paragraph analysis, formatting
  - Destructive (red): Weaknesses, CTA issues
  - Primary (blue): Main score, improvements

## Technical Details

### API Integration
- **Model**: Gemini 2.5 Flash (multimodal LLM)
- **Endpoint**: Supabase Edge Function `analyze-post`
- **Method**: POST with SSE streaming
- **Timeout**: Up to 30 seconds for first response
- **Authentication**: Automatic via INTEGRATIONS_API_KEY

### Training Data
- **Source**: 34,000+ viral LinkedIn posts
- **Creators**: Neil Patel, Gary Vaynerchuk, Simon Sinek, Lara Acosta, Ann Handley, and 100+ others
- **Niches**: Tech, Marketing, Leadership, Sales, Personal Branding, Entrepreneurship

### Data Storage
- **Table**: `ai_analyses`
- **Stored**: user_id, content (first 500 chars), niche, score, analysis_data, created_at
- **Privacy**: RLS policies ensure you only see your own analyses

## Usage Tips

### Getting the Best Results

1. **Write Complete Posts**: AI analyzes full post structure
2. **Include Hook**: First 2 lines are critical for scoring
3. **Use Paragraphs**: Break content into readable chunks
4. **Add CTA**: Include a clear call-to-action
5. **Select Correct Niche**: Helps AI provide niche-specific insights

### Understanding Scores

- **Don't Expect 90%+**: AI is trained to be strict
- **60-75% is Normal**: Most good posts score in this range
- **Focus on Improvements**: Use suggestions to enhance your post
- **Compare Versions**: Analyze multiple drafts to see improvement

### Iterative Improvement

1. **First Draft**: Analyze your initial post
2. **Review Insights**: Read all improvement suggestions
3. **Apply Changes**: Implement hook, structure, formatting improvements
4. **Re-analyze**: Check if score improves
5. **Repeat**: Continue refining until satisfied

## Comparison: Standard vs AI Analysis

### Standard Analysis
- **Speed**: Instant (local calculation)
- **Scoring**: Rule-based algorithm
- **Insights**: Checklist of pass/fail criteria
- **Explanation**: Why Box with scoring rules
- **No Login Required**: Works for everyone

### AI Analysis
- **Speed**: 30 seconds (API call)
- **Scoring**: AI-powered, trained on 34,000+ posts
- **Insights**: Comprehensive analysis with specific suggestions
- **Explanation**: Detailed reasoning with examples
- **Login Required**: Requires authentication

### When to Use Each

**Use Standard Analysis When**:
- You want instant feedback
- You're not logged in
- You want to check basic criteria
- You're doing quick iterations

**Use AI Analysis When**:
- You want detailed, specific feedback
- You're preparing a final post
- You want improvement suggestions
- You want to track analysis history

## Troubleshooting

### AI Insights Not Showing

**Problem**: Empty state shows "AI Insights will appear here after analyzing your post"

**Solutions**:
1. Make sure you're logged in
2. Check that AI-Powered Analysis toggle is "Enabled"
3. Click "Analyze Reach" button
4. Wait for 30-second countdown to complete
5. Check AI Insights tab after analysis completes

### Analysis Failed

**Problem**: Error message "AI Analysis Failed"

**Solutions**:
1. Check your internet connection
2. Try again (API may be temporarily unavailable)
3. Use Standard analysis as fallback
4. Contact support if problem persists

### Low Score

**Problem**: AI gave lower score than expected

**Remember**:
- AI uses strict grading (most posts score 60-75%)
- Read the "Reasoning" section to understand why
- Focus on "Improvements" section for specific fixes
- Compare with "Weaknesses" to identify issues
- Re-analyze after implementing suggestions

## Privacy & Security

- **Data Storage**: Only first 500 characters stored
- **Access Control**: RLS policies protect your data
- **No Sharing**: Your analyses are private
- **Deletion**: Contact support to delete analysis history

## Future Enhancements

Coming soon:
- Real-time streaming of AI insights
- Historical analysis trends
- Niche-specific training data insights
- Export analysis reports as PDF
- Comparison view between analyses

---

**Need Help?**
- Check the Standard tab for basic analysis
- Review improvement suggestions carefully
- Try analyzing example posts to learn
- Contact support for technical issues

**Last Updated**: 2026-02-21  
**Version**: 1.0  
**Model**: Gemini 2.5 Flash

# 🔧 Fix AI Search Error: "Edge Function returned a non-2xx status code"

## The Problem

You're seeing this error when trying to use AI Search:
```
Edge Function returned a non-2xx status code
```

**This means**: The AI Search Edge Function is failing, most likely because the `INTEGRATIONS_API_KEY` environment variable is not configured.

## The Solution (2 Minutes)

### Step 1: Get Your API Key

The `INTEGRATIONS_API_KEY` is provided by the Miaoda platform. You should have received this key when you registered for the AI Search service.

**If you don't have an API key**:
1. Contact the Miaoda support team
2. Request access to the AI Search API
3. They will provide you with an `INTEGRATIONS_API_KEY`

### Step 2: Configure the API Key in Supabase

1. **Go to Supabase Dashboard**: https://supabase.com/dashboard

2. **Select Your Project**: `upxgbldhftcjldbgdehu`

3. **Navigate to Edge Functions**:
   - Click "Edge Functions" in the left sidebar
   - Find "ai-search" in the list
   - Click on it

4. **Go to Settings**:
   - Click the "Settings" tab (or "Secrets" tab if available)

5. **Add Environment Variable**:
   - Click "Add new secret" or "New environment variable"
   - Name: `INTEGRATIONS_API_KEY`
   - Value: [Paste your API key here]
   - Click "Save" or "Add"

6. **Redeploy the Function** (if needed):
   - Some Supabase versions require redeployment
   - Click "Deploy" or "Redeploy" button
   - Wait for deployment to complete

### Step 3: Test the Feature

1. **Refresh your application** (hard refresh: Ctrl+Shift+R or Cmd+Shift+R)
2. **Write a post** in the Drafting Board
3. **Click "Analyze Reach"**
4. **Scroll down** to the AI Search Assistant
5. **Ask a question** (e.g., "How can I improve this post?")
6. **Wait 30-45 seconds** for the response
7. **You should see an answer** ✅

## Visual Guide

### Supabase Dashboard - Edge Function Settings

```
┌─────────────────────────────────────────────────────────┐
│ Edge Functions > ai-search > Settings                   │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Environment Variables / Secrets                         │
│                                                         │
│ ┌─────────────────────────────────────────────────┐   │
│ │ Name: INTEGRATIONS_API_KEY                      │   │
│ │ Value: ••••••••••••••••••••••••••••••••••••    │   │
│ │                                    [Delete]     │   │
│ └─────────────────────────────────────────────────┘   │
│                                                         │
│ [+ Add new secret]                                      │
│                                                         │
│                    [Save Changes]                       │
└─────────────────────────────────────────────────────────┘
```

## Troubleshooting

### Issue: "API key not configured"

**Cause**: `INTEGRATIONS_API_KEY` environment variable is not set

**Solution**: Follow Step 2 above to add the API key

### Issue: Still getting error after adding API key

**Solution**:
1. Make sure you clicked "Save" in Supabase Dashboard
2. Wait 1-2 minutes for changes to propagate
3. Redeploy the Edge Function if needed
4. Hard refresh your application (Ctrl+Shift+R)
5. Clear browser cache if needed

### Issue: "AI Search API error: 401" or "Unauthorized"

**Cause**: API key is invalid or expired

**Solution**:
1. Verify the API key is correct (no extra spaces)
2. Contact Miaoda support to verify key is active
3. Request a new API key if needed

### Issue: "AI Search API error: 429" or "Too Many Requests"

**Cause**: Rate limit exceeded

**Solution**:
1. Wait a few minutes before trying again
2. Contact Miaoda support to increase rate limit
3. Implement rate limiting on client side

### Issue: Request times out (>60 seconds)

**Cause**: AI Search API is slow or unresponsive

**Solution**:
1. This is normal for first token (up to 30 seconds)
2. If consistently slow, check API status
3. Contact Miaoda support if issue persists

## Verification Checklist

Before testing, make sure:

- [ ] You have an `INTEGRATIONS_API_KEY` from Miaoda
- [ ] Supabase Dashboard is open
- [ ] Project `upxgbldhftcjldbgdehu` is selected
- [ ] Edge Functions → ai-search is open
- [ ] Settings/Secrets tab is selected
- [ ] Environment variable `INTEGRATIONS_API_KEY` is added
- [ ] Value is pasted correctly (no extra spaces)
- [ ] Changes are saved
- [ ] Edge Function is redeployed (if needed)
- [ ] Application is refreshed

## Expected Result

After configuration, when you ask a question in AI Search:

1. ✅ Loading indicator appears
2. ✅ "Searching and analyzing..." message shows
3. ✅ Wait 30-45 seconds
4. ✅ Answer appears with sources
5. ✅ You can ask follow-up questions

## Alternative: Disable AI Search (Temporary)

If you can't configure the API key right now, you can temporarily hide the AI Search feature:

### Option 1: Comment Out in Code

Edit `src/pages/Home.tsx` and comment out the AI Search Panel:

```typescript
{/* AI Search Panel (temporarily disabled)
{(analysis || aiAnalysis) && draft.trim() && (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="mt-8"
  >
    <AISearchPanel postContent={draft} />
  </motion.div>
)}
*/}
```

### Option 2: Add Feature Flag

Add a feature flag to enable/disable AI Search:

```typescript
const AI_SEARCH_ENABLED = false; // Set to true when API key is configured

{AI_SEARCH_ENABLED && (analysis || aiAnalysis) && draft.trim() && (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="mt-8"
  >
    <AISearchPanel postContent={draft} />
  </motion.div>
)}
```

## Getting an API Key

### Contact Miaoda Support

**Email**: support@miaoda.tech (example - use actual support email)

**Information to Provide**:
- Your name and organization
- Project name: Linked-Optima
- Supabase project ID: upxgbldhftcjldbgdehu
- Use case: LinkedIn post analysis Q&A
- Expected usage: [number] requests per day/month

**What to Request**:
- Access to AI Search API
- `INTEGRATIONS_API_KEY` for authentication
- Rate limits and pricing information
- API documentation

## API Key Security

### ✅ Best Practices

- **Never commit API keys to Git**: Always use environment variables
- **Never expose in client code**: Only use in Edge Functions
- **Rotate keys regularly**: Request new keys periodically
- **Monitor usage**: Track API calls to detect abuse
- **Use separate keys**: Different keys for dev/staging/production

### 🔒 How It's Protected

- ✅ API key stored in Supabase Edge Function environment
- ✅ Never sent to client browser
- ✅ Only accessible by server-side Edge Function
- ✅ Encrypted at rest in Supabase
- ✅ Transmitted over HTTPS only

## Cost Considerations

### AI Search API Pricing

- Check with Miaoda for current pricing
- Typically charged per request or per token
- May have free tier or trial period
- Monitor usage to control costs

### Optimization Tips

1. **Cache common questions**: Store frequent answers
2. **Rate limiting**: Prevent abuse with limits
3. **User education**: Teach users to ask specific questions
4. **Analytics**: Track which questions are most valuable

## Need More Help?

### For Users
- **Documentation**: See `AI_SEARCH_QUICK_START.md`
- **Support**: Contact your administrator

### For Developers
- **Technical Guide**: See `AI_SEARCH_FEATURE.md`
- **Edge Function Logs**: Supabase Dashboard → Edge Functions → ai-search → Logs
- **Component Code**: `src/components/analysis/AISearchPanel.tsx`
- **Edge Function Code**: `supabase/functions/ai-search/index.ts`

### For Administrators
- **Supabase Dashboard**: https://supabase.com/dashboard
- **Project ID**: upxgbldhftcjldbgdehu
- **Edge Function**: ai-search
- **Required Variable**: INTEGRATIONS_API_KEY

---

**Quick Summary**:
1. Get API key from Miaoda
2. Add to Supabase Edge Function settings
3. Save and redeploy
4. Test the feature

**Estimated Time**: 2-5 minutes  
**Difficulty**: Easy  
**Cost**: Depends on Miaoda pricing

---

**Last Updated**: 2026-02-28  
**Status**: Configuration Required

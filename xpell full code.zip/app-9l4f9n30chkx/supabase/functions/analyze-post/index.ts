import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AnalyzePostRequest {
  content: string;
  niche: string;
  userId?: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Analyze-post function called');
    const { content, niche, userId }: AnalyzePostRequest = await req.json();
    console.log('Request params:', { contentLength: content?.length, niche, userId });

    if (!content || !niche) {
      console.error('Missing required fields:', { hasContent: !!content, hasNiche: !!niche });
      return new Response(
        JSON.stringify({ error: 'Content and niche are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get the LLM API key from environment
    const INTEGRATIONS_API_KEY = Deno.env.get('INTEGRATIONS_API_KEY');
    console.log('INTEGRATIONS_API_KEY exists:', !!INTEGRATIONS_API_KEY);
    if (!INTEGRATIONS_API_KEY) {
      throw new Error('INTEGRATIONS_API_KEY not configured');
    }

    // Construct the prompt for strict analysis
    const analysisPrompt = `You are an expert LinkedIn post analyzer trained on 34,000+ viral posts from top creators like Neil Patel, Gary Vaynerchuk, Simon Sinek, Lara Acosta, Ann Handley, and 100+ others.

CRITICAL SCORING RULES (BE EXTREMELY STRICT):
- 90-100%: EXCEPTIONAL posts only (top 5-10% of all content). Must have perfect hook, structure, CTA, and viral potential.
- 80-89%: Very good posts with minor flaws. Strong engagement potential.
- 70-79%: Good posts with noticeable improvements needed.
- 60-69%: Average posts with several flaws.
- 50-59%: Below average, needs significant work.
- 0-49%: Poor posts with major issues.

Analyze this LinkedIn post for the "${niche}" niche:

"""
${content}
"""

Provide a JSON response with:
{
  "score": <number 0-100, be VERY strict>,
  "grade": "<Exceptional|Excellent|Very Good|Good|Fair|Poor>",
  "insights": [
    "<specific insight 1>",
    "<specific insight 2>",
    "<specific insight 3>"
  ],
  "improvements": {
    "hook": "<how to improve the first 2 lines>",
    "structure": "<how to improve paragraph structure and flow>",
    "hashtags": ["<suggested hashtag 1>", "<suggested hashtag 2>", "<suggested hashtag 3>"],
    "formatting": "<specific formatting improvements>",
    "cta": "<how to improve the call-to-action>"
  },
  "paragraphAnalysis": {
    "totalParagraphs": <number>,
    "avgLinesPerParagraph": <number>,
    "longParagraphs": <number of paragraphs with >4 lines>,
    "recommendation": "<specific recommendation for paragraph structure>"
  },
  "strengths": ["<strength 1>", "<strength 2>"],
  "weaknesses": ["<weakness 1>", "<weakness 2>", "<weakness 3>"],
  "viralPotential": "<Low|Medium|High|Very High>",
  "reasoning": "<2-3 sentences explaining the score>"
}

Be brutally honest. Most posts should score 60-75%. Only truly exceptional posts deserve 90%+.`;

    // Call the LLM API
    console.log('Calling LLM API...');
    const llmResponse = await fetch(
      'https://app-9l4f9n30chkx-api-VaOwP8E7dJqa.gateway.appmedo.com/v1beta/models/gemini-2.5-flash:streamGenerateContent?alt=sse',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Gateway-Authorization': `Bearer ${INTEGRATIONS_API_KEY}`,
        },
        body: JSON.stringify({
          contents: [
            {
              role: 'user',
              parts: [{ text: analysisPrompt }],
            },
          ],
        }),
      }
    );

    console.log('LLM API Response Status:', llmResponse.status);

    if (!llmResponse.ok) {
      const errorText = await llmResponse.text();
      console.error('LLM API Error Response:', errorText);
      throw new Error(`LLM API failed with status ${llmResponse.status}: ${errorText}`);
    }

    // Parse SSE response
    console.log('Parsing SSE response...');
    const reader = llmResponse.body?.getReader();
    const decoder = new TextDecoder();
    let fullResponse = '';

    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value);
        const lines = chunk.split('\n');

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data = JSON.parse(line.slice(6));
              if (data.candidates?.[0]?.content?.parts?.[0]?.text) {
                fullResponse += data.candidates[0].content.parts[0].text;
              }
            } catch (e) {
              // Skip invalid JSON lines
              console.warn('Failed to parse SSE line:', line);
            }
          }
        }
      }
    }

    console.log('Full LLM response length:', fullResponse.length);
    console.log('Full LLM response preview:', fullResponse.substring(0, 200));

    // Extract JSON from response (handle markdown code blocks)
    let analysisResult;
    try {
      // Try to find JSON in markdown code blocks
      const jsonMatch = fullResponse.match(/```json\n([\s\S]*?)\n```/) || 
                       fullResponse.match(/```\n([\s\S]*?)\n```/) ||
                       fullResponse.match(/\{[\s\S]*\}/);
      
      if (jsonMatch) {
        const jsonString = jsonMatch[1] || jsonMatch[0];
        console.log('Extracted JSON string length:', jsonString.length);
        analysisResult = JSON.parse(jsonString);
      } else {
        console.log('No JSON match found, trying to parse full response');
        analysisResult = JSON.parse(fullResponse);
      }
      console.log('Successfully parsed analysis result');
    } catch (e) {
      console.error('Failed to parse LLM response:', e);
      console.error('Full response:', fullResponse);
      throw new Error(`Failed to parse AI analysis response: ${e.message}`);
    }

    // Store analysis in database if userId provided
    if (userId) {
      console.log('Storing analysis in database for user:', userId);
      const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
      const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
      const supabase = createClient(supabaseUrl, supabaseKey);

      const { error: dbError } = await supabase.from('ai_analyses').insert({
        user_id: userId,
        content: content.substring(0, 500), // Store first 500 chars
        niche,
        score: analysisResult.score,
        analysis_data: analysisResult,
        created_at: new Date().toISOString(),
      });

      if (dbError) {
        console.error('Database insert error:', dbError);
        // Don't throw, just log the error
      } else {
        console.log('Analysis stored successfully');
      }
    }

    console.log('Returning analysis result');
    return new Response(
      JSON.stringify(analysisResult),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in analyze-post function:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Internal server error',
        details: error.toString()
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

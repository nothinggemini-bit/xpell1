import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { query, postContent } = await req.json()

    if (!query) {
      return new Response(
        JSON.stringify({ error: 'Query is required' }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    console.log('AI Search request:', { query, hasPostContent: !!postContent })

    // Get API key from environment
    const apiKey = Deno.env.get('INTEGRATIONS_API_KEY')
    if (!apiKey) {
      console.error('INTEGRATIONS_API_KEY not found')
      return new Response(
        JSON.stringify({ error: 'API key not configured' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Enhance query with post context if available
    let enhancedQuery = query
    if (postContent) {
      enhancedQuery = `Context: I wrote this LinkedIn post: "${postContent.substring(0, 500)}..."\n\nQuestion: ${query}`
    }

    console.log('Calling AI Search API...')

    // Call AI Search API
    const response = await fetch('https://api.miaoda.tech/api/v1/ai-search', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        query: enhancedQuery,
        stream: false, // Use non-streaming for simpler handling
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error('AI Search API error:', response.status, errorText)
      return new Response(
        JSON.stringify({ 
          error: `AI Search API error: ${response.status}`,
          details: errorText 
        }),
        { 
          status: response.status, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    const data = await response.json()
    console.log('AI Search response received')

    return new Response(
      JSON.stringify({
        answer: data.answer || data.result || 'No answer found',
        sources: data.sources || [],
        query: query,
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('Error in ai-search function:', error)
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Internal server error',
        details: String(error)
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})

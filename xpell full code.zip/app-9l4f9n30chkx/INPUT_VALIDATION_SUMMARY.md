# Input Validation System

## Validation Checks Implemented

### 1. Post Content Validation (Home Page)
- Empty/whitespace check
- Minimum length (10 chars)
- Maximum length (3000 chars)
- Word count (min 3 words)

### 2. Hook A/B Testing Validation (Hook Lab)
- Empty check for both hooks
- Minimum length (5 chars each)
- Maximum length (200 chars each)
- Uniqueness check
- Word count (min 2 words each)

## Files
- src/lib/input-validation.ts (validation utilities)
- src/pages/Home.tsx (uses validatePostContent)
- src/pages/hook-lab/HookLab.tsx (uses validateHooks)

Status: Production Ready

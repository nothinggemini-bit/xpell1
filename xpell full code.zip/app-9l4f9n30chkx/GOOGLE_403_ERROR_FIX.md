# 🔴 Google OAuth 403 Error - Fix Guide

## Error You're Seeing

```
403. That's an error.
We're sorry, but you do not have access to this page.
That's all we know.
```

## What This Means

Your Google OAuth app is in **Testing mode** and your Google account is not added as a test user.

## Quick Fix (2 Minutes)

### Option 1: Add Your Email as Test User (Recommended for Testing)

1. **Go to Google Cloud Console OAuth Consent Screen**
   - Direct link: https://console.cloud.google.com/apis/credentials/consent
   - Or: Google Cloud Console → APIs & Services → OAuth consent screen

2. **Scroll to "Test users" section**
   - Click **"+ ADD USERS"** button

3. **Add Your Email**
   - Enter the email address you're trying to sign in with
   - Click **"Save"**

4. **Test Again**
   - Go back to Xpell
   - Click "Continue with Google"
   - Should work now! ✅

### Option 2: Publish Your App (For Production)

⚠️ **Only do this if you're ready for public use**

1. **Go to OAuth Consent Screen**
   - https://console.cloud.google.com/apis/credentials/consent

2. **Click "PUBLISH APP"**
   - Review the information
   - Click "Confirm"

3. **Verification May Be Required**
   - Google may require verification for certain scopes
   - This can take several days
   - Not recommended for testing

## Step-by-Step with Screenshots

### Step 1: Open OAuth Consent Screen
1. Go to: https://console.cloud.google.com/apis/credentials/consent
2. You should see your app name (e.g., "Xpell")
3. Status should show "Testing"

### Step 2: Add Test Users
1. Scroll down to **"Test users"** section
2. Click **"+ ADD USERS"** button
3. A popup will appear

### Step 3: Enter Email
1. Type your email address (the one you're using to sign in)
2. Press Enter or click outside the field
3. Click **"Save"** button

### Step 4: Verify
1. Your email should now appear in the Test users list
2. You can add up to 100 test users

### Step 5: Test Sign-In
1. Go back to Xpell application
2. Click "Continue with Google"
3. Sign in with the email you just added
4. Should work now! ✅

## Why This Happens

When you create a Google OAuth app:
- It starts in **Testing mode** by default
- Only test users can sign in
- This is a security feature to prevent unauthorized access
- You must either:
  - Add test users (for development/testing)
  - Publish the app (for production)

## Common Issues

### "Email already added but still getting 403"
- Wait 1-2 minutes for changes to propagate
- Clear browser cache
- Try in incognito/private window
- Make sure you're signing in with the exact email you added

### "Can't find OAuth consent screen"
- Make sure you're in the correct Google Cloud project
- Check that you have the right permissions
- You need to be project owner or editor

### "ADD USERS button is disabled"
- Make sure app is in Testing mode (not Published)
- Check that you have edit permissions
- Try refreshing the page

## Alternative: Use Email/Password

While fixing Google OAuth, you can still use:
- ✅ Email/password signup
- ✅ Username/password login
- ✅ All features work the same way

## Verification Checklist

After adding test user:
- [ ] Went to OAuth consent screen
- [ ] Clicked "+ ADD USERS"
- [ ] Added your email address
- [ ] Clicked "Save"
- [ ] Waited 1-2 minutes
- [ ] Cleared browser cache
- [ ] Tested "Continue with Google"
- [ ] Successfully signed in ✅

## Expected Flow After Fix

1. Click "Continue with Google"
2. Redirected to Google sign-in page
3. Sign in with your email (the one you added as test user)
4. Grant permissions
5. Redirected back to Xpell
6. Logged in successfully ✅

## Screenshots Reference

### OAuth Consent Screen Location
```
Google Cloud Console
  └── APIs & Services
      └── OAuth consent screen
          └── Test users section
              └── + ADD USERS button
```

### What You Should See
- App name: Your app name
- User type: External
- Publishing status: Testing
- Test users: (your email should be listed here)

## Need More Help?

If you're still having issues:
1. Make sure you're using the correct Google Cloud project
2. Verify the OAuth Client ID matches the one in Supabase
3. Check that redirect URI is correct: `https://cgaavihuckojsrolsapn.supabase.co/auth/v1/callback`
4. Try signing in with a different Google account that's added as test user

---

**Quick Link**: https://console.cloud.google.com/apis/credentials/consent

**Status**: Waiting for you to add test user  
**Estimated Fix Time**: 2 minutes  
**Difficulty**: Easy ⭐

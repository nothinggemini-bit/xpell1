# Input Validation System Documentation

## Overview

The Linked-Optima application implements a comprehensive input validation system to ensure data integrity, improve user experience, and prevent errors. The validation system is centralized in a reusable utility module and integrated across all user input points.

---

## Architecture

### File Structure
```
src/
├── lib/
│   └── input-validation.ts    # Core validation utilities
├── pages/
│   ├── Home.tsx               # Main post analysis (uses validatePostContent)
│   └── hook-lab/
│       └── HookLab.tsx        # Hook A/B testing (uses validateHooks)
```

### Validation Flow
```
User Input
    ↓
Validation Function
    ↓
ValidationResult { isValid, error? }
    ↓
[Valid] → Process Input
[Invalid] → Show Toast Error
```

---

## Validation Functions

### 1. `validatePostContent(content: string)`

**Purpose**: Validates LinkedIn post content for analysis

**Validation Rules**:
1. ✅ **Empty Check**: Content cannot be empty or only whitespace
2. ✅ **Minimum Length**: At least 10 characters required
3. ✅ **Maximum Length**: Cannot exceed 3000 characters (LinkedIn limit)
4. ✅ **Word Count**: Must contain at least 3 meaningful words

**Usage**:
```typescript
import { validatePostContent } from '@/lib/input-validation';

const validation = validatePostContent(userInput);
if (!validation.isValid) {
  toast({
    variant: "destructive",
    title: "Validation Error",
    description: validation.error,
  });
  return;
}
// Proceed with analysis
```

**Error Messages**:
- "Post content cannot be empty. Please enter your LinkedIn post text."
- "Post content is too short. Please enter at least 10 characters for accurate analysis."
- "Post content exceeds LinkedIn's 3000 character limit. Please shorten your post."
- "Post must contain at least 3 words for meaningful analysis."

---

### 2. `validateHooks(hookA: string, hookB: string)`

**Purpose**: Validates two hooks for A/B testing comparison

**Validation Rules**:
1. ✅ **Empty Check**: Both hooks must be filled
2. ✅ **Minimum Length**: Each hook must be at least 5 characters
3. ✅ **Maximum Length**: Each hook must be under 200 characters
4. ✅ **Uniqueness**: Hooks cannot be identical (case-insensitive)
5. ✅ **Word Count**: Each hook must contain at least 2 words

**Usage**:
```typescript
import { validateHooks } from '@/lib/input-validation';

const validation = validateHooks(hookA, hookB);
if (!validation.isValid) {
  toast({
    variant: "destructive",
    title: "Validation Error",
    description: validation.error,
  });
  return;
}
// Proceed with A/B testing
```

**Error Messages**:
- "Both hooks must be filled. Please enter text for both Option A and Option B."
- "Option A is too short. Please enter at least 5 characters."
- "Option B is too short. Please enter at least 5 characters."
- "Option A is too long. Hooks should be concise (max 200 characters)."
- "Option B is too long. Hooks should be concise (max 200 characters)."
- "Both hooks are identical. Please enter different hooks for A/B testing."
- "Option A must contain at least 2 words."
- "Option B must contain at least 2 words."

---

### 3. `validateSingleHook(hook: string, label: string)`

**Purpose**: Validates a single hook with custom label

**Validation Rules**:
1. ✅ **Empty Check**: Hook cannot be empty
2. ✅ **Minimum Length**: At least 5 characters
3. ✅ **Maximum Length**: Under 200 characters
4. ✅ **Word Count**: At least 2 words

**Usage**:
```typescript
import { validateSingleHook } from '@/lib/input-validation';

const validation = validateSingleHook(hook, "Opening Line");
if (!validation.isValid) {
  console.error(validation.error);
}
```

---

### 4. `validateEmail(email: string)`

**Purpose**: Validates email address format

**Validation Rules**:
1. ✅ **Empty Check**: Email is required
2. ✅ **Format Check**: Must match email pattern (user@domain.com)

**Usage**:
```typescript
import { validateEmail } from '@/lib/input-validation';

const validation = validateEmail(emailInput);
if (!validation.isValid) {
  // Show error
}
```

---

### 5. `validatePassword(password: string)`

**Purpose**: Validates password strength

**Validation Rules**:
1. ✅ **Empty Check**: Password is required
2. ✅ **Minimum Length**: At least 6 characters

**Usage**:
```typescript
import { validatePassword } from '@/lib/input-validation';

const validation = validatePassword(passwordInput);
if (!validation.isValid) {
  // Show error
}
```

---

### 6. `validateUsername(username: string)`

**Purpose**: Validates username format and length

**Validation Rules**:
1. ✅ **Empty Check**: Username is required
2. ✅ **Minimum Length**: At least 3 characters
3. ✅ **Maximum Length**: Under 30 characters
4. ✅ **Character Check**: Only alphanumeric, underscore, hyphen allowed

**Usage**:
```typescript
import { validateUsername } from '@/lib/input-validation';

const validation = validateUsername(usernameInput);
if (!validation.isValid) {
  // Show error
}
```

---

## Utility Functions

### `sanitizeInput(input: string)`
Removes potentially harmful characters (script tags, HTML tags)

```typescript
const clean = sanitizeInput(userInput);
```

### `hasMeaningfulContent(input: string)`
Checks if input contains alphanumeric characters

```typescript
if (!hasMeaningfulContent(input)) {
  // Input is only whitespace or special characters
}
```

### `getWordCount(text: string)`
Returns number of meaningful words

```typescript
const words = getWordCount(text); // 42
```

### `getCharacterCount(text: string)`
Returns character count (trimmed)

```typescript
const chars = getCharacterCount(text); // 256
```

---

## Integration Examples

### Home Page (Post Analysis)

**File**: `src/pages/Home.tsx`

```typescript
import { validatePostContent } from '@/lib/input-validation';
import { useToast } from '@/hooks/use-toast';

const Home: React.FC = () => {
  const { toast } = useToast();
  const [draft, setDraft] = useState('');

  const handleAnalyze = async () => {
    // Validate input
    const validation = validatePostContent(draft);
    
    if (!validation.isValid) {
      toast({
        variant: "destructive",
        title: "Validation Error",
        description: validation.error,
      });
      return;
    }
    
    // Proceed with analysis
    const result = calculateViralScore(draft, weights, niche);
    setAnalysis(result);
  };

  return (
    // ... UI components
  );
};
```

### Hook Lab Page (A/B Testing)

**File**: `src/pages/hook-lab/HookLab.tsx`

```typescript
import { validateHooks } from '@/lib/input-validation';
import { useToast } from '@/hooks/use-toast';

const HookLab: React.FC = () => {
  const { toast } = useToast();
  const [hookA, setHookA] = useState('');
  const [hookB, setHookB] = useState('');

  const handleFight = () => {
    // Validate both hooks
    const validation = validateHooks(hookA, hookB);
    
    if (!validation.isValid) {
      toast({
        variant: "destructive",
        title: "Validation Error",
        description: validation.error,
      });
      return;
    }
    
    // Proceed with A/B testing
    const resultA = calculateViralScore(hookA, weights);
    const resultB = calculateViralScore(hookB, weights);
    // ... comparison logic
  };

  return (
    // ... UI components
  );
};
```

---

## Validation Rules Summary

### Post Content Validation
| Rule | Requirement | Error Message |
|------|-------------|---------------|
| Empty | Not empty | "Post content cannot be empty..." |
| Min Length | ≥ 10 chars | "Post content is too short..." |
| Max Length | ≤ 3000 chars | "Post content exceeds LinkedIn's 3000 character limit..." |
| Word Count | ≥ 3 words | "Post must contain at least 3 words..." |

### Hook Validation
| Rule | Requirement | Error Message |
|------|-------------|---------------|
| Empty | Both filled | "Both hooks must be filled..." |
| Min Length | ≥ 5 chars each | "Option X is too short..." |
| Max Length | ≤ 200 chars each | "Option X is too long..." |
| Uniqueness | Different | "Both hooks are identical..." |
| Word Count | ≥ 2 words each | "Option X must contain at least 2 words..." |

---

## User Experience

### Toast Notifications

**Visual Feedback**:
- ❌ **Destructive Variant**: Red/orange color scheme
- ⚠️ **Title**: "Validation Error"
- 📝 **Description**: Specific error message with guidance

**Example Toast**:
```
┌─────────────────────────────────────────┐
│ ⚠️ Validation Error                     │
│                                         │
│ Post content is too short. Please      │
│ enter at least 10 characters for       │
│ accurate analysis.                      │
└─────────────────────────────────────────┘
```

### Button States

**Before Validation**:
- Button enabled if input has content
- User can click to trigger validation

**After Validation Failure**:
- Toast appears with error message
- Button remains enabled for retry
- Input field retains user's content

**After Validation Success**:
- Button shows loading state
- Analysis proceeds
- Results displayed

---

## Testing

### Manual Testing Checklist

#### Post Content Validation
- [ ] Empty input shows error
- [ ] 5 characters shows error (too short)
- [ ] 10 characters passes validation
- [ ] 3000 characters passes validation
- [ ] 3001 characters shows error (too long)
- [ ] Only whitespace shows error
- [ ] Only special characters shows error
- [ ] 1-2 words shows error
- [ ] 3+ words passes validation

#### Hook Validation
- [ ] Both empty shows error
- [ ] Only Hook A filled shows error
- [ ] Only Hook B filled shows error
- [ ] Both under 5 chars shows error
- [ ] Both over 200 chars shows error
- [ ] Identical hooks shows error
- [ ] Different hooks pass validation
- [ ] 1 word in either hook shows error
- [ ] 2+ words in both hooks pass validation

---

## Error Handling

### Validation Error Flow
```
User submits form
    ↓
Validation function called
    ↓
Validation fails
    ↓
Toast notification shown
    ↓
User corrects input
    ↓
User resubmits
    ↓
Validation passes
    ↓
Processing continues
```

### No Silent Failures
- All validation errors are surfaced to the user
- Clear, actionable error messages
- No console-only errors
- No generic "Something went wrong" messages

---

## Best Practices

### 1. **Validate Early**
```typescript
// ✅ Good: Validate before processing
const validation = validatePostContent(input);
if (!validation.isValid) {
  showError(validation.error);
  return;
}
processInput(input);

// ❌ Bad: Process first, validate later
processInput(input);
if (input.length < 10) {
  showError("Too short");
}
```

### 2. **Use Centralized Functions**
```typescript
// ✅ Good: Use validation utility
import { validatePostContent } from '@/lib/input-validation';
const validation = validatePostContent(input);

// ❌ Bad: Duplicate validation logic
if (!input.trim() || input.length < 10) {
  // ...
}
```

### 3. **Provide Clear Feedback**
```typescript
// ✅ Good: Specific error message
"Post content is too short. Please enter at least 10 characters for accurate analysis."

// ❌ Bad: Vague error message
"Invalid input"
```

### 4. **Validate on Submit, Not on Type**
```typescript
// ✅ Good: Validate when user clicks "Analyze"
const handleAnalyze = () => {
  const validation = validatePostContent(draft);
  // ...
};

// ❌ Bad: Validate on every keystroke (annoying)
const handleChange = (e) => {
  setDraft(e.target.value);
  validatePostContent(e.target.value); // Don't do this
};
```

---

## Future Enhancements

### Potential Additions
1. **Real-time Validation**: Show character count and warnings as user types
2. **Progressive Validation**: Show hints before errors (e.g., "10 more characters needed")
3. **Custom Validation Rules**: Allow admin to configure validation thresholds
4. **Localization**: Support multiple languages for error messages
5. **Accessibility**: Add ARIA labels and screen reader support
6. **Analytics**: Track validation failure rates to improve UX

---

## Troubleshooting

### Common Issues

**Issue**: Toast not appearing
**Solution**: Ensure `useToast` hook is imported and used correctly

**Issue**: Validation passing when it shouldn't
**Solution**: Check that validation function is called before processing

**Issue**: Error messages not clear
**Solution**: Update error messages in `input-validation.ts`

---

## API Reference

### ValidationResult Interface
```typescript
interface ValidationResult {
  isValid: boolean;
  error?: string;
}
```

### Function Signatures
```typescript
validatePostContent(content: string): ValidationResult
validateHooks(hookA: string, hookB: string): ValidationResult
validateSingleHook(hook: string, label?: string): ValidationResult
validateEmail(email: string): ValidationResult
validatePassword(password: string): ValidationResult
validateUsername(username: string): ValidationResult
sanitizeInput(input: string): string
hasMeaningfulContent(input: string): boolean
getWordCount(text: string): number
getCharacterCount(text: string): number
```

---

## Conclusion

The input validation system provides:

✅ **Comprehensive Coverage**: All user inputs validated
✅ **Centralized Logic**: Single source of truth for validation rules
✅ **User-Friendly**: Clear, actionable error messages
✅ **Type-Safe**: Full TypeScript support
✅ **Maintainable**: Easy to update rules and add new validations
✅ **Consistent**: Same validation approach across all pages

The system ensures data integrity while maintaining excellent user experience through clear feedback and helpful error messages.

---

**Last Updated**: 2026-02-13
**Version**: 1.0.0
**Status**: ✅ Production Ready

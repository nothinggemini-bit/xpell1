# ⚠️ AI Search Error Fix - Quick Guide

## The Error

```
Edge Function returned a non-2xx status code
```

## The Cause

The `INTEGRATIONS_API_KEY` environment variable is **not configured** in your Supabase Edge Function.

## The Fix (2 Steps)

### Step 1: Get API Key
Contact Miaoda support to get your `INTEGRATIONS_API_KEY`

### Step 2: Configure in Supabase
1. Go to https://supabase.com/dashboard
2. Select project: `upxgbldhftcjldbgdehu`
3. Go to: **Edge Functions** → **ai-search** → **Settings**
4. Add secret:
   - Name: `INTEGRATIONS_API_KEY`
   - Value: [Your API key]
5. Click **Save**
6. **Redeploy** the function (if needed)

### Step 3: Test
1. Refresh your app (Ctrl+Shift+R)
2. Analyze a post
3. Ask a question in AI Search
4. ✅ It works!

## What I Fixed

### Improved Error Messages
- Now shows clear message: "AI Search is not configured yet"
- Tells user to contact administrator
- Provides specific instructions

### Better Error Handling
- Checks for API key configuration error
- Checks for API response errors
- Shows detailed error messages
- Allows retry after error

## Files Modified

1. **AISearchPanel.tsx**: Improved error handling and messages
2. **FIX_AI_SEARCH_ERROR.md**: Comprehensive configuration guide

## Current Status

✅ **Code is correct** - Edge Function and component work properly  
⚠️ **Configuration needed** - API key must be added to Supabase  
✅ **Error messages improved** - Users see clear instructions  

## Next Steps

1. **Get API Key**: Contact Miaoda support
2. **Configure**: Add key to Supabase Edge Function
3. **Test**: Try AI Search feature
4. **Enjoy**: Ask questions about your posts!

## Temporary Workaround

If you can't configure the API key right now, you can temporarily disable AI Search by editing `src/pages/Home.tsx`:

```typescript
const AI_SEARCH_ENABLED = false; // Set to true when API key is configured
```

## Need Help?

- **Configuration Guide**: See `FIX_AI_SEARCH_ERROR.md`
- **Feature Documentation**: See `AI_SEARCH_FEATURE.md`
- **Quick Start**: See `AI_SEARCH_QUICK_START.md`

---

**TL;DR**: The AI Search feature needs an API key from Miaoda. Add it to Supabase Edge Function settings, and it will work!

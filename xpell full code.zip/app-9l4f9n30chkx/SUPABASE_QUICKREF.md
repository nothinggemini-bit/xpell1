# Supabase Connection - Quick Reference

## ✅ Current Configuration (Active)

### Project Information
```
Project URL:  https://cgaavihuckojsrolsapn.supabase.co
Project Ref:  cgaavihuckojsrolsapn
```

### API Keys
```
Anon Key (JWT):
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNnYWF2aWh1Y2tvanNyb2xzYXBuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE2OTg0NjksImV4cCI6MjA4NzI3NDQ2OX0.cWJhSOcYDtBnUGLLzd580-ZrpyT3E-A8-Q8cCJSZ2fY

Publishable Key:
sb_publishable_6Wg7fS0XmLaM6Mjo-daS1w_tELGDRCd
```

### Database Connection
```
postgresql://postgres:[YOUR-PASSWORD]@db.cgaavihuckojsrolsapn.supabase.co:5432/postgres
```

### OAuth Redirect URI (for Google)
```
https://cgaavihuckojsrolsapn.supabase.co/auth/v1/callback
```

## 🔑 Key Types Explained

| Key Type | Format | Usage | Safe for Frontend? |
|----------|--------|-------|-------------------|
| **Anon Key** | JWT (eyJhbGci...) | Client authentication | ✅ Yes |
| **Publishable Key** | sb_publishable_... | Alternative format | ✅ Yes |
| **Service Role Key** | JWT (eyJhbGci...) | Admin operations | ❌ No (backend only) |

## 🚀 Quick Start

### 1. Verify Configuration
```bash
cat .env
```
Should show:
```
VITE_SUPABASE_URL=https://cgaavihuckojsrolsapn.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 2. Restart Server
```bash
npm run dev
```

### 3. Test Connection
Open browser console and check for Supabase initialization logs.

## 📋 Setup Checklist

### Frontend (Completed ✅)
- [x] Environment variables configured
- [x] Supabase client initialized
- [x] Authentication UI implemented
- [x] Google OAuth UI added
- [x] Error handling implemented

### Backend (Pending ⚠️)
- [ ] Database schema created
- [ ] RLS policies configured
- [ ] Google OAuth enabled
- [ ] Edge Functions deployed
- [ ] Storage buckets created

## 🔗 Important Links

- **Supabase Dashboard**: https://app.supabase.com/project/cgaavihuckojsrolsapn
- **Database**: https://app.supabase.com/project/cgaavihuckojsrolsapn/editor
- **Authentication**: https://app.supabase.com/project/cgaavihuckojsrolsapn/auth/users
- **Storage**: https://app.supabase.com/project/cgaavihuckojsrolsapn/storage/buckets

## 🛠️ Troubleshooting

### Issue: "Invalid API key"
**Solution**: Verify anon key in .env matches the JWT token above

### Issue: "Failed to fetch"
**Solution**: Check project URL is correct and Supabase project is active

### Issue: Google OAuth not working
**Solution**: 
1. Enable Google provider in Supabase Dashboard
2. Add redirect URI to Google Cloud Console
3. See GOOGLE_OAUTH_SETUP.md for detailed steps

## 📚 Documentation

- **Full Configuration**: See `SUPABASE_CONFIG.md`
- **Google OAuth Setup**: See `GOOGLE_OAUTH_SETUP.md`
- **Implementation Notes**: See `TODO.md`

---

**Last Updated**: 2026-02-21  
**Status**: ✅ Connected and Ready  
**Next Step**: Enable Google OAuth in Supabase Dashboard

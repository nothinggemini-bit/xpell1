# LiquidEther - Advanced Fluid Simulation Effect

## Overview

LiquidEther is a sophisticated THREE.js-based fluid simulation component that creates stunning interactive visual effects across the Linked-Optima application. It implements real-time Navier-Stokes fluid dynamics with advanced features like automatic cursor movement, smooth user takeover, and performance optimizations.

## Technical Architecture

### Core Physics Engine

The component implements a complete 2D fluid simulation using:

1. **Navier-Stokes Equations**: Full incompressible fluid dynamics
2. **Advection**: Velocity field transport with BFECC (Back and Forth Error Compensation and Correction)
3. **Viscosity**: Optional viscous diffusion for realistic fluid behavior
4. **Pressure Projection**: Poisson equation solver for divergence-free velocity fields
5. **External Forces**: Mouse/touch interaction forces

### Shader Pipeline

The simulation uses a multi-pass WebGL shader pipeline:

```
┌─────────────┐
│  Advection  │ ← Transports velocity field
└──────┬──────┘
       ↓
┌─────────────┐
│External Force│ ← Applies mouse/touch forces
└──────┬──────┘
       ↓
┌─────────────┐
│  Viscosity  │ ← Optional viscous diffusion (iterative)
└──────┬──────┘
       ↓
┌─────────────┐
│ Divergence  │ ← Computes velocity divergence
└──────┬──────┘
       ↓
┌─────────────┐
│   Poisson   │ ← Solves for pressure (iterative)
└──────┬──────┘
       ↓
┌─────────────┐
│  Pressure   │ ← Projects velocity to divergence-free
└──────┬──────┘
       ↓
┌─────────────┐
│Color Mapping│ ← Visualizes velocity magnitude
└─────────────┘
```

## Component API

### Props

```typescript
interface LiquidEtherProps {
  // Physics Parameters
  mouseForce?: number;          // Force multiplier (default: 20)
  cursorSize?: number;          // Interaction radius (default: 100)
  isViscous?: boolean;          // Enable viscosity (default: false)
  viscous?: number;             // Viscosity coefficient (default: 30)
  dt?: number;                  // Time step (default: 0.014)
  BFECC?: boolean;              // Advanced advection (default: true)
  resolution?: number;          // Simulation resolution 0-1 (default: 0.5)
  isBounce?: boolean;           // Boundary bounce (default: false)
  
  // Solver Iterations
  iterationsViscous?: number;   // Viscosity solver iterations (default: 32)
  iterationsPoisson?: number;   // Pressure solver iterations (default: 32)
  
  // Visual Parameters
  colors?: string[];            // Color palette (default: ['#5227FF', '#FF9FFC', '#B19EEF'])
  
  // Auto-Demo Mode
  autoDemo?: boolean;           // Enable auto cursor (default: true)
  autoSpeed?: number;           // Auto movement speed (default: 0.5)
  autoIntensity?: number;       // Auto force multiplier (default: 2.2)
  autoResumeDelay?: number;     // Idle time before auto resumes (ms, default: 1000)
  autoRampDuration?: number;    // Smooth ramp-up time (s, default: 0.6)
  takeoverDuration?: number;    // User takeover transition (s, default: 0.25)
  
  // Styling
  style?: React.CSSProperties;
  className?: string;
}
```

## Page-Specific Configurations

### Landing Page
```tsx
<LiquidEther 
  mouseForce={25}
  cursorSize={120}
  resolution={0.6}
  colors={['#2563EB', '#10B981', '#8B5CF6']}
  autoDemo={true}
  autoSpeed={0.6}
  autoIntensity={2.5}
  autoResumeDelay={2000}
/>
```
**Purpose**: High-energy, vibrant effect for first impression
**Colors**: Electric Blue, Signal Green, Purple (brand colors)

### Home/Dashboard
```tsx
<LiquidEther 
  mouseForce={20}
  cursorSize={100}
  resolution={0.5}
  colors={['#2563EB', '#10B981', '#F59E0B']}
  autoDemo={true}
  autoSpeed={0.5}
  autoIntensity={2.0}
  autoResumeDelay={3000}
/>
```
**Purpose**: Balanced, professional effect for main workspace
**Colors**: Blue, Green, Warning Orange (diagnostic colors)

### Hook Lab
```tsx
<LiquidEther 
  mouseForce={28}
  cursorSize={110}
  resolution={0.55}
  colors={['#EF4444', '#F59E0B', '#8B5CF6']}
  autoDemo={true}
  autoSpeed={0.7}
  autoIntensity={2.8}
  autoResumeDelay={2500}
/>
```
**Purpose**: Dynamic, competitive effect for A/B testing
**Colors**: Red, Orange, Purple (battle/competition theme)

### Login/Signup
```tsx
<LiquidEther 
  mouseForce={15}
  cursorSize={90}
  resolution={0.45}
  colors={['#2563EB', '#8B5CF6', '#06B6D4']}
  autoDemo={true}
  autoSpeed={0.4}
  autoIntensity={1.8}
  autoResumeDelay={4000}
/>
```
**Purpose**: Subtle, calming effect for authentication
**Colors**: Blue, Purple, Cyan (trust and security)

## Advanced Features

### 1. Auto-Demo Mode

The component includes an intelligent auto-pilot system:

- **Automatic Movement**: Cursor moves smoothly between random targets when idle
- **Smart Activation**: Only activates after user inactivity period
- **Hover Detection**: Pauses when mouse enters component area
- **Smooth Takeover**: Seamless transition from auto to manual control
- **Ramp-Up**: Gradual intensity increase for natural feel

### 2. Performance Optimizations

```typescript
// IntersectionObserver: Pauses rendering when off-screen
const io = new IntersectionObserver(entries => {
  const isVisible = entries[0].isIntersecting;
  if (isVisible && !document.hidden) {
    webgl.start();
  } else {
    webgl.pause();
  }
});

// ResizeObserver: Efficient resize handling with RAF throttling
const ro = new ResizeObserver(() => {
  requestAnimationFrame(() => webgl.resize());
});

// Visibility API: Pauses when tab is hidden
document.addEventListener('visibilitychange', () => {
  if (document.hidden) webgl.pause();
  else webgl.start();
});
```

### 3. Mobile Optimization

- **Adaptive Float Type**: Uses HalfFloatType on iOS for better performance
- **Touch Support**: Full touch event handling with single-finger tracking
- **Pixel Ratio Capping**: Limits to 2x for performance on high-DPI displays
- **Resolution Scaling**: Adjustable simulation resolution for performance tuning

## Implementation Details

### Framebuffer Objects (FBOs)

The simulation uses ping-pong rendering with multiple FBOs:

```typescript
fbos = {
  vel_0: WebGLRenderTarget,      // Current velocity
  vel_1: WebGLRenderTarget,      // Next velocity
  vel_viscous0: WebGLRenderTarget, // Viscosity ping
  vel_viscous1: WebGLRenderTarget, // Viscosity pong
  div: WebGLRenderTarget,        // Divergence field
  pressure_0: WebGLRenderTarget, // Pressure ping
  pressure_1: WebGLRenderTarget  // Pressure pong
}
```

### Color Palette System

Colors are converted to a 1D texture for GPU sampling:

```typescript
// CPU: Array of hex colors → DataTexture
const paletteTex = makePaletteTexture(['#5227FF', '#FF9FFC', '#B19EEF']);

// GPU: Velocity magnitude → Color lookup
vec2 vel = texture2D(velocity, uv).xy;
float lenv = clamp(length(vel), 0.0, 1.0);
vec3 c = texture2D(palette, vec2(lenv, 0.5)).rgb;
```

### Boundary Conditions

Two modes available:

1. **Clamp (default)**: Velocity dampens at edges
2. **Bounce**: Velocity reflects at boundaries (set `isBounce={true}`)

## Performance Tuning Guide

### High Performance (Desktop)
```tsx
<LiquidEther 
  resolution={0.7}
  iterationsPoisson={48}
  iterationsViscous={48}
  isViscous={true}
/>
```

### Balanced (Recommended)
```tsx
<LiquidEther 
  resolution={0.5}
  iterationsPoisson={32}
  iterationsViscous={32}
/>
```

### Low Performance (Mobile)
```tsx
<LiquidEther 
  resolution={0.3}
  iterationsPoisson={16}
  iterationsViscous={16}
  isViscous={false}
/>
```

## Troubleshooting

### Issue: Low FPS
**Solutions**:
- Reduce `resolution` (0.3-0.4)
- Decrease `iterationsPoisson` and `iterationsViscous` (16-24)
- Disable `isViscous`
- Reduce `cursorSize`

### Issue: Effect too subtle
**Solutions**:
- Increase `mouseForce` (25-35)
- Increase `cursorSize` (120-150)
- Adjust `colors` for higher contrast
- Increase `autoIntensity` (2.5-3.0)

### Issue: Effect too aggressive
**Solutions**:
- Decrease `mouseForce` (10-15)
- Decrease `cursorSize` (70-90)
- Increase `autoResumeDelay` (4000-6000)
- Decrease `autoIntensity` (1.5-2.0)

### Issue: Auto-demo interfering
**Solutions**:
- Increase `autoResumeDelay` (longer idle time)
- Decrease `autoSpeed` (slower movement)
- Set `autoDemo={false}` to disable

## Browser Compatibility

- ✅ Chrome/Edge 90+
- ✅ Firefox 88+
- ✅ Safari 14+ (iOS/macOS)
- ✅ Opera 76+
- ⚠️ IE11: Not supported (requires WebGL 2.0)

## Dependencies

- `three` (^0.170.0): Core 3D rendering engine
- `react` (^18.3.1): Component framework

## File Structure

```
src/components/effects/
└── LiquidEther.tsx          # Main component (1,300+ lines)
    ├── CommonClass          # Renderer & timing management
    ├── MouseClass           # Input handling & auto-pilot
    ├── AutoDriver           # Automatic cursor movement
    ├── ShaderPass           # Base shader pass class
    ├── Advection            # Velocity advection
    ├── ExternalForce        # Mouse/touch forces
    ├── Viscous              # Viscosity diffusion
    ├── Divergence           # Divergence computation
    ├── Poisson              # Pressure solver
    ├── Pressure             # Pressure projection
    ├── Simulation           # Simulation orchestrator
    ├── Output               # Final rendering
    └── WebGLManager         # Lifecycle management
```

## Future Enhancements

Potential improvements for future versions:

1. **Multi-touch Support**: Handle multiple simultaneous touch points
2. **Obstacle System**: Add static/dynamic obstacles to the flow
3. **Vorticity Confinement**: Enhance small-scale turbulence
4. **Dye Injection**: Separate dye advection for richer visuals
5. **WebGPU Backend**: Leverage compute shaders for better performance
6. **Preset System**: Pre-configured effect presets (calm, energetic, chaotic)
7. **Recording**: Export animations as video/GIF

## Credits

Based on advanced fluid simulation techniques:
- Jos Stam's "Real-Time Fluid Dynamics for Games" (GDC 2003)
- BFECC advection method by Kim et al.
- WebGL implementation patterns from Pavel Dobryakov's fluid simulation

## License

Part of the Linked-Optima project. All rights reserved.

---

**Last Updated**: 2026-02-12
**Component Version**: 1.0.0
**Author**: Linked-Optima Development Team

# 🎨 UI Layout Guide: New Features

## Page Layout Overview

```
┌─────────────────────────────────────────────────────────────┐
│                         HEADER                               │
│  Logo: Linked-Optima          [Admin Mode Toggle]           │
└─────────────────────────────────────────────────────────────┘

┌──────────────────────────┬──────────────────────────────────┐
│   LEFT PANEL (Input)     │   RIGHT PANEL (Diagnostics)      │
│                          │                                  │
│  ┌────────────────────┐  │  ┌────────────────────────────┐ │
│  │ Target Audience    │  │  │ 👥 FOLLOWER INDICATOR ⭐  │ │
│  │ [Dropdown]         │  │  │ 8.0K Followers             │ │
│  └────────────────────┘  │  │ Established Creator        │ │
│                          │  │ ↗ +4% Score Adjustment     │ │
│  ┌────────────────────┐  │  └────────────────────────────┘ │
│  │ AI-Powered         │  │                                  │
│  │ Analysis [Toggle]  │  │  ┌────────────────────────────┐ │
│  └────────────────────┘  │  │                            │ │
│                          │  │    SCORE GAUGE             │ │
│  ┌────────────────────┐  │  │        78/100              │ │
│  │                    │  │  │                            │ │
│  │  DRAFTING BOARD    │  │  └────────────────────────────┘ │
│  │                    │  │                                  │
│  │  [Text Editor]     │  │  ┌────────────────────────────┐ │
│  │                    │  │  │ [Standard] [AI Insights]   │ │
│  │                    │  │  │                            │ │
│  │  [Analyze Reach]   │  │  │  • Diagnostics             │ │
│  │                    │  │  │  • Why Box                 │ │
│  └────────────────────┘  │  │  • Explanations            │ │
│                          │  │                            │ │
│  ┌────────────────────┐  │  └────────────────────────────┘ │
│  │ 📸 POST IMAGES ⭐  │  │                                  │
│  │ (Optional)         │  │                                  │
│  │ Boost: up to 15%   │  │                                  │
│  │                    │  │                                  │
│  │ ┌──────────────┐   │  │                                  │
│  │ │ [Upload Area]│   │  │                                  │
│  │ │ Drag & Drop  │   │  │                                  │
│  │ └──────────────┘   │  │                                  │
│  │                    │  │                                  │
│  │ [Image Previews]   │  │                                  │
│  │ [🖼️] [🖼️] [🖼️]    │  │                                  │
│  └────────────────────┘  │                                  │
│                          │                                  │
└──────────────────────────┴──────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                    HOOK REFINER                              │
│  • Alternative hooks                                         │
│  • Suggestions                                               │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                    HASHTAG PANEL                             │
│  • Suggested hashtags                                        │
│  • Niche-specific tags                                       │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│              📊 IMAGE ANALYSIS RESULTS ⭐                    │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 📸 Image Analysis        ↗ +8% Impression Boost     │   │
│  │ 2 images analyzed                                    │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ [🖼️] Image 1                                         │   │
│  │ ✓ Excellent (92/100)                                 │   │
│  │ Relevance: 95% | Professional: 90% | Boost: +4%     │   │
│  │ • High quality screenshot                            │   │
│  │ • Clear and professional                             │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ [🖼️] Image 2                                         │   │
│  │ ✓ Good (85/100)                                      │   │
│  │ Relevance: 90% | Professional: 85% | Boost: +4%     │   │
│  │ • Good visual support                                │   │
│  │ • Consider higher resolution                         │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ ↗ Impact on Viral Score                              │   │
│  │ Your images are predicted to increase impressions    │   │
│  │ by +8%. Great visual enhancement!                    │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

## Feature Locations

### ⭐ NEW: Follower Score Indicator
**Location**: Right Panel, Top (above Score Gauge)  
**When**: After analyzing a post (if logged in)  
**Shows**:
- Follower count (formatted: 1K, 1M)
- Follower tier (Emerging, Growing, Established, etc.)
- Score adjustment percentage (+/- %)
- Trending icon (up/down arrow)
- Explanation text

### ⭐ NEW: Image Upload Section
**Location**: Left Panel, Below Drafting Board  
**When**: Always visible  
**Features**:
- Drag & drop upload area
- Click to browse files
- Image preview grid (thumbnails)
- Remove image button (on hover)
- File info (name, size)
- Upload count (X/5 images)
- Max images warning
- Impression boost label

### ⭐ NEW: Image Analysis Results
**Location**: Below Hashtag Panel (bottom of page)  
**When**: After analyzing with images  
**Shows**:
- Total images analyzed
- Total impression boost percentage
- Individual image cards with:
  - Image thumbnail
  - Quality score (0-100)
  - Quality rating (Excellent/Good/Fair/Poor)
  - Relevance percentage
  - Professional appearance percentage
  - Individual impression boost
  - AI insights list
- Impact summary

## User Flow

### 1. Write Post
```
User types in Drafting Board
↓
Selects target audience
↓
Enables AI-Powered Analysis (optional)
```

### 2. Upload Images (Optional)
```
Scrolls to "Post Images" section
↓
Drags images or clicks to browse
↓
Uploads 1-5 images (max 5MB each)
↓
Previews images in grid
↓
Removes unwanted images (optional)
```

### 3. Analyze
```
Clicks "Analyze Reach" button
↓
System calculates base score
↓
System applies follower adjustment
↓
System applies image boost
↓
Results appear
```

### 4. View Results
```
RIGHT PANEL:
- Follower Score Indicator appears (top)
- Score Gauge shows adjusted score
- Tabs show Standard/AI Insights

BOTTOM:
- Hook Refiner suggestions
- Hashtag suggestions
- Image Analysis Results (if images uploaded)
```

## Visual Indicators

### Follower Score Colors
- **Green** (↗): Positive adjustment (+4% to +15%)
- **Red** (↘): Negative adjustment (-4%)
- **Gray**: Neutral (0%)

### Image Quality Colors
- **Green** (✓): Excellent/Good (70-100)
- **Yellow** (⚠): Fair (50-69)
- **Red** (⚠): Poor (0-49)

### Score Gauge Colors
- **Green**: 80-90 (Excellent)
- **Blue**: 60-79 (Good)
- **Yellow**: 40-59 (Fair)
- **Red**: 0-39 (Needs Work)

## Responsive Behavior

### Desktop (≥1024px)
- Two-column layout (7:5 ratio)
- Image upload below drafting board
- Follower indicator above score gauge
- Image analysis full width at bottom

### Tablet (768px - 1023px)
- Two-column layout (stacked on smaller tablets)
- Image upload below drafting board
- Follower indicator above score gauge
- Image analysis full width at bottom

### Mobile (<768px)
- Single column layout
- All sections stack vertically
- Image upload below drafting board
- Follower indicator above score gauge
- Image analysis full width at bottom

## Interaction States

### Image Upload
- **Default**: Gray border, upload icon
- **Drag Over**: Blue border, blue icon
- **Uploaded**: Image grid with thumbnails
- **Hover**: Remove button appears
- **Max Reached**: Disabled state, warning message

### Follower Indicator
- **Loading**: Skeleton loader
- **Loaded**: Shows follower count and adjustment
- **No Data**: Hidden (not logged in or no followers_count)

### Image Analysis
- **Loading**: Skeleton loaders
- **Loaded**: Full analysis cards
- **No Images**: Hidden (not shown)

## Accessibility

### Keyboard Navigation
- Tab through upload area
- Enter to open file picker
- Tab through image previews
- Enter to remove image

### Screen Readers
- Upload area labeled "Upload Images"
- Image previews labeled with filename
- Remove buttons labeled "Remove [filename]"
- Follower indicator reads full text
- Image analysis cards read all metrics

### Color Contrast
- All text meets WCAG AA standards
- Icons have sufficient contrast
- Borders visible in all themes

## Animation

### Entrance Animations
- Follower indicator: Fade in + slide down (0.3s)
- Image previews: Fade in + scale up (0.2s each, staggered)
- Image analysis: Fade in + slide up (0.4s)

### Interaction Animations
- Image hover: Scale up (1.05x)
- Remove button: Fade in (0.2s)
- Upload area drag: Border pulse

### Exit Animations
- Image removal: Fade out + scale down (0.2s)

---

**Legend**:
- ⭐ = New feature
- [Button] = Interactive button
- [Dropdown] = Select dropdown
- [Toggle] = Toggle switch
- 🖼️ = Image thumbnail
- ↗/↘ = Trending indicator
- ✓/⚠ = Status indicator

---

**Last Updated**: 2026-02-28

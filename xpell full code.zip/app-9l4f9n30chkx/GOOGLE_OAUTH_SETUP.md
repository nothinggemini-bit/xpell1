# Google OAuth Setup Guide for Xpell

## Error: "Unsupported provider: provider is not enabled"

If you see this error when clicking "Continue with Google", it means Google OAuth is not yet configured in Supabase.

## Setup Steps

### 1. Create Google Cloud Console Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select an existing one
3. Navigate to **APIs & Services** > **Credentials**
4. Click **Create Credentials** > **OAuth 2.0 Client ID**
5. Configure the OAuth consent screen if prompted:
   - User Type: External
   - App name: Xpell
   - User support email: Your email
   - Developer contact: Your email
6. Create OAuth 2.0 Client ID:
   - Application type: **Web application**
   - Name: Xpell OAuth
   - Authorized JavaScript origins:
     - `http://localhost:5173` (for development)
     - `https://your-production-domain.com` (for production)
   - Authorized redirect URIs:
     - `https://cgaavihuckojsrolsapn.supabase.co/auth/v1/callback`
7. Click **Create**
8. Copy the **Client ID** and **Client Secret**

### 2. Enable Google Provider in Supabase

1. Go to [Supabase Dashboard](https://app.supabase.com/)
2. Select your project: **app-9l4f9n30chkx**
3. Navigate to **Authentication** > **Providers**
4. Find **Google** in the list
5. Toggle **Enable Sign in with Google**
6. Paste your Google OAuth credentials:
   - **Client ID**: Paste from Google Cloud Console
   - **Client Secret**: Paste from Google Cloud Console
7. Configure redirect URLs:
   - Add `http://localhost:5173/` for development
   - Add your production URL when deployed
8. Click **Save**

### 3. Configure Redirect URLs

In Supabase Dashboard:
1. Go to **Authentication** > **URL Configuration**
2. Add to **Redirect URLs**:
   - `http://localhost:5173/`
   - `https://your-production-domain.com/`
3. Click **Save**

### 4. Test the Integration

1. Restart your development server: `npm run dev`
2. Navigate to Login or Signup page
3. Click **Continue with Google**
4. You should be redirected to Google's consent screen
5. After granting permission, you'll be redirected back to the app

## Troubleshooting

### Error: "redirect_uri_mismatch"
- Make sure the redirect URI in Google Cloud Console matches exactly: `https://cgaavihuckojsrolsapn.supabase.co/auth/v1/callback`
- Check that your app URL is in the Authorized JavaScript origins

### Error: "Access blocked: This app's request is invalid"
- Complete the OAuth consent screen configuration in Google Cloud Console
- Add test users if your app is in testing mode

### Error: "Invalid redirect URL"
- Add your app URL to the Redirect URLs list in Supabase Dashboard
- Make sure the URL includes the protocol (http:// or https://)

## Security Notes

- Never commit your Client Secret to version control
- Use environment variables for sensitive credentials
- Keep your OAuth credentials secure
- Regularly rotate your Client Secret
- Monitor OAuth usage in Google Cloud Console

## Additional Resources

- [Supabase Google OAuth Documentation](https://supabase.com/docs/guides/auth/social-login/auth-google)
- [Google OAuth 2.0 Documentation](https://developers.google.com/identity/protocols/oauth2)
- [OAuth 2.0 Best Practices](https://tools.ietf.org/html/rfc6749)

## Current Status

✅ Google Sign-In UI implemented in Login and Signup pages
✅ Error handling for provider not enabled
❌ Google OAuth provider not yet enabled in Supabase (requires admin setup)

## Next Steps

1. Follow the setup steps above to enable Google OAuth
2. Test the complete authentication flow
3. Add additional OAuth providers if needed (GitHub, Facebook, etc.)
4. Configure production redirect URLs before deployment

# Supabase Configuration - Xpell

## Current Configuration

### Environment Variables (.env)
```
VITE_SUPABASE_URL=https://cgaavihuckojsrolsapn.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNnYWF2aWh1Y2tvanNyb2xzYXBuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE2OTg0NjksImV4cCI6MjA4NzI3NDQ2OX0.cWJhSOcYDtBnUGLLzd580-ZrpyT3E-A8-Q8cCJSZ2fY
VITE_APP_ID=app-9l4f9n30chkx
```

### Supabase Project Details
- **Project URL**: https://cgaavihuckojsrolsapn.supabase.co
- **Project Reference**: cgaavihuckojsrolsapn
- **Region**: Auto-detected by Supabase
- **Anon Key**: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... (JWT token for client-side auth)
- **Service Role Key**: Available in Supabase Dashboard (for server-side operations)

### Database Connection
```
postgresql://postgres:[YOUR-PASSWORD]@db.cgaavihuckojsrolsapn.supabase.co:5432/postgres
```
⚠️ **Note**: Replace `[YOUR-PASSWORD]` with your actual database password from Supabase Dashboard

## OAuth Configuration

### Google OAuth Redirect URI
When setting up Google OAuth in Google Cloud Console, use this redirect URI:
```
https://cgaavihuckojsrolsapn.supabase.co/auth/v1/callback
```

### Authorized JavaScript Origins
Add these origins in Google Cloud Console:
- Development: `http://localhost:5173`
- Production: `https://your-production-domain.com`

## Setup Checklist

### ✅ Completed
- [x] Environment variables configured
- [x] Supabase client initialized
- [x] Google OAuth UI implemented
- [x] Error handling for OAuth
- [x] Setup documentation created

### ⚠️ Pending (Requires Admin Action)
- [ ] Database schema migration
- [ ] RLS policies configuration
- [ ] Edge Functions deployment
- [ ] Storage buckets creation
- [ ] Google OAuth provider enablement
- [ ] Google Cloud Console OAuth setup

## Quick Start

### 1. Restart Development Server
```bash
npm run dev
```
This will load the new Supabase credentials.

### 2. Verify Connection
Open browser console and check for Supabase connection logs.

### 3. Test Authentication
Try logging in or signing up to verify Supabase connection works.

## Database Setup

### Required Tables
The application requires these tables to be created in Supabase:
- `users` - User profiles and authentication data
- `posts` - Analyzed LinkedIn posts
- `ai_analyses` - AI analysis results
- `post_history` - Historical post data

### Run Migrations
Use Supabase CLI or Dashboard to run migrations:
```bash
# If using Supabase CLI
supabase db push
```

## Security Best Practices

### Environment Variables
- ✅ Publishable key is safe for client-side use
- ❌ Never commit database password to git
- ✅ Use `.env` file for local development
- ✅ Use environment variables in production

### API Keys
- **Anon Key (JWT)**: Safe to expose in frontend code (used for client-side authentication)
- **Publishable Key**: Alternative key format (also safe for frontend)
- **Service Role Key**: NEVER expose in frontend (backend only, has admin privileges)
- **Database Password**: Keep secure, rotate regularly

### RLS Policies
Ensure Row Level Security is enabled for all tables:
```sql
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_analyses ENABLE ROW LEVEL SECURITY;
```

## Troubleshooting

### Connection Issues
If you see connection errors:
1. Verify `.env` file has correct credentials
2. Restart development server
3. Check Supabase project status in Dashboard
4. Verify network connectivity

### Authentication Issues
If login/signup fails:
1. Check Supabase Auth settings
2. Verify email confirmation is disabled (for testing)
3. Check browser console for detailed errors
4. Verify RLS policies allow user operations

### Google OAuth Issues
If Google Sign-In fails:
1. Check if Google provider is enabled in Supabase
2. Verify redirect URI matches exactly
3. Check Google Cloud Console credentials
4. See GOOGLE_OAUTH_SETUP.md for detailed guide

## Support Resources

- [Supabase Documentation](https://supabase.com/docs)
- [Supabase Dashboard](https://app.supabase.com/project/cgaavihuckojsrolsapn)
- [Google OAuth Setup Guide](./GOOGLE_OAUTH_SETUP.md)
- [Supabase Auth Guide](https://supabase.com/docs/guides/auth)

## Project Links

- **Supabase Dashboard**: https://app.supabase.com/project/cgaavihuckojsrolsapn
- **API URL**: https://cgaavihuckojsrolsapn.supabase.co
- **Database URL**: db.cgaavihuckojsrolsapn.supabase.co:5432

---

**Last Updated**: 2026-02-21  
**Configuration Version**: v1.0  
**Project**: Xpell (app-9l4f9n30chkx)

# Quick Start: Enable Google Login

## Your Supabase Project
- **URL**: https://cgaavihuckojsrolsapn.supabase.co
- **Project ID**: cgaavihuckojsrolsapn
- **Status**: ✅ Credentials configured in application

## 3 Steps to Enable Google Login

### Step 1: Go to Supabase Dashboard
Open: https://supabase.com/dashboard/project/cgaavihuckojsrolsapn/auth/providers

### Step 2: Enable Google Provider
1. Find "Google" in the providers list
2. Toggle it to **Enabled**
3. You'll see fields for Client ID and Client Secret

### Step 3: Get Google OAuth Credentials

#### Option A: Quick Setup (Recommended)
1. Go to: https://console.cloud.google.com/apis/credentials
2. Create new project (or select existing)
3. Click "Create Credentials" → "OAuth 2.0 Client ID"
4. Application type: **Web application**
5. Authorized redirect URIs: 
   ```
   https://cgaavihuckojsrolsapn.supabase.co/auth/v1/callback
   ```
6. Copy **Client ID** and **Client Secret**
7. Paste them into Supabase Dashboard
8. Click **Save**

#### Option B: Detailed Instructions
See `GOOGLE_OAUTH_SETUP_COMPLETE.md` for step-by-step guide

## Test It!

1. Start your app: `npm run dev`
2. Go to Login or Signup page
3. Click "Continue with Google"
4. Google popup should open
5. Select your account
6. You'll be logged in automatically!

## Troubleshooting

**Error: "Provider is not enabled"**
→ Complete Step 2 above

**Google popup doesn't open**
→ Check browser popup blocker

**Error: "Invalid redirect URI"**
→ Add the redirect URI to Google Cloud Console (see Step 3)

## Application Status
✅ Code is ready
✅ Credentials are configured
⏳ Waiting for Google OAuth setup in Supabase Dashboard

Once you complete the 3 steps above, Google login will work immediately!

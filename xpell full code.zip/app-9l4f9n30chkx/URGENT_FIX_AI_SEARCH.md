# 🚨 URGENT: Fix AI Search Error

## Error You're Seeing

```
Edge Function returned a non-2xx status code
```

## What This Means

The AI Search feature needs an **API key** to work. Right now, it's not configured.

---

## Solution 1: Configure API Key (Recommended)

### Step 1: Get API Key from Miaoda

You need to get the `INTEGRATIONS_API_KEY` from Miaoda platform.

**How to get it:**
- If you have a Miaoda account, check your dashboard
- If not, contact Miaoda support to request access

### Step 2: Add to Supabase

1. Open: https://supabase.com/dashboard
2. Select project: **upxgbldhftcjldbgdehu**
3. Click: **Edge Functions** (left sidebar)
4. Click: **ai-search**
5. Click: **Settings** or **Secrets** tab
6. Click: **Add new secret**
7. Fill in:
   ```
   Name: INTEGRATIONS_API_KEY
   Value: [paste your API key]
   ```
8. Click: **Save**
9. Click: **Deploy** or **Redeploy** (if button exists)

### Step 3: Test

1. Refresh your app (Ctrl+Shift+R)
2. Analyze a post
3. Ask a question
4. ✅ Should work now!

---

## Solution 2: Temporarily Disable AI Search

If you can't get the API key right now, you can hide the AI Search feature:

### Edit the Code

Open: `src/pages/Home.tsx`

Find this line (around line 39):
```typescript
const AI_SEARCH_ENABLED = true;
```

Change it to:
```typescript
const AI_SEARCH_ENABLED = false;
```

Save the file, and the AI Search panel will be hidden.

**When you get the API key later**, change it back to `true`.

---

## Which Solution Should I Use?

### Use Solution 1 if:
- ✅ You have or can get a Miaoda API key
- ✅ You want the AI Search feature to work
- ✅ You have access to Supabase Dashboard

### Use Solution 2 if:
- ⏳ You don't have an API key yet
- ⏳ You want to use the app without AI Search for now
- ⏳ You'll configure it later

---

## Need Help?

### Getting API Key
- **Miaoda Support**: Contact them for API access
- **Documentation**: Check your Miaoda account dashboard

### Configuring Supabase
- **Detailed Guide**: See `FIX_AI_SEARCH_ERROR.md`
- **Supabase Docs**: https://supabase.com/docs/guides/functions/secrets

### Technical Issues
- **Edge Function Logs**: Supabase Dashboard → Edge Functions → ai-search → Logs
- **Browser Console**: Press F12 to see error details

---

## Quick Checklist

Before testing, make sure:

- [ ] I have the INTEGRATIONS_API_KEY
- [ ] I opened Supabase Dashboard
- [ ] I selected the correct project (upxgbldhftcjldbgdehu)
- [ ] I went to Edge Functions → ai-search
- [ ] I added the secret with correct name and value
- [ ] I saved the changes
- [ ] I redeployed the function (if needed)
- [ ] I refreshed my app

---

## Expected Result

After configuration:

1. ✅ No more error message
2. ✅ Loading indicator appears when asking questions
3. ✅ AI answers appear after 30-45 seconds
4. ✅ Sources are shown with answers
5. ✅ You can ask multiple questions

---

**TL;DR**: 
- **Problem**: Missing API key
- **Solution**: Add INTEGRATIONS_API_KEY to Supabase Edge Function
- **Temporary Fix**: Set AI_SEARCH_ENABLED = false in Home.tsx

---

**Last Updated**: 2026-02-28

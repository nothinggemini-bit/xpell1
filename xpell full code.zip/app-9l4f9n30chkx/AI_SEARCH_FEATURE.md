# 🔍 AI Search Feature Documentation

## Overview

The AI Search feature allows users to ask questions about their LinkedIn posts after analysis. It uses AI-powered search to provide intelligent insights, suggestions, and answers based on the post content and web knowledge.

## Features

### ✨ Key Capabilities

1. **Context-Aware Search**: Automatically includes post content as context for more relevant answers
2. **Natural Language Q&A**: Ask questions in plain English
3. **Web-Powered Insights**: Searches across the web for the latest information
4. **Source Citations**: Provides links to sources for transparency
5. **Suggested Questions**: Quick-start questions to get users started
6. **Chat Interface**: Familiar chat-like experience with message history

### 🎯 Use Cases

- **Post Improvement**: "How can I improve this post?"
- **Hashtag Suggestions**: "What hashtags should I use?"
- **Timing Advice**: "When is the best time to post this?"
- **Hook Enhancement**: "How can I make the hook more engaging?"
- **Engagement Tips**: "What can I do to increase engagement?"
- **Industry Insights**: "What are the latest trends in [industry]?"
- **Best Practices**: "What are LinkedIn best practices for this type of post?"

## User Interface

### Location

The AI Search Panel appears at the bottom of the page after a post has been analyzed.

### Layout

```
┌─────────────────────────────────────────────────────────┐
│ 🔍 AI Search Assistant                                  │
│ Ask questions about your post and get AI-powered        │
│ insights                                                 │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ [Messages Area - Scrollable]                            │
│                                                         │
│ User: How can I improve this post?                      │
│                                                         │
│ Assistant: Based on your post, here are 3 ways to      │
│ improve it:                                             │
│ 1. Add a stronger hook...                              │
│ 2. Include more specific data...                       │
│ 3. End with a clear CTA...                             │
│                                                         │
│ Sources:                                                │
│ 🔗 LinkedIn Best Practices 2026                        │
│ 🔗 Viral Post Strategies                               │
│                                                         │
├─────────────────────────────────────────────────────────┤
│ [Input Field] [Send Button]                            │
├─────────────────────────────────────────────────────────┤
│ 💡 Tip: Ask specific questions about your post content │
└─────────────────────────────────────────────────────────┘
```

### Components

#### Header
- **Icon**: Sparkles icon (✨) indicating AI feature
- **Title**: "AI Search Assistant"
- **Description**: Brief explanation of the feature

#### Messages Area
- **Empty State**: Shows search icon and suggested questions
- **User Messages**: Right-aligned, blue background
- **Assistant Messages**: Left-aligned, glass effect
- **Sources**: Clickable links to external sources
- **Timestamps**: Shows when each message was sent
- **Scrollable**: Auto-scrolls to latest message

#### Suggested Questions (Empty State)
- "How can I improve this post?"
- "What hashtags should I use?"
- "When is the best time to post this?"
- "How can I make the hook more engaging?"

#### Input Area
- **Text Input**: Glass effect, placeholder text
- **Send Button**: Primary color, disabled when empty
- **Keyboard Shortcut**: Press Enter to send

#### Loading State
- Shows "Searching and analyzing... This may take up to 30 seconds."
- Animated spinner icon
- Prevents multiple simultaneous requests

## Technical Implementation

### Architecture

```
User Input → AISearchPanel Component → Edge Function → AI Search API → Response
                                                              ↓
                                                         Web Search
                                                              ↓
                                                        AI Analysis
```

### Components

#### 1. AISearchPanel Component
**Location**: `src/components/analysis/AISearchPanel.tsx`

**Props**:
- `postContent: string` - The LinkedIn post content for context

**State**:
- `messages: Message[]` - Chat message history
- `query: string` - Current user input
- `loading: boolean` - Loading state
- `error: string | null` - Error message

**Key Functions**:
- `handleSearch()` - Sends query to Edge Function
- `handleKeyPress()` - Handles Enter key to send
- `scrollToBottom()` - Auto-scrolls to latest message

#### 2. Edge Function: ai-search
**Location**: `supabase/functions/ai-search/index.ts`

**Input**:
```typescript
{
  query: string,        // User's question
  postContent: string   // LinkedIn post content (optional)
}
```

**Output**:
```typescript
{
  answer: string,       // AI-generated answer
  sources: Array<{      // Source citations
    title: string,
    url: string
  }>,
  query: string         // Original query
}
```

**Environment Variables**:
- `INTEGRATIONS_API_KEY` - API key for AI Search service

**Error Handling**:
- Missing query validation
- API key validation
- Network error handling
- Timeout handling (30+ seconds)

### API Integration

#### AI Search API
**Endpoint**: `https://api.miaoda.tech/api/v1/ai-search`

**Method**: POST

**Headers**:
```json
{
  "Content-Type": "application/json",
  "Authorization": "Bearer {INTEGRATIONS_API_KEY}"
}
```

**Request Body**:
```json
{
  "query": "Enhanced query with post context",
  "stream": false
}
```

**Response**:
```json
{
  "answer": "AI-generated answer text",
  "sources": [
    {
      "title": "Source Title",
      "url": "https://example.com"
    }
  ]
}
```

**Important Notes**:
- First token may take up to 30 seconds
- Non-streaming mode for simpler handling
- Automatic context enhancement with post content

### Context Enhancement

When a user asks a question, the Edge Function automatically enhances the query with post context:

**Original Query**:
```
"How can I improve this post?"
```

**Enhanced Query**:
```
Context: I wrote this LinkedIn post: "Just launched our new SaaS product! 🚀 After 6 months of development..."

Question: How can I improve this post?
```

This provides the AI with necessary context for more relevant answers.

## User Flow

### 1. Initial State (Before Analysis)
- AI Search Panel is hidden
- User writes post in Drafting Board
- User clicks "Analyze Reach"

### 2. After Analysis
- AI Search Panel appears at bottom
- Shows empty state with suggested questions
- User can click suggested question or type their own

### 3. Asking a Question
1. User types question or clicks suggested question
2. Question appears in chat as user message
3. Loading indicator appears
4. "Searching and analyzing..." message shown
5. Wait up to 30 seconds for response

### 4. Receiving Answer
1. Assistant message appears with answer
2. Sources are listed (if available)
3. Timestamp is shown
4. Chat scrolls to latest message
5. User can ask follow-up questions

### 5. Error Handling
- If API fails, error alert is shown
- User message is removed
- User can retry the question
- Error message explains what went wrong

## Best Practices

### For Users

1. **Be Specific**: Ask specific questions about your post
   - ❌ "Is this good?"
   - ✅ "How can I make the hook more engaging?"

2. **One Question at a Time**: Wait for response before asking next question
   - Prevents confusion and ensures context is maintained

3. **Use Context**: The AI knows your post content, so reference it
   - ✅ "Should I add more data to this post?"
   - ✅ "Is my CTA strong enough?"

4. **Explore Different Topics**:
   - Post improvement suggestions
   - Hashtag recommendations
   - Timing and scheduling advice
   - Engagement strategies
   - Industry trends

### For Developers

1. **Timeout Handling**: Always set appropriate timeouts (30+ seconds)
2. **Error Messages**: Provide clear, actionable error messages
3. **Loading States**: Show progress indicators for long operations
4. **Context Management**: Always include post content for better answers
5. **Source Citations**: Display sources for transparency

## Troubleshooting

### Issue: "API key not configured"

**Cause**: `INTEGRATIONS_API_KEY` environment variable not set

**Solution**:
1. Go to Supabase Dashboard
2. Navigate to Edge Functions → ai-search
3. Add environment variable: `INTEGRATIONS_API_KEY`
4. Redeploy the Edge Function

### Issue: "Failed to get AI response"

**Cause**: Network error or API timeout

**Solution**:
1. Check internet connection
2. Verify Supabase project is accessible
3. Check Edge Function logs for detailed error
4. Retry the request

### Issue: Request takes too long (>30 seconds)

**Cause**: AI Search API processing time

**Solution**:
- This is normal for the first token
- Loading message informs user to wait
- If consistently slow, check API status

### Issue: No sources in response

**Cause**: AI Search didn't find relevant sources

**Solution**:
- This is normal for some queries
- Answer is still provided without sources
- Try rephrasing the question

### Issue: Answer not relevant to post

**Cause**: Context not properly included

**Solution**:
1. Verify `postContent` is passed to Edge Function
2. Check Edge Function logs for context enhancement
3. Ensure post content is not empty

## Performance Considerations

### Response Time
- **First Token**: Up to 30 seconds (AI Search API processing)
- **Full Response**: 30-45 seconds typically
- **Subsequent Requests**: Similar timing (each is independent)

### Optimization Tips
1. **Non-Streaming Mode**: Simpler implementation, single response
2. **Context Truncation**: Limit post content to 500 characters for context
3. **Error Handling**: Fail fast on validation errors
4. **Loading Indicators**: Keep user informed during wait

### Rate Limiting
- No explicit rate limiting implemented
- Users naturally rate-limited by response time
- Consider adding rate limiting if needed

## Security Considerations

### API Key Protection
- ✅ API key stored in Edge Function environment
- ✅ Never exposed to client-side code
- ✅ Accessed only by Edge Function

### Input Validation
- ✅ Query required validation
- ✅ Empty query rejection
- ✅ Post content sanitization

### Output Sanitization
- ✅ Sources validated as URLs
- ✅ Answer text displayed safely
- ✅ No script injection possible

## Future Enhancements

### Planned Features
1. **Streaming Responses**: Real-time token streaming for faster perceived response
2. **Message History Persistence**: Save chat history to database
3. **Follow-up Context**: Maintain conversation context across messages
4. **Voice Input**: Ask questions using voice
5. **Export Chat**: Download chat history as PDF/text
6. **Suggested Follow-ups**: AI suggests next questions
7. **Multi-language Support**: Ask questions in any language
8. **Image Analysis**: Upload images and ask about them

### Potential Improvements
1. **Caching**: Cache common questions for faster responses
2. **Rate Limiting**: Prevent abuse with rate limits
3. **Analytics**: Track popular questions and topics
4. **Feedback System**: Let users rate answer quality
5. **Custom Prompts**: Allow users to customize AI behavior

## Testing Checklist

### Functional Testing
- [ ] AI Search Panel appears after analysis
- [ ] Suggested questions are clickable
- [ ] User can type custom questions
- [ ] Enter key sends message
- [ ] Loading indicator appears during search
- [ ] Answer appears after search completes
- [ ] Sources are clickable and open in new tab
- [ ] Chat scrolls to latest message
- [ ] Multiple questions can be asked
- [ ] Error messages display correctly

### Edge Cases
- [ ] Empty query is rejected
- [ ] Very long query (1000+ characters)
- [ ] Special characters in query
- [ ] Network error handling
- [ ] API timeout handling
- [ ] No sources in response
- [ ] Empty post content
- [ ] Rapid successive questions

### Performance Testing
- [ ] Response time under 45 seconds
- [ ] Loading indicator shows immediately
- [ ] No UI freezing during search
- [ ] Smooth scrolling in chat
- [ ] Memory usage acceptable

### Security Testing
- [ ] API key not exposed in client
- [ ] XSS prevention in messages
- [ ] URL validation for sources
- [ ] Input sanitization

## Support

### For Users
- **Documentation**: See this file
- **Quick Start**: Click suggested questions to get started
- **Tips**: Hover over info icon for tips

### For Developers
- **Edge Function Logs**: Supabase Dashboard → Edge Functions → ai-search → Logs
- **API Documentation**: AI Search API docs
- **Component Code**: `src/components/analysis/AISearchPanel.tsx`
- **Edge Function Code**: `supabase/functions/ai-search/index.ts`

---

**Last Updated**: 2026-02-28  
**Version**: 1.0.0  
**Status**: Production Ready

# AI Analysis Troubleshooting Guide

## Issue: "AI Analysis Failed - Falling back to standard analysis"

### What Was Fixed

1. **Enhanced Error Logging**
   - Added detailed console logging in Edge Function
   - Added error context extraction in frontend
   - Now logs every step of the AI analysis process

2. **Redeployed Edge Function**
   - Edge Function `analyze-post` redeployed with plugin ID: b17b019e-e71c-457f-93ef-619824a3e6db
   - INTEGRATIONS_API_KEY automatically injected
   - Connected to Gemini 2.5 Flash API

3. **Improved Error Handling**
   - Better error messages with context
   - Graceful fallback to standard analysis
   - Database insert errors no longer break the function

### How to Debug

#### Step 1: Check Browser Console

After clicking "Analyze Reach", open browser DevTools (F12) and check the Console tab for:

```
Calling AI analysis Edge Function...
AI Analysis Response: { data: ..., error: ... }
```

**If you see an error**, look for:
- `AI Analysis Error:` - Shows the error object
- `Error details:` - Shows error message and context
- `AI Analysis Exception:` - Shows any JavaScript exceptions

#### Step 2: Common Errors and Solutions

##### Error: "INTEGRATIONS_API_KEY not configured"
**Cause**: API key not set in Edge Function environment  
**Solution**: Edge Function should have been deployed with plugin ID - try redeploying

##### Error: "LLM API failed with status 401"
**Cause**: Invalid or expired API key  
**Solution**: Check that plugin ID b17b019e-e71c-457f-93ef-619824a3e6db is correct

##### Error: "LLM API failed with status 429"
**Cause**: Rate limit exceeded  
**Solution**: Wait a few minutes and try again

##### Error: "Failed to parse AI analysis response"
**Cause**: LLM returned invalid JSON  
**Solution**: Check Edge Function logs for the full response

##### Error: "Content and niche are required"
**Cause**: Missing required fields in request  
**Solution**: Make sure you've written a post and selected a niche

##### Error: "Network error" or "Failed to fetch"
**Cause**: Edge Function not deployed or network issue  
**Solution**: Check internet connection, verify Edge Function is deployed

#### Step 3: Check Edge Function Logs

To see detailed Edge Function logs:

1. Go to Supabase Dashboard: https://app.supabase.com/project/cgaavihuckojsrolsapn/logs/edge-functions
2. Select `analyze-post` function
3. Look for recent logs showing:
   - "Analyze-post function called"
   - "Request params: ..."
   - "INTEGRATIONS_API_KEY exists: true"
   - "Calling LLM API..."
   - "LLM API Response Status: 200"
   - "Parsing SSE response..."
   - "Successfully parsed analysis result"
   - "Returning analysis result"

**If you see errors in the logs**, they will show exactly what went wrong.

#### Step 4: Test with Simple Post

Try analyzing a very simple post to rule out content issues:

```
I love LinkedIn.

It helps me connect with professionals.

What's your favorite platform?
```

Select niche: "General"

If this works, the issue might be with longer or more complex posts.

### What to Check

1. **User is Logged In**
   - AI analysis only works when logged in
   - Check that you see your profile in the header

2. **AI Toggle is Enabled**
   - Look for "AI-Powered Analysis" toggle
   - Make sure it shows "Enabled" (green)

3. **Post Content**
   - Make sure you've written some text
   - Minimum 10 characters recommended

4. **Niche Selected**
   - Make sure you've selected a niche from the dropdown
   - Default is "General"

5. **Internet Connection**
   - AI analysis requires internet connection
   - Check that you can access other websites

### Expected Behavior

When AI analysis works correctly:

1. Click "Analyze Reach" button
2. See 30-second countdown timer
3. Console shows: "Calling AI analysis Edge Function..."
4. After ~5-30 seconds, console shows: "AI Analysis Success: ..."
5. "AI Insights" tab shows comprehensive analysis
6. No error toast appears

### Fallback Behavior

If AI analysis fails:

1. Red toast appears: "AI Analysis Failed - Falling back to standard analysis"
2. Standard analysis runs instead
3. "Standard" tab shows results
4. "AI Insights" tab shows empty state
5. You can still use all other features

### Manual Test

To manually test the Edge Function, you can use curl:

```bash
curl -X POST https://cgaavihuckojsrolsapn.supabase.co/functions/v1/analyze-post \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -d '{
    "content": "I love LinkedIn. It helps me connect with professionals. What is your favorite platform?",
    "niche": "General"
  }'
```

Replace `YOUR_ANON_KEY` with the anon key from .env file.

**Expected response**: JSON object with score, grade, insights, etc.

### Still Not Working?

If AI analysis still fails after checking all the above:

1. **Check Supabase Status**
   - Go to: https://status.supabase.com/
   - Make sure all services are operational

2. **Check API Gateway Status**
   - The LLM API endpoint might be down
   - Try again in a few minutes

3. **Try Standard Analysis**
   - Toggle AI-Powered Analysis to "Disabled"
   - Use standard analysis instead
   - All features still work

4. **Report the Issue**
   - Copy the error from browser console
   - Copy the Edge Function logs from Supabase Dashboard
   - Share both for debugging

### Logging Details

The Edge Function now logs:
- Function invocation
- Request parameters (content length, niche, userId)
- API key existence check
- LLM API call status
- Response parsing progress
- Full response preview
- Database storage status
- Final result return

The frontend now logs:
- Edge Function call initiation
- Response data and error
- Error message and context
- Success confirmation

### Next Steps

1. **Test the AI Analysis**
   - Write a LinkedIn post
   - Select a niche
   - Click "Analyze Reach"
   - Check browser console for logs

2. **If It Works**
   - Great! AI analysis is now functional
   - Check the "AI Insights" tab for results

3. **If It Fails**
   - Check browser console for error details
   - Check Edge Function logs in Supabase Dashboard
   - Follow the troubleshooting steps above
   - Report the specific error message

---

**Status**: Enhanced logging deployed  
**Edge Function**: analyze-post (redeployed)  
**Plugin ID**: b17b019e-e71c-457f-93ef-619824a3e6db  
**API**: Gemini 2.5 Flash  
**Last Updated**: 2026-02-28

# 🔧 Fix Google Sign-In Error: "Unsupported provider: provider is not enabled"

## The Problem

You're seeing this error:
```json
{"code":400,"error_code":"validation_failed","msg":"Unsupported provider: provider is not enabled"}
```

**This means**: Google OAuth is not enabled in your Supabase project.

## The Solution (5 Minutes)

### Step 1: Get Google OAuth Credentials

1. **Go to Google Cloud Console**: https://console.cloud.google.com/

2. **Create or Select a Project**:
   - Click the project dropdown at the top
   - Click "New Project" or select existing project
   - Name it (e.g., "Linked-Optima")

3. **Enable Google+ API**:
   - Go to "APIs & Services" → "Library"
   - Search for "Google+ API"
   - Click "Enable"

4. **Configure OAuth Consent Screen**:
   - Go to "APIs & Services" → "OAuth consent screen"
   - Select "External" user type
   - Click "Create"
   - Fill in required fields:
     - App name: "Linked-Optima"
     - User support email: your email
     - Developer contact: your email
   - Click "Save and Continue"
   - Skip "Scopes" (click "Save and Continue")
   - Add test users (your email) if in testing mode
   - Click "Save and Continue"

5. **Create OAuth 2.0 Client ID**:
   - Go to "APIs & Services" → "Credentials"
   - Click "Create Credentials" → "OAuth 2.0 Client ID"
   - Application type: "Web application"
   - Name: "Linked-Optima Web Client"
   - **Authorized JavaScript origins**:
     - Add: `https://upxgbldhftcjldbgdehu.supabase.co`
     - Add: `http://localhost:5173` (for local development)
   - **Authorized redirect URIs**:
     - Add: `https://upxgbldhftcjldbgdehu.supabase.co/auth/v1/callback`
   - Click "Create"
   - **Copy the Client ID and Client Secret** (you'll need these next)

### Step 2: Enable Google in Supabase

1. **Go to Supabase Dashboard**: https://supabase.com/dashboard

2. **Select Your Project**: `upxgbldhftcjldbgdehu`

3. **Navigate to Authentication**:
   - Click "Authentication" in the left sidebar
   - Click "Providers" tab

4. **Enable Google Provider**:
   - Scroll down to find "Google" in the provider list
   - Click on "Google" to expand it
   - Toggle the switch to **Enable**

5. **Configure Google Credentials**:
   - Paste your **Client ID** from Google Cloud Console
   - Paste your **Client Secret** from Google Cloud Console
   - Click **Save**

### Step 3: Test It

1. **Refresh your application** (hard refresh: Ctrl+Shift+R or Cmd+Shift+R)
2. **Click "Continue with Google"**
3. **You should see Google's consent screen** ✅
4. **Authorize the app**
5. **You're logged in!** 🎉

## Visual Guide

### Google Cloud Console - OAuth Client ID Setup

```
┌─────────────────────────────────────────────────────────┐
│ Create OAuth client ID                                  │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Application type: [Web application ▼]                  │
│                                                         │
│ Name: Linked-Optima Web Client                         │
│                                                         │
│ Authorized JavaScript origins:                          │
│ ┌─────────────────────────────────────────────────┐   │
│ │ https://upxgbldhftcjldbgdehu.supabase.co        │   │
│ │ http://localhost:5173                            │   │
│ └─────────────────────────────────────────────────┘   │
│                                                         │
│ Authorized redirect URIs:                               │
│ ┌─────────────────────────────────────────────────┐   │
│ │ https://upxgbldhftcjldbgdehu.supabase.co/auth/  │   │
│ │ v1/callback                                      │   │
│ └─────────────────────────────────────────────────┘   │
│                                                         │
│                    [Create]                             │
└─────────────────────────────────────────────────────────┘
```

### Supabase Dashboard - Google Provider Setup

```
┌─────────────────────────────────────────────────────────┐
│ Authentication > Providers > Google                     │
├─────────────────────────────────────────────────────────┤
│                                                         │
│ Enable Sign in with Google: [ON] ✅                    │
│                                                         │
│ Client ID (for OAuth):                                  │
│ ┌─────────────────────────────────────────────────┐   │
│ │ 123456789-abc.apps.googleusercontent.com        │   │
│ └─────────────────────────────────────────────────┘   │
│                                                         │
│ Client Secret (for OAuth):                              │
│ ┌─────────────────────────────────────────────────┐   │
│ │ GOCSPX-••••••••••••••••••••                     │   │
│ └─────────────────────────────────────────────────┘   │
│                                                         │
│                    [Save]                               │
└─────────────────────────────────────────────────────────┘
```

## Troubleshooting

### Issue: Can't find "Google+ API"
**Solution**: Search for "Google People API" instead (Google+ is deprecated, but the OAuth still works)

### Issue: "redirect_uri_mismatch" error
**Solution**: 
1. Double-check the redirect URI in Google Cloud Console
2. It must be EXACTLY: `https://upxgbldhftcjldbgdehu.supabase.co/auth/v1/callback`
3. No trailing slash, no extra characters
4. Wait 5 minutes after saving for changes to propagate

### Issue: "Access blocked: This app's request is invalid"
**Solution**:
1. Make sure OAuth consent screen is configured
2. Add your email as a test user
3. If you want public access, publish the app (go to OAuth consent screen → "Publish App")

### Issue: Still getting "provider is not enabled" after configuration
**Solution**:
1. Make sure you clicked "Save" in Supabase Dashboard
2. Wait 1-2 minutes for changes to propagate
3. Hard refresh your application (Ctrl+Shift+R)
4. Clear browser cache if needed
5. Check Supabase Dashboard to confirm Google provider shows as "Enabled"

## Quick Checklist

Before testing, make sure:

- [ ] Google Cloud Console project created
- [ ] OAuth consent screen configured
- [ ] OAuth 2.0 Client ID created
- [ ] Authorized redirect URI added: `https://upxgbldhftcjldbgdehu.supabase.co/auth/v1/callback`
- [ ] Client ID and Client Secret copied
- [ ] Supabase Dashboard opened
- [ ] Project `upxgbldhftcjldbgdehu` selected
- [ ] Authentication → Providers → Google opened
- [ ] Google provider enabled (toggle ON)
- [ ] Client ID pasted
- [ ] Client Secret pasted
- [ ] Changes saved
- [ ] Application refreshed

## Expected Result

After configuration, when you click "Continue with Google":

1. ✅ You'll be redirected to Google's consent screen
2. ✅ You'll see: "Linked-Optima wants to access your Google Account"
3. ✅ You'll see permissions: "See your personal info, including any personal info you've made publicly available"
4. ✅ After clicking "Continue", you'll be redirected back to your app
5. ✅ You'll be logged in automatically
6. ✅ Your profile will be created/loaded

## Need Help?

If you're still having issues after following these steps:

1. **Check Supabase logs**:
   - Go to Supabase Dashboard → Logs → Auth Logs
   - Look for error messages

2. **Check browser console**:
   - Open Developer Tools (F12)
   - Go to Console tab
   - Look for error messages

3. **Verify configuration**:
   - Supabase Dashboard → Authentication → Providers → Google
   - Make sure it shows "Enabled" with a green checkmark

---

**Estimated Time**: 5-10 minutes  
**Difficulty**: Easy  
**Cost**: Free (Google Cloud and Supabase free tiers)

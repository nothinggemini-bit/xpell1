import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Send, Loader2, Sparkles, ExternalLink, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/db/supabase';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  sources?: Array<{ title: string; url: string }>;
  timestamp: Date;
}

interface AISearchPanelProps {
  postContent: string;
}

export const AISearchPanel: React.FC<AISearchPanelProps> = ({ postContent }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSearch = async () => {
    if (!query.trim() || loading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: query,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setQuery('');
    setLoading(true);
    setError(null);

    try {
      console.log('Sending AI Search request...');
      
      const { data, error: searchError } = await supabase.functions.invoke('ai-search', {
        body: {
          query: query,
          postContent: postContent,
        },
      });

      if (searchError) {
        console.error('AI Search error:', searchError);
        
        // Check for specific error types
        if (searchError.message?.includes('API key not configured')) {
          throw new Error('AI Search is not configured yet. Please contact the administrator to set up the INTEGRATIONS_API_KEY.');
        }
        
        throw new Error(searchError.message || 'Failed to get AI response');
      }

      // Check if data contains an error
      if (data?.error) {
        console.error('AI Search API error:', data.error, data.details);
        
        if (data.error.includes('API key not configured')) {
          throw new Error('AI Search is not configured yet. Please contact the administrator to set up the INTEGRATIONS_API_KEY.');
        }
        
        throw new Error(data.error || 'Failed to get AI response');
      }

      console.log('AI Search response:', data);

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: data.answer || 'No answer found',
        sources: data.sources || [],
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (err: any) {
      console.error('AI Search exception:', err);
      setError(err.message || 'Failed to get AI response. Please try again.');
      
      // Remove user message if request failed
      setMessages(prev => prev.filter(m => m.id !== userMessage.id));
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSearch();
    }
  };

  const suggestedQuestions = [
    'How can I improve this post?',
    'What hashtags should I use?',
    'When is the best time to post this?',
    'How can I make the hook more engaging?',
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass p-6 rounded-lg space-y-4"
    >
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-lg bg-primary/10">
          <Sparkles className="text-primary" size={24} />
        </div>
        <div>
          <h3 className="text-lg font-semibold">AI Search Assistant</h3>
          <p className="text-sm text-muted-foreground">
            Ask questions about your post and get AI-powered insights
          </p>
        </div>
      </div>

      {/* Messages Area */}
      <div className="space-y-4 min-h-[300px] max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-[300px] space-y-4">
            <Search className="text-muted-foreground" size={48} />
            <div className="text-center space-y-2">
              <p className="text-sm text-muted-foreground">
                No questions yet. Try asking something about your post!
              </p>
              <div className="flex flex-wrap gap-2 justify-center mt-4">
                {suggestedQuestions.map((question, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="glass text-xs"
                    onClick={() => setQuery(question)}
                    disabled={loading}
                  >
                    {question}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <AnimatePresence>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-4 ${
                    message.type === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'glass border border-border/50'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  
                  {/* Sources */}
                  {message.sources && message.sources.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-border/50 space-y-2">
                      <p className="text-xs font-semibold opacity-70">Sources:</p>
                      {message.sources.map((source, index) => (
                        <a
                          key={index}
                          href={source.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 text-xs hover:underline opacity-80 hover:opacity-100 transition-opacity"
                        >
                          <ExternalLink size={12} />
                          <span>{source.title}</span>
                        </a>
                      ))}
                    </div>
                  )}
                  
                  <p className="text-xs opacity-50 mt-2">
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}

        {/* Loading Indicator */}
        {loading && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-start"
          >
            <div className="glass border border-border/50 rounded-lg p-4 max-w-[80%]">
              <div className="flex items-center gap-2">
                <Loader2 className="animate-spin text-primary" size={16} />
                <p className="text-sm text-muted-foreground">
                  Searching and analyzing... This may take up to 30 seconds.
                </p>
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Error Alert */}
      {error && (
        <Alert variant="destructive" className="glass">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Input Area */}
      <div className="flex gap-2">
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask a question about your post..."
          disabled={loading}
          className="glass flex-1"
        />
        <Button
          onClick={handleSearch}
          disabled={!query.trim() || loading}
          className="cursor-target"
        >
          {loading ? (
            <Loader2 className="animate-spin" size={20} />
          ) : (
            <Send size={20} />
          )}
        </Button>
      </div>

      {/* Info */}
      <p className="text-xs text-muted-foreground text-center">
        💡 Tip: Ask specific questions about your post content, engagement strategies, or LinkedIn best practices
      </p>
    </motion.div>
  );
};

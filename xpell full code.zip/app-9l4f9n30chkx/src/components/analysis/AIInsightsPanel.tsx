import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Sparkles, TrendingUp, AlertTriangle, CheckCircle, Lightbulb, Hash, FileText } from 'lucide-react';
import { motion } from 'framer-motion';

interface AIAnalysisResult {
  score: number;
  grade: string;
  insights: string[];
  improvements: {
    hook: string;
    structure: string;
    hashtags: string[];
    formatting: string;
    cta: string;
  };
  paragraphAnalysis: {
    totalParagraphs: number;
    avgLinesPerParagraph: number;
    longParagraphs: number;
    recommendation: string;
  };
  strengths: string[];
  weaknesses: string[];
  viralPotential: string;
  reasoning: string;
}

interface AIInsightsPanelProps {
  analysis: AIAnalysisResult;
}

export const AIInsightsPanel: React.FC<AIInsightsPanelProps> = ({ analysis }) => {
  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-success';
    if (score >= 80) return 'text-primary';
    if (score >= 70) return 'text-warning';
    return 'text-destructive';
  };

  const getGradeBadgeVariant = (grade: string): "default" | "secondary" | "destructive" | "outline" => {
    if (grade === 'Exceptional' || grade === 'Excellent') return 'default';
    if (grade === 'Very Good' || grade === 'Good') return 'secondary';
    if (grade === 'Fair') return 'outline';
    return 'destructive';
  };

  const getViralPotentialColor = (potential: string) => {
    if (potential === 'Very High') return 'text-success';
    if (potential === 'High') return 'text-primary';
    if (potential === 'Medium') return 'text-warning';
    return 'text-destructive';
  };

  return (
    <div className="space-y-4">
      {/* Main Score Card */}
      <Card className="glass border-primary/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="text-primary" size={20} />
              <CardTitle className="text-lg">AI-Powered Analysis</CardTitle>
            </div>
            <Badge variant={getGradeBadgeVariant(analysis.grade)}>
              {analysis.grade}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            Analyzed by AI trained on 34,000+ viral posts
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Score Display */}
          <div className="text-center p-6 rounded-lg bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20">
            <div className={`text-5xl font-bold text-mono mb-2 ${getScoreColor(analysis.score)}`}>
              {analysis.score}%
            </div>
            <p className="text-sm text-muted-foreground mb-3">Viral Score</p>
            <Progress value={analysis.score} className="h-2 mb-3" />
            <p className="text-xs text-muted-foreground italic">{analysis.reasoning}</p>
          </div>

          {/* Viral Potential */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-card/50 border border-white/10">
            <span className="text-sm text-muted-foreground">Viral Potential:</span>
            <span className={`text-sm font-semibold ${getViralPotentialColor(analysis.viralPotential)}`}>
              {analysis.viralPotential}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Key Insights */}
      <Card className="glass border-success/20">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Lightbulb className="text-success" size={20} />
            <CardTitle className="text-lg">Key Insights</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-2">
          {analysis.insights.map((insight, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-start gap-2 p-2 rounded bg-success/5"
            >
              <CheckCircle className="text-success shrink-0 mt-0.5" size={16} />
              <p className="text-sm text-muted-foreground">{insight}</p>
            </motion.div>
          ))}
        </CardContent>
      </Card>

      {/* Strengths & Weaknesses */}
      <div className="grid md:grid-cols-2 gap-4">
        {/* Strengths */}
        <Card className="glass border-success/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="text-success" size={18} />
              <CardTitle className="text-base">Strengths</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {analysis.strengths.map((strength, index) => (
              <div key={index} className="flex items-start gap-2 text-sm">
                <span className="text-success shrink-0">✓</span>
                <p className="text-muted-foreground">{strength}</p>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Weaknesses */}
        <Card className="glass border-destructive/20">
          <CardHeader>
            <div className="flex items-center gap-2">
              <AlertTriangle className="text-destructive" size={18} />
              <CardTitle className="text-base">Weaknesses</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {analysis.weaknesses.map((weakness, index) => (
              <div key={index} className="flex items-start gap-2 text-sm">
                <span className="text-destructive shrink-0">✗</span>
                <p className="text-muted-foreground">{weakness}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Paragraph Analysis */}
      <Card className="glass border-warning/20">
        <CardHeader>
          <div className="flex items-center gap-2">
            <FileText className="text-warning" size={20} />
            <CardTitle className="text-lg">Paragraph Structure Analysis</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center p-3 rounded-lg bg-muted/30 border border-white/10">
              <div className="text-xl font-bold text-mono text-primary">{analysis.paragraphAnalysis.totalParagraphs}</div>
              <div className="text-xs text-muted-foreground">Paragraphs</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/30 border border-white/10">
              <div className="text-xl font-bold text-mono text-primary">{analysis.paragraphAnalysis.avgLinesPerParagraph.toFixed(1)}</div>
              <div className="text-xs text-muted-foreground">Avg Lines/Para</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-muted/30 border border-white/10">
              <div className="text-xl font-bold text-mono text-warning">{analysis.paragraphAnalysis.longParagraphs}</div>
              <div className="text-xs text-muted-foreground">Long Paras</div>
            </div>
          </div>
          <div className="p-3 rounded-lg bg-warning/5 border border-warning/20">
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-warning">Recommendation:</span> {analysis.paragraphAnalysis.recommendation}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Improvements */}
      <Card className="glass border-primary/20">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Sparkles className="text-primary" size={20} />
            <CardTitle className="text-lg">AI Improvement Suggestions</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {/* Hook Improvement */}
          <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
            <h4 className="text-sm font-semibold text-primary mb-2">🎣 Hook Improvement:</h4>
            <p className="text-sm text-muted-foreground">{analysis.improvements.hook}</p>
          </div>

          {/* Structure Improvement */}
          <div className="p-3 rounded-lg bg-success/5 border border-success/20">
            <h4 className="text-sm font-semibold text-success mb-2">📝 Structure Improvement:</h4>
            <p className="text-sm text-muted-foreground">{analysis.improvements.structure}</p>
          </div>

          {/* Formatting Improvement */}
          <div className="p-3 rounded-lg bg-warning/5 border border-warning/20">
            <h4 className="text-sm font-semibold text-warning mb-2">✨ Formatting Improvement:</h4>
            <p className="text-sm text-muted-foreground">{analysis.improvements.formatting}</p>
          </div>

          {/* CTA Improvement */}
          <div className="p-3 rounded-lg bg-destructive/5 border border-destructive/20">
            <h4 className="text-sm font-semibold text-destructive mb-2">💬 CTA Improvement:</h4>
            <p className="text-sm text-muted-foreground">{analysis.improvements.cta}</p>
          </div>

          {/* Hashtag Suggestions */}
          <div className="p-3 rounded-lg bg-card/50 border border-primary/20">
            <h4 className="text-sm font-semibold text-primary mb-2 flex items-center gap-2">
              <Hash size={16} />
              Suggested Hashtags:
            </h4>
            <div className="flex flex-wrap gap-2">
              {analysis.improvements.hashtags.map((tag, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

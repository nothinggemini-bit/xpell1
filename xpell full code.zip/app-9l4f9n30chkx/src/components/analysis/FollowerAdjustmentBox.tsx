import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Users, TrendingUp, TrendingDown } from 'lucide-react';
import { motion } from 'framer-motion';

interface FollowerAdjustmentBoxProps {
  followerCount: number;
  onFollowerCountChange: (count: number) => void;
  adjustment: number;
}

const getFollowerTier = (count: number): { tier: string; adjustment: number; color: string } => {
  if (count < 500) {
    return { tier: 'Emerging Creator', adjustment: -4, color: 'text-destructive' };
  } else if (count < 2000) {
    return { tier: 'Growing Voice', adjustment: 0, color: 'text-muted-foreground' };
  } else if (count < 12000) {
    return { tier: 'Established Creator', adjustment: 4, color: 'text-primary' };
  } else if (count < 40000) {
    return { tier: 'Influential Voice', adjustment: 7, color: 'text-primary' };
  } else if (count < 100000) {
    return { tier: 'Industry Leader', adjustment: 10, color: 'text-success' };
  } else {
    return { tier: 'Thought Leader', adjustment: 15, color: 'text-success' };
  }
};

export const FollowerAdjustmentBox: React.FC<FollowerAdjustmentBoxProps> = ({
  followerCount,
  onFollowerCountChange,
  adjustment
}) => {
  const tierInfo = getFollowerTier(followerCount);
  const isPositive = tierInfo.adjustment >= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass p-4 rounded-lg space-y-3"
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="text-primary" size={18} />
          <Label htmlFor="follower-count" className="text-sm font-semibold">
            Follower Count
          </Label>
        </div>
        <div className={`flex items-center gap-1 ${tierInfo.color}`}>
          {isPositive ? (
            <TrendingUp size={16} />
          ) : (
            <TrendingDown size={16} />
          )}
          <span className="text-sm font-bold">
            {isPositive ? '+' : ''}{tierInfo.adjustment}%
          </span>
        </div>
      </div>

      <Input
        id="follower-count"
        type="number"
        min={0}
        value={followerCount}
        onChange={(e) => onFollowerCountChange(parseInt(e.target.value) || 0)}
        className="glass font-mono"
        placeholder="Enter follower count"
      />

      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">{tierInfo.tier}</span>
        <span className={tierInfo.color}>Score Adjustment</span>
      </div>

      <p className="text-xs text-muted-foreground leading-relaxed">
        Building your follower base will improve your viral score. Focus on consistent, quality content.
      </p>
    </motion.div>
  );
};

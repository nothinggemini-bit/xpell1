import React from 'react';
import { Image as ImageIcon, TrendingUp, CheckCircle, AlertTriangle, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

interface ImageAnalysisResult {
  imageUrl: string;
  score: number;
  quality: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  relevance: number;
  professionalAppearance: number;
  insights: string[];
  impressionBoost: number;
}

interface ImageAnalysisResultsProps {
  results: ImageAnalysisResult[];
  totalImpressionBoost: number;
}

export const ImageAnalysisResults: React.FC<ImageAnalysisResultsProps> = ({
  results,
  totalImpressionBoost
}) => {
  const getQualityColor = (quality: string) => {
    switch (quality) {
      case 'Excellent':
        return 'text-green-500';
      case 'Good':
        return 'text-blue-500';
      case 'Fair':
        return 'text-yellow-500';
      case 'Poor':
        return 'text-red-500';
      default:
        return 'text-muted-foreground';
    }
  };

  const getQualityIcon = (quality: string) => {
    switch (quality) {
      case 'Excellent':
      case 'Good':
        return <CheckCircle className="text-green-500" size={20} />;
      case 'Fair':
        return <AlertTriangle className="text-yellow-500" size={20} />;
      case 'Poor':
        return <AlertTriangle className="text-red-500" size={20} />;
      default:
        return <ImageIcon size={20} />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass p-6 rounded-lg space-y-6"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <ImageIcon className="text-primary" size={24} />
          </div>
          <div>
            <h3 className="text-lg font-semibold">Image Analysis</h3>
            <p className="text-sm text-muted-foreground">
              {results.length} image{results.length !== 1 ? 's' : ''} analyzed
            </p>
          </div>
        </div>

        {/* Total Impression Boost */}
        <div className="text-right">
          <div className="flex items-center gap-2 justify-end">
            <TrendingUp className="text-green-500" size={20} />
            <span className="text-2xl font-bold text-green-500">
              +{totalImpressionBoost}%
            </span>
          </div>
          <p className="text-xs text-muted-foreground">Impression Boost</p>
        </div>
      </div>

      {/* Individual Image Results */}
      <div className="space-y-4">
        {results.map((result, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="glass p-4 rounded-lg space-y-3"
          >
            {/* Image Header */}
            <div className="flex items-start gap-4">
              {/* Image Thumbnail */}
              <div className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0">
                <img
                  src={result.imageUrl}
                  alt={`Analysis ${index + 1}`}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Image Info */}
              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {getQualityIcon(result.quality)}
                    <span className={`font-semibold ${getQualityColor(result.quality)}`}>
                      {result.quality}
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold">{result.score}/100</div>
                    <div className="text-xs text-muted-foreground">Quality Score</div>
                  </div>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <div className="text-muted-foreground">Relevance</div>
                    <div className="font-semibold">{result.relevance}%</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Professional</div>
                    <div className="font-semibold">{result.professionalAppearance}%</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Boost</div>
                    <div className="font-semibold text-green-500">+{result.impressionBoost}%</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Insights */}
            {result.insights.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <Sparkles size={14} className="text-primary" />
                  <span>AI Insights</span>
                </div>
                <ul className="space-y-1">
                  {result.insights.map((insight, i) => (
                    <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                      <span className="text-primary mt-0.5">•</span>
                      <span>{insight}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </motion.div>
        ))}
      </div>

      {/* Summary */}
      <div className="glass p-4 rounded-lg bg-primary/5 border border-primary/20">
        <div className="flex items-start gap-3">
          <TrendingUp className="text-primary flex-shrink-0 mt-0.5" size={20} />
          <div className="space-y-1">
            <p className="text-sm font-semibold">Impact on Viral Score</p>
            <p className="text-xs text-muted-foreground">
              Your images are predicted to increase post impressions by{' '}
              <span className="text-primary font-semibold">+{totalImpressionBoost}%</span>.
              {totalImpressionBoost >= 15 && ' Excellent visual content!'}
              {totalImpressionBoost >= 10 && totalImpressionBoost < 15 && ' Great visual support!'}
              {totalImpressionBoost >= 5 && totalImpressionBoost < 10 && ' Good visual enhancement.'}
              {totalImpressionBoost < 5 && ' Consider higher quality images for better impact.'}
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

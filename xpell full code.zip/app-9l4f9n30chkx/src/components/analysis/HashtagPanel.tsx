import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Hash, Copy, TrendingUp } from 'lucide-react';
import type { HashtagSuggestion } from '@/lib/hashtag-suggestions';
import { formatHashtagsForPost, getHashtagStrategy } from '@/lib/hashtag-suggestions';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';

interface HashtagPanelProps {
  suggestions: HashtagSuggestion[];
}

export const HashtagPanel: React.FC<HashtagPanelProps> = ({ suggestions }) => {
  const { toast } = useToast();
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const copyHashtag = (tag: string, index: number) => {
    navigator.clipboard.writeText(tag);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
    toast({
      title: 'Copied!',
      description: `${tag} copied to clipboard`,
    });
  };

  const copyAllHashtags = () => {
    const formatted = formatHashtagsForPost(suggestions);
    navigator.clipboard.writeText(formatted);
    toast({
      title: 'All hashtags copied!',
      description: 'Paste them at the end of your post',
    });
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Trending':
        return 'bg-destructive/10 text-destructive border-destructive/20';
      case 'Niche-Specific':
        return 'bg-primary/10 text-primary border-primary/20';
      case 'Engagement-Booster':
        return 'bg-success/10 text-success border-success/20';
      case 'Reach-Expander':
        return 'bg-warning/10 text-warning border-warning/20';
      default:
        return 'bg-muted/10 text-muted-foreground border-muted/20';
    }
  };

  const strategy = getHashtagStrategy(suggestions);

  return (
    <Card className="glass border-primary/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Hash className="text-primary" size={20} />
            <CardTitle className="text-lg">Hashtag Strategy</CardTitle>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={copyAllHashtags}
            className="gap-2"
          >
            <Copy size={14} />
            Copy All
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">
          Optimized hashtags based on your niche and content analysis
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Strategy Explanation */}
        <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
          <p className="text-xs text-muted-foreground">
            <span className="font-semibold text-primary">Strategy:</span> {strategy}
          </p>
        </div>

        {/* Hashtag Grid */}
        <div className="space-y-2">
          {suggestions.map((suggestion, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="p-3 rounded-lg bg-card/50 border border-white/10 hover:border-primary/30 transition-colors"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm font-semibold text-mono text-primary">
                      {suggestion.tag}
                    </span>
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${getCategoryColor(suggestion.category)}`}
                    >
                      {suggestion.category}
                    </Badge>
                  </div>
                  
                  <p className="text-xs text-muted-foreground mb-2">
                    {suggestion.reasoning}
                  </p>
                  
                  <div className="flex items-center gap-2 text-xs">
                    <TrendingUp size={12} className="text-success" />
                    <span className="text-muted-foreground">
                      Est. reach: <span className="font-semibold text-success">{suggestion.estimatedReach}</span>
                    </span>
                  </div>
                </div>
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyHashtag(suggestion.tag, index)}
                  className="h-8 w-8 p-0 shrink-0"
                >
                  {copiedIndex === index ? (
                    <span className="text-success">✓</span>
                  ) : (
                    <Copy size={14} />
                  )}
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Best Practices */}
        <div className="p-3 rounded-lg bg-muted/20 border border-white/10">
          <p className="text-xs text-muted-foreground">
            <span className="font-semibold text-primary">Best Practice:</span> Use 5-7 hashtags max. 
            Place them at the end of your post (not in comments). Mix trending + niche tags for optimal reach.
          </p>
        </div>

        {/* Copy-Paste Ready */}
        <div className="p-3 rounded-lg bg-card/50 border border-primary/20">
          <p className="text-xs text-muted-foreground mb-2 font-semibold">Copy-Paste Ready:</p>
          <p className="text-sm text-mono text-primary break-all">
            {formatHashtagsForPost(suggestions)}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

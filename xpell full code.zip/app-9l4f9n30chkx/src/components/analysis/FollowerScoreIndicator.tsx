import React from 'react';
import { Users, TrendingUp, TrendingDown } from 'lucide-react';
import { motion } from 'framer-motion';

interface FollowerScoreIndicatorProps {
  followersCount: number;
  scoreAdjustment: number;
}

export const FollowerScoreIndicator: React.FC<FollowerScoreIndicatorProps> = ({
  followersCount,
  scoreAdjustment
}) => {
  const getFollowerTier = (count: number): string => {
    if (count < 500) return 'Emerging Creator';
    if (count < 2000) return 'Growing Creator';
    if (count < 12000) return 'Established Creator';
    if (count < 40000) return 'Influential Creator';
    if (count < 100000) return 'Top Creator';
    return 'Elite Creator';
  };

  const formatFollowers = (count: number): string => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  const isPositive = scoreAdjustment > 0;
  const isNegative = scoreAdjustment < 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass p-4 rounded-lg"
    >
      <div className="flex items-center justify-between">
        {/* Follower Info */}
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <Users className="text-primary" size={20} />
          </div>
          <div>
            <div className="text-sm font-semibold">{formatFollowers(followersCount)} Followers</div>
            <div className="text-xs text-muted-foreground">{getFollowerTier(followersCount)}</div>
          </div>
        </div>

        {/* Score Adjustment */}
        <div className="text-right">
          <div className={`flex items-center gap-1 justify-end ${
            isPositive ? 'text-green-500' : isNegative ? 'text-red-500' : 'text-muted-foreground'
          }`}>
            {isPositive && <TrendingUp size={16} />}
            {isNegative && <TrendingDown size={16} />}
            <span className="text-lg font-bold">
              {scoreAdjustment > 0 ? '+' : ''}{scoreAdjustment}%
            </span>
          </div>
          <div className="text-xs text-muted-foreground">Score Adjustment</div>
        </div>
      </div>

      {/* Explanation */}
      <div className="mt-3 pt-3 border-t border-border/50">
        <p className="text-xs text-muted-foreground">
          {isPositive && `Your ${formatFollowers(followersCount)} followers boost your viral potential. Larger audiences increase post reach.`}
          {isNegative && `Building your follower base will improve your viral score. Focus on consistent, quality content.`}
          {!isPositive && !isNegative && `Your follower count is in the neutral range. Keep growing your audience!`}
        </p>
      </div>
    </motion.div>
  );
};

import React from 'react';
import { motion } from 'framer-motion';
import { Bot, User, AlertTriangle } from 'lucide-react';
import { AIDetectionResult } from '@/lib/ai-detector';

interface AIDetectionPanelProps {
  result: AIDetectionResult;
}

export const AIDetectionPanel: React.FC<AIDetectionPanelProps> = ({ result }) => {
  const { score, indicators, confidence } = result;

  // Calculate color based on score (0 = green/human, 100 = red/AI)
  const getColor = (score: number): string => {
    if (score < 30) return 'from-success to-success/80';
    if (score < 60) return 'from-warning to-warning/80';
    return 'from-destructive to-destructive/80';
  };

  const getTextColor = (score: number): string => {
    if (score < 30) return 'text-success';
    if (score < 60) return 'text-warning';
    return 'text-destructive';
  };

  const getLabel = (score: number): string => {
    if (score < 20) return 'Highly Human';
    if (score < 40) return 'Mostly Human';
    if (score < 60) return 'Mixed Signals';
    if (score < 80) return 'Likely AI-Generated';
    return 'Highly AI-Generated';
  };

  const getConfidenceColor = (conf: string): string => {
    if (conf === 'low') return 'text-muted-foreground';
    if (conf === 'medium') return 'text-warning';
    return 'text-destructive';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass p-6 rounded-xl space-y-4"
    >
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="text-primary" size={20} />
          <h3 className="text-lg font-semibold">AI Detection Analysis</h3>
        </div>
        <div className={`text-xs font-mono ${getConfidenceColor(confidence)} uppercase tracking-wider`}>
          {confidence} confidence
        </div>
      </div>

      {/* Score Scale */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-1 text-success">
            <User size={14} />
            <span>Human</span>
          </div>
          <div className="flex items-center gap-1 text-destructive">
            <Bot size={14} />
            <span>AI-Generated</span>
          </div>
        </div>

        {/* Gradient Bar */}
        <div className="relative h-8 rounded-lg overflow-hidden bg-gradient-to-r from-success/20 via-warning/20 to-destructive/20 border border-white/10">
          {/* Score Indicator */}
          <motion.div
            initial={{ left: 0 }}
            animate={{ left: `${score}%` }}
            transition={{ duration: 1, ease: 'easeOut' }}
            className="absolute top-0 bottom-0 w-1 bg-white shadow-lg"
            style={{ transform: 'translateX(-50%)' }}
          >
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 whitespace-nowrap">
              <div className={`text-xs font-bold ${getTextColor(score)}`}>
                {score}%
              </div>
            </div>
          </motion.div>
        </div>

        {/* Label */}
        <div className="text-center">
          <span className={`text-sm font-semibold ${getTextColor(score)}`}>
            {getLabel(score)}
          </span>
        </div>
      </div>

      {/* Indicators */}
      {indicators.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm font-semibold text-muted-foreground">
            <AlertTriangle size={14} />
            <span>AI Indicators Detected:</span>
          </div>
          <div className="space-y-1.5">
            {indicators.map((indicator, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="flex items-start gap-2 text-xs text-muted-foreground bg-white/5 p-2 rounded border border-white/5"
              >
                <span className="text-warning mt-0.5">•</span>
                <span className="flex-1">{indicator}</span>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* No Indicators */}
      {indicators.length === 0 && (
        <div className="text-center py-4">
          <div className="inline-flex items-center gap-2 text-success text-sm">
            <User size={16} />
            <span>No AI patterns detected - looks authentically human!</span>
          </div>
        </div>
      )}

      {/* Info */}
      <div className="text-xs text-muted-foreground leading-relaxed pt-2 border-t border-white/5">
        <p>
          This analysis checks for common AI writing patterns including em dash usage, emoji placement, 
          buzzwords, uniform sentence structure, and lack of personal details. Lower scores indicate 
          more human-like writing.
        </p>
      </div>
    </motion.div>
  );
};

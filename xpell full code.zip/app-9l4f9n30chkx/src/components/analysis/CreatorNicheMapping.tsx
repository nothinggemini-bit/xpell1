import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Users, TrendingUp, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface CreatorData {
  name: string;
  niche: string;
  expertise: string;
  keyMetric: string;
  pattern: string;
}

const CREATOR_DATABASE: CreatorData[] = [
  // B2B Marketing & Strategy
  { name: 'Neil Patel', niche: 'B2B Marketing', expertise: 'Data-backed strategies, SEO', keyMetric: '93+ comments avg', pattern: '46.7% uplift with numbers + visuals' },
  { name: 'Ann Handley', niche: 'B2B Marketing', expertise: 'Writing craft, storytelling', keyMetric: 'High shares', pattern: 'Emotional hooks drive engagement' },
  { name: 'Matt Barker', niche: 'B2B Marketing', expertise: 'Framework lists, scaling', keyMetric: '3x from carousels', pattern: 'Visual frameworks = saves' },
  
  // Entrepreneurship & Growth
  { name: 'Gary Vaynerchuk', niche: 'Entrepreneurship', expertise: 'Volume, consistency, hustle', keyMetric: '312 comments avg', pattern: 'One post = 40% sales growth' },
  { name: 'Ankur Warikoo', niche: 'Entrepreneurship', expertise: 'Personal stories, vulnerability', keyMetric: '100k+ impressions', pattern: '"How I failed" arcs resonate' },
  { name: 'Raj Shamani', niche: 'Entrepreneurship', expertise: 'Motivational content', keyMetric: 'High reposts', pattern: 'Numbers + motivation = viral' },
  
  // Career & Personal Branding
  { name: 'Niharikaa Kaur Sodhi', niche: 'Career', expertise: 'Gen-Z hiring, authenticity', keyMetric: '840+ comments', pattern: 'Polarizing topics spark debate' },
  { name: 'AJ Eckstein', niche: 'Career', expertise: 'Career advice, authenticity', keyMetric: '4k+ likes', pattern: 'Short hooks + PS CTAs = 2x shares' },
  
  // Leadership & Innovation
  { name: 'Simon Sinek', niche: 'Leadership', expertise: 'Timeless wisdom, why-driven', keyMetric: '400k views', pattern: 'Questions drive 2.1x comments' },
  { name: 'Lara Acosta', niche: 'Leadership', expertise: 'Viral rules, frameworks', keyMetric: '99% viral rate', pattern: '8-10 word hooks, lists, colons' },
  { name: 'Dora Vanourek', niche: 'Leadership', expertise: 'Leadership frameworks', keyMetric: 'High engagement', pattern: 'Vulnerability = 3.4x engagement' },
  { name: 'George Stern', niche: 'Leadership', expertise: 'Innovation strategies', keyMetric: 'Strong saves', pattern: 'Counterintuitive advice wins' },
  
  // Design & Creative Strategy
  { name: 'Zander Whitehurst', niche: 'Design', expertise: 'UX/UI education', keyMetric: 'High saves', pattern: 'Accessible education content' },
  { name: 'James Martin', niche: 'Design', expertise: 'Brand scaling for founders', keyMetric: 'Founder audience', pattern: 'Practical brand advice' },
  { name: 'Chris Do', niche: 'Design', expertise: 'Branding + business', keyMetric: 'Strong community', pattern: 'Business + design fusion' },
  { name: 'Julie Zhuo', niche: 'Design', expertise: 'Design leadership', keyMetric: 'Executive reach', pattern: 'Leadership for designers' },
  { name: 'Pablo Stanley', niche: 'Design', expertise: 'Design education', keyMetric: 'High engagement', pattern: 'Fun, accessible teaching' },
  
  // AI & Data Science
  { name: 'Cassie Kozyrkov', niche: 'AI & Data', expertise: 'Decision intelligence', keyMetric: 'Technical audience', pattern: 'Complex topics simplified' },
  { name: 'Andreas Kretz', niche: 'AI & Data', expertise: 'Data engineering', keyMetric: 'Engineer audience', pattern: 'Pipeline architecture insights' },
  
  // HR & Future of Work
  { name: 'Josh Bersin', niche: 'HR & Future of Work', expertise: 'Corporate learning, HR tech', keyMetric: 'C-suite reach', pattern: 'Data-driven HR insights' },
  { name: 'Anshuman Das', niche: 'HR & Future of Work', expertise: 'Tech hiring, talent', keyMetric: 'Startup audience', pattern: 'Hiring best practices' },
  
  // Sales & Revenue
  { name: 'Cynthia Barnes', niche: 'Sales', expertise: 'Women in sales', keyMetric: 'Sales community', pattern: 'Empowerment + tactics' },
  { name: 'Jed Mahrle', niche: 'Sales', expertise: 'Cold outbound, prospecting', keyMetric: 'High engagement', pattern: 'Tactical prospecting tips' },
  
  // Workplace Wellness
  { name: 'Liz Fosslien', niche: 'Workplace Wellness', expertise: 'Emotional intelligence', keyMetric: 'High saves', pattern: 'Relatable workplace emotions' },
  { name: 'Amy Morin', niche: 'Workplace Wellness', expertise: 'Mental toughness', keyMetric: 'Strong shares', pattern: 'Resilience frameworks' },
  
  // Cybersecurity
  { name: 'Kevin Mitnick', niche: 'Cybersecurity', expertise: 'Social engineering', keyMetric: 'Security audience', pattern: 'Real-world threat stories' },
  { name: 'Shira Rubinoff', niche: 'Cybersecurity', expertise: 'Psychology of security', keyMetric: 'Executive reach', pattern: 'Human-centric security' },
  
  // Supply Chain & Logistics
  { name: 'Sheri Hinish', niche: 'Supply Chain', expertise: 'Supply chain strategy', keyMetric: 'Industry leaders', pattern: 'Practical logistics insights' },
  { name: 'Lora Cecere', niche: 'Supply Chain', expertise: 'Supply chain tech', keyMetric: 'Tech adoption', pattern: 'Innovation in logistics' },
];

export const CreatorNicheMapping: React.FC = () => {
  const [selectedNiche, setSelectedNiche] = useState<string>('All');
  
  const niches = ['All', ...Array.from(new Set(CREATOR_DATABASE.map(c => c.niche)))];
  const filteredCreators = selectedNiche === 'All' 
    ? CREATOR_DATABASE 
    : CREATOR_DATABASE.filter(c => c.niche === selectedNiche);

  return (
    <Card className="glass border-primary/20">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <Users className="text-primary" size={20} />
            <CardTitle className="text-lg">Creator Training Database</CardTitle>
          </div>
          <Badge variant="outline" className="text-mono">
            {CREATOR_DATABASE.length} Creators
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          AI trained on posts from these verified creators across multiple niches
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Niche Filter */}
        <div className="flex items-center gap-2 flex-wrap">
          <Filter size={16} className="text-muted-foreground" />
          {niches.map((niche) => (
            <Button
              key={niche}
              variant={selectedNiche === niche ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedNiche(niche)}
              className="text-xs"
            >
              {niche}
            </Button>
          ))}
        </div>

        {/* Creator Grid */}
        <div className="space-y-2 max-h-[500px] overflow-y-auto pr-2">
          <AnimatePresence mode="popLayout">
            {filteredCreators.map((creator, index) => (
              <motion.div
                key={creator.name}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ delay: index * 0.02 }}
                className="p-3 rounded-lg bg-card/50 border border-white/10 hover:border-primary/30 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="text-sm font-semibold truncate">{creator.name}</span>
                      <Badge variant="outline" className="text-xs shrink-0">
                        {creator.niche}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">{creator.expertise}</p>
                    <div className="flex items-start gap-3 text-xs flex-wrap">
                      <div className="flex items-center gap-1">
                        <TrendingUp size={12} className="text-success shrink-0" />
                        <span className="text-success font-semibold">{creator.keyMetric}</span>
                      </div>
                      <span className="text-muted-foreground">• {creator.pattern}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-3 border-t border-white/10">
          <div className="text-center p-2 rounded bg-primary/5">
            <div className="text-lg font-bold text-primary">{CREATOR_DATABASE.length}</div>
            <div className="text-xs text-muted-foreground">Creators</div>
          </div>
          <div className="text-center p-2 rounded bg-success/5">
            <div className="text-lg font-bold text-success">{niches.length - 1}</div>
            <div className="text-xs text-muted-foreground">Niches</div>
          </div>
          <div className="text-center p-2 rounded bg-warning/5">
            <div className="text-lg font-bold text-warning">34k+</div>
            <div className="text-xs text-muted-foreground">Posts</div>
          </div>
          <div className="text-center p-2 rounded bg-destructive/5">
            <div className="text-lg font-bold text-destructive">89%</div>
            <div className="text-xs text-muted-foreground">Accuracy</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

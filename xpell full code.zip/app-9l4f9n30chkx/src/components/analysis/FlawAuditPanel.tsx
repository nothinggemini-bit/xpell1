import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, CheckCircle2, XCircle, Wrench } from 'lucide-react';
import type { FlawAudit } from '@/lib/flaw-audit';
import { motion } from 'framer-motion';

interface FlawAuditPanelProps {
  audit: FlawAudit;
}

export const FlawAuditPanel: React.FC<FlawAuditPanelProps> = ({ audit }) => {
  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'Critical':
        return <XCircle className="text-destructive" size={18} />;
      case 'High':
        return <AlertTriangle className="text-warning" size={18} />;
      case 'Medium':
        return <CheckCircle2 className="text-primary" size={18} />;
      default:
        return <CheckCircle2 className="text-success" size={18} />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Critical':
        return 'border-destructive/30 bg-destructive/5';
      case 'High':
        return 'border-warning/30 bg-warning/5';
      case 'Medium':
        return 'border-primary/30 bg-primary/5';
      default:
        return 'border-success/30 bg-success/5';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-success';
    if (score >= 60) return 'text-primary';
    if (score >= 40) return 'text-warning';
    return 'text-destructive';
  };

  return (
    <Card className="glass border-warning/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wrench className="text-warning" size={20} />
            <CardTitle className="text-lg">5 Flaw Audit</CardTitle>
          </div>
          <div className="text-right">
            <div className={`text-2xl font-bold text-mono ${getScoreColor(audit.overallScore)}`}>
              {audit.overallScore}/100
            </div>
            <p className="text-xs text-muted-foreground">Quality Score</p>
          </div>
        </div>
        <p className="text-sm text-muted-foreground">
          Brutally honest, actionable feedback from 34k+ viral post analysis
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Overall Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Post Quality</span>
            <span className={`font-semibold ${getScoreColor(audit.overallScore)}`}>
              {audit.overallScore}%
            </span>
          </div>
          <Progress value={audit.overallScore} className="h-2" />
          <p className="text-xs text-muted-foreground italic">
            {audit.summary}
          </p>
        </div>

        {/* Flaws List */}
        <div className="space-y-3">
          {audit.flaws.map((flaw, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className={`p-4 rounded-lg border ${getSeverityColor(flaw.severity)}`}
            >
              {/* Flaw Header */}
              <div className="flex items-start gap-3 mb-2">
                {getSeverityIcon(flaw.severity)}
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="text-sm font-semibold">{flaw.type}</h4>
                    <Badge 
                      variant={flaw.severity === 'Critical' ? 'destructive' : flaw.severity === 'High' ? 'default' : 'secondary'}
                      className="text-xs"
                    >
                      {flaw.severity}
                    </Badge>
                  </div>
                  
                  {/* Description */}
                  <p className="text-sm text-muted-foreground mb-3">
                    {flaw.description}
                  </p>
                  
                  {/* Fix */}
                  <div className="p-2 rounded bg-card/50 border border-white/10 mb-2">
                    <p className="text-xs font-semibold text-success mb-1">✓ How to Fix:</p>
                    <p className="text-xs text-muted-foreground">{flaw.fix}</p>
                  </div>
                  
                  {/* Impact */}
                  <p className="text-xs text-primary font-medium">
                    💡 {flaw.impact}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Action Summary */}
        <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
          <p className="text-xs text-muted-foreground">
            <span className="font-semibold text-primary">Next Steps:</span> Fix critical flaws first (30-point impact each), 
            then high-priority issues (15-point impact). Even fixing 2-3 flaws can 3x your engagement.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

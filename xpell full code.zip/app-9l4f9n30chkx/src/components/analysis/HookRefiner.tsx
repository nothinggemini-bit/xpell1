import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { AlertCircle, CheckCircle, Copy, Lightbulb, TrendingUp, Zap } from 'lucide-react';
import type { HookAnalysis } from '@/lib/hook-analyzer';
import { useToast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';

interface HookRefinerProps {
  analysis: HookAnalysis;
}

export const HookRefiner: React.FC<HookRefinerProps> = ({ analysis }) => {
  const { toast } = useToast();

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: 'Copied!',
      description: `${type} hook copied to clipboard`,
    });
  };

  const getSeeMoreWarning = () => {
    if (analysis.hookEndsBeforeSeeMore) {
      return (
        <div className="flex items-start gap-2 p-3 rounded-lg bg-success/10 border border-success/20">
          <CheckCircle className="text-success shrink-0 mt-0.5" size={18} />
          <div className="text-sm">
            <p className="font-semibold text-success">Hook is visible!</p>
            <p className="text-muted-foreground">
              Your hook ({analysis.hookLength} chars) appears before LinkedIn's "See More" button (~{analysis.seeMorePosition} chars).
            </p>
          </div>
        </div>
      );
    } else {
      return (
        <div className="flex items-start gap-2 p-3 rounded-lg bg-destructive/10 border border-destructive/20">
          <AlertCircle className="text-destructive shrink-0 mt-0.5" size={18} />
          <div className="text-sm">
            <p className="font-semibold text-destructive">Hook is hidden!</p>
            <p className="text-muted-foreground">
              Your hook ({analysis.hookLength} chars) gets cut off by "See More" button at ~{analysis.seeMorePosition} chars. 
              Readers won't see your full hook without clicking.
            </p>
          </div>
        </div>
      );
    }
  };

  return (
    <Card className="glass border-primary/20">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Lightbulb className="text-primary" size={20} />
          <CardTitle className="text-lg">Hook Refiner</CardTitle>
        </div>
        <p className="text-sm text-muted-foreground">
          Your first 2 lines make or break virality. Here are 3 proven alternatives.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Original Hook */}
        <div>
          <h4 className="text-sm font-semibold mb-2 text-muted-foreground">Your Current Hook:</h4>
          <div className="p-3 rounded-lg bg-muted/30 border border-white/10">
            <p className="text-sm whitespace-pre-wrap">{analysis.originalHook}</p>
          </div>
        </div>

        {/* See More Warning */}
        {getSeeMoreWarning()}

        <Separator className="bg-white/10" />

        {/* Alternative Hooks */}
        <div className="space-y-3">
          <h4 className="text-sm font-semibold flex items-center gap-2">
            <Zap className="text-warning" size={16} />
            3 Better Alternatives (Trained on 34k+ Viral Posts):
          </h4>
          
          {analysis.alternatives.map((alt, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-4 rounded-lg bg-card/50 border border-primary/10 hover:border-primary/30 transition-colors"
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <Badge 
                  variant={alt.type === 'Controversial' ? 'destructive' : alt.type === 'Data-driven' ? 'default' : 'secondary'}
                  className="shrink-0"
                >
                  {alt.type}
                </Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(alt.text, alt.type)}
                  className="h-8 gap-2"
                >
                  <Copy size={14} />
                  Copy
                </Button>
              </div>
              
              <p className="text-sm whitespace-pre-wrap mb-3 font-medium">
                {alt.text}
              </p>
              
              <div className="flex items-start gap-2 text-xs text-muted-foreground">
                <TrendingUp size={14} className="shrink-0 mt-0.5" />
                <p>{alt.reasoning}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Pro Tip */}
        <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
          <p className="text-xs text-muted-foreground">
            <span className="font-semibold text-primary">Pro Tip:</span> Test all 3 hooks with your audience. 
            Controversial hooks drive comments, data-driven hooks build authority, story-based hooks create emotional connection.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

import React from 'react';
import { motion } from 'framer-motion';

export const TrainingDataMarquee: React.FC = () => {
  const trainingText = "Trained with 1000+ viral LinkedIn posts • Analyzed: Statistics + Content + Niche + Views + Impressions + Comments + Likes + Shares + Reposts • 34,000+ posts from 100+ top creators • 89% prediction accuracy • Patterns from Neil Patel, Gary Vaynerchuk, Simon Sinek, Lara Acosta, Ann Handley & more";

  return (
    <div className="w-full overflow-hidden bg-primary/10 border-y border-primary/20 py-2">
      <motion.div
        className="flex whitespace-nowrap"
        animate={{
          x: [0, -1000],
        }}
        transition={{
          x: {
            repeat: Infinity,
            repeatType: "loop",
            duration: 30,
            ease: "linear",
          },
        }}
      >
        {[...Array(3)].map((_, i) => (
          <span key={i} className="text-sm text-primary font-medium mx-8">
            {trainingText}
          </span>
        ))}
      </motion.div>
    </div>
  );
};

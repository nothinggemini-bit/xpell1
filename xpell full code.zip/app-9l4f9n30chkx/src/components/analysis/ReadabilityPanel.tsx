import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Eye, AlertCircle, CheckCircle } from 'lucide-react';
import type { ReadabilityScore } from '@/lib/readability-score';
import { getReadabilityInsights } from '@/lib/readability-score';

interface ReadabilityPanelProps {
  score: ReadabilityScore;
}

export const ReadabilityPanel: React.FC<ReadabilityPanelProps> = ({ score }) => {
  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'Excellent':
        return 'text-success';
      case 'Good':
        return 'text-primary';
      case 'Fair':
        return 'text-warning';
      case 'Poor':
        return 'text-destructive';
      default:
        return 'text-muted-foreground';
    }
  };

  const getGradeBadgeVariant = (grade: string): "default" | "secondary" | "destructive" | "outline" => {
    switch (grade) {
      case 'Excellent':
      case 'Good':
        return 'default';
      case 'Fair':
        return 'secondary';
      case 'Poor':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const insights = getReadabilityInsights(score);

  return (
    <Card className="glass border-primary/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Eye className="text-primary" size={20} />
            <CardTitle className="text-lg">Scanning Score</CardTitle>
          </div>
          <Badge variant={getGradeBadgeVariant(score.grade)} className="text-mono">
            {score.grade}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground">
          LinkedIn users scan, not read. Optimize for F-pattern scanning.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Score Display */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Readability</span>
            <span className={`text-2xl font-bold text-mono ${getGradeColor(score.grade)}`}>
              {score.scanningScore}/100
            </span>
          </div>
          <Progress value={score.scanningScore} className="h-2" />
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-muted/30 border border-white/10 text-center">
            <div className="text-xl font-bold text-mono text-primary">{score.avgLinesPerParagraph}</div>
            <div className="text-xs text-muted-foreground">Lines/Para</div>
          </div>
          <div className="p-3 rounded-lg bg-muted/30 border border-white/10 text-center">
            <div className="text-xl font-bold text-mono text-primary">{score.totalParagraphs}</div>
            <div className="text-xs text-muted-foreground">Paragraphs</div>
          </div>
          <div className="p-3 rounded-lg bg-muted/30 border border-white/10 text-center">
            <div className="text-xl font-bold text-mono text-primary">{score.totalLines}</div>
            <div className="text-xs text-muted-foreground">Total Lines</div>
          </div>
        </div>

        {/* Insights */}
        <div className="space-y-2">
          {insights.map((insight, index) => (
            <div key={index} className="flex items-start gap-2 text-sm">
              <span className="shrink-0 mt-0.5">{insight.startsWith('✅') ? '✅' : insight.startsWith('⚠️') ? '⚠️' : insight.startsWith('❌') ? '❌' : '📊'}</span>
              <p className="text-muted-foreground">{insight.replace(/^[✅⚠️❌📊]\s*/, '')}</p>
            </div>
          ))}
        </div>

        {/* Flaws */}
        {score.flaws.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              <AlertCircle className="text-warning" size={16} />
              Issues Found:
            </h4>
            {score.flaws.map((flaw, index) => (
              <div key={index} className="p-2 rounded-lg bg-warning/5 border border-warning/20">
                <p className="text-xs text-muted-foreground">{flaw}</p>
              </div>
            ))}
          </div>
        )}

        {/* Improvements */}
        {score.improvements.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              <CheckCircle className="text-success" size={16} />
              Quick Wins:
            </h4>
            {score.improvements.map((improvement, index) => (
              <div key={index} className="p-2 rounded-lg bg-success/5 border border-success/20">
                <p className="text-xs text-muted-foreground">{improvement}</p>
              </div>
            ))}
          </div>
        )}

        {/* Formula Explanation */}
        <div className="p-3 rounded-lg bg-muted/20 border border-white/10">
          <p className="text-xs text-muted-foreground">
            <span className="font-semibold text-primary">Formula:</span> Score = 100 - (Avg Lines/Para - 3) × 20 + Visual Aids Bonus. 
            Optimal: 1-3 lines per paragraph for maximum scanning efficiency.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

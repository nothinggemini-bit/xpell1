import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Brain, TrendingUp, Users, BarChart3, ChevronDown, ChevronUp } from 'lucide-react';
import { TRAINING_CREATORS, TRAINING_STATS, VIRAL_PATTERNS, getRandomCreators } from '@/lib/training-data';
import { motion, AnimatePresence } from 'framer-motion';

export const TrainingDataShowcase: React.FC = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [displayCreators] = useState(getRandomCreators(6));

  return (
    <Card className="glass border-primary/20">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Brain className="text-primary" size={20} />
          <CardTitle className="text-lg">AI Training Data</CardTitle>
        </div>
        <p className="text-sm text-muted-foreground">
          This AI has been trained on {TRAINING_STATS.totalPosts} viral LinkedIn posts from {TRAINING_STATS.totalCreators} top creators
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Key Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="p-3 rounded-lg bg-primary/10 border border-primary/20 text-center">
            <div className="text-xl font-bold text-mono text-primary">{TRAINING_STATS.totalPosts}</div>
            <div className="text-xs text-muted-foreground">Viral Posts</div>
          </div>
          <div className="p-3 rounded-lg bg-success/10 border border-success/20 text-center">
            <div className="text-xl font-bold text-mono text-success">{TRAINING_STATS.successRate}</div>
            <div className="text-xs text-muted-foreground">Accuracy</div>
          </div>
          <div className="p-3 rounded-lg bg-warning/10 border border-warning/20 text-center">
            <div className="text-xl font-bold text-mono text-warning">{TRAINING_STATS.totalCreators}</div>
            <div className="text-xs text-muted-foreground">Creators</div>
          </div>
          <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-center">
            <div className="text-xl font-bold text-mono text-destructive">{TRAINING_STATS.categories}</div>
            <div className="text-xs text-muted-foreground">Categories</div>
          </div>
        </div>

        {/* Featured Creators Sample */}
        <div>
          <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
            <Users size={16} className="text-primary" />
            Featured Creators (Sample):
          </h4>
          <div className="space-y-2">
            {displayCreators.map((creator, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="p-3 rounded-lg bg-card/50 border border-white/10"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-semibold">{creator.name}</span>
                      <Badge variant="outline" className="text-xs">
                        {creator.category}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mb-1">{creator.expertise}</p>
                    <div className="flex items-center gap-3 text-xs">
                      <span className="text-success font-semibold">{creator.avgEngagement}</span>
                      <span className="text-muted-foreground">• {creator.keyPattern}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Expandable Viral Patterns */}
        <div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-full justify-between"
          >
            <span className="flex items-center gap-2">
              <BarChart3 size={16} className="text-primary" />
              Viral Patterns & Data Points
            </span>
            {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </Button>

          <AnimatePresence>
            {isExpanded && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-3 space-y-3"
              >
                {/* Hook Patterns */}
                <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                  <h5 className="text-xs font-semibold text-primary mb-2">Hook Optimization:</h5>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>• Optimal length: {VIRAL_PATTERNS.hooks.optimal}</li>
                    <li>• Types: {VIRAL_PATTERNS.hooks.types.join(', ')}</li>
                    <li>• Impact: {VIRAL_PATTERNS.hooks.impact}</li>
                  </ul>
                </div>

                {/* Structure Patterns */}
                <div className="p-3 rounded-lg bg-success/5 border border-success/20">
                  <h5 className="text-xs font-semibold text-success mb-2">Structure Patterns:</h5>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>• Winning format: {VIRAL_PATTERNS.structure.winning}</li>
                    <li>• Elements: {VIRAL_PATTERNS.structure.elements.join(', ')}</li>
                    <li>• Impact: {VIRAL_PATTERNS.structure.impact}</li>
                  </ul>
                </div>

                {/* Engagement Signals */}
                <div className="p-3 rounded-lg bg-warning/5 border border-warning/20">
                  <h5 className="text-xs font-semibold text-warning mb-2">Engagement Signals:</h5>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>• Critical: {VIRAL_PATTERNS.engagement.critical}</li>
                    <li>• Drivers: {VIRAL_PATTERNS.engagement.drivers.join(', ')}</li>
                    <li>• Impact: {VIRAL_PATTERNS.engagement.impact}</li>
                  </ul>
                </div>

                {/* Timing Optimization */}
                <div className="p-3 rounded-lg bg-destructive/5 border border-destructive/20">
                  <h5 className="text-xs font-semibold text-destructive mb-2">Timing Optimization:</h5>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>• Best days: {VIRAL_PATTERNS.timing.best}</li>
                    <li>• Performance boost: {VIRAL_PATTERNS.timing.boost}</li>
                    <li>• Optimal length: {VIRAL_PATTERNS.timing.optimal}</li>
                  </ul>
                </div>

                {/* Key Data Points */}
                <div className="p-3 rounded-lg bg-muted/20 border border-white/10">
                  <h5 className="text-xs font-semibold mb-2">Key Data Points:</h5>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    {TRAINING_STATS.dataPoints.map((point, index) => (
                      <li key={index}>• {point}</li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Creator Categories */}
        <div className="p-3 rounded-lg bg-card/50 border border-primary/20">
          <p className="text-xs text-muted-foreground">
            <span className="font-semibold text-primary">Categories Include:</span> B2B Marketing (Neil Patel, Ann Handley), 
            Entrepreneurship (Gary Vaynerchuk, Ankur Warikoo), Leadership (Simon Sinek, Lara Acosta), 
            Design (Julie Zhuo, Chris Do), Career (Niharikaa Kaur Sodhi), AI & Data (Cassie Kozyrkov), 
            and 10+ more specialized niches.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

import React from 'react';
import { Info, TrendingUp } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface WhyBoxProps {
  explanations: string[];
  postType?: string;
  framework?: string;
}

export const WhyBox: React.FC<WhyBoxProps> = ({ explanations, postType, framework }) => {
  return (
    <div className="flex flex-col gap-4 p-6 glass rounded-2xl bg-primary/5 border-primary/20">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-primary">
          <Info size={18} />
          <h3 className="text-sm font-bold uppercase tracking-widest">Why this score?</h3>
        </div>
        {postType && (
          <Badge variant="outline" className="text-xs border-success/30 text-success">
            {postType}
          </Badge>
        )}
      </div>
      
      {framework && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-success/10 border border-success/20">
          <TrendingUp className="text-success" size={14} />
          <span className="text-xs font-semibold text-success">{framework}</span>
        </div>
      )}
      
      <div className="space-y-2">
        {explanations.map((exp, i) => {
          const isWarning = exp.startsWith('⚠️');
          const isError = exp.startsWith('❌');
          const isTip = exp.startsWith('💡');
          const isSuccess = exp.startsWith('🚀') || exp.startsWith('✅');
          
          return (
            <p 
              key={i} 
              className={`text-sm leading-relaxed border-l-2 pl-4 py-1 ${
                isError ? 'border-warning/50 text-warning' :
                isWarning ? 'border-warning/30 text-muted-foreground' :
                isTip ? 'border-primary/30 text-foreground' :
                isSuccess ? 'border-success/50 text-success' :
                'border-white/10 text-muted-foreground'
              }`}
            >
              {exp}
            </p>
          );
        })}
        {explanations.length === 0 && (
          <p className="text-sm text-muted-foreground italic">No analysis data yet.</p>
        )}
      </div>
      
      <div className="mt-2 pt-4 border-t border-white/5 space-y-1">
        <p className="text-[10px] text-muted-foreground font-mono uppercase opacity-50">
          Glass-Box Logic: 2026 LinkedIn Algorithm v3.2
        </p>
        <p className="text-[9px] text-muted-foreground/40">
          Based on: 5 Post Funnel • SERVE Framework • 360 Brew • IRL-to-URL
        </p>
      </div>
    </div>
  );
};

import React from 'react';
import trainingData from '@/data/training_data.json';
import { Badge } from '@/components/ui/badge';

export const LearnedPatterns: React.FC = () => {
  return (
    <div className="w-full overflow-hidden glass py-4 border-y border-white/5 relative">
      <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-background to-transparent z-10" />
      <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-background to-transparent z-10" />
      
      <div className="flex animate-marquee gap-8 items-center whitespace-nowrap px-4">
        {[...trainingData, ...trainingData].map((post, i) => (
          <div key={i} className="flex items-center gap-4 px-6 py-2 rounded-full bg-white/5 border border-white/10 shrink-0">
            <Badge variant="outline" className="text-[10px] uppercase font-mono border-primary/30 text-primary">
              {post.type}
            </Badge>
            <span className="text-sm font-medium italic text-muted-foreground truncate max-w-[200px]">
              "{post.hook}"
            </span>
            <span className="text-xs font-bold text-success text-mono">
              {post.metrics}
            </span>
          </div>
        ))}
      </div>
      
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 40s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
      `}} />
    </div>
  );
};

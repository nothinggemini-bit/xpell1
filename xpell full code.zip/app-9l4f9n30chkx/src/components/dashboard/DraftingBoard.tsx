import React, { useState, useRef, useEffect } from 'react';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Sparkles, Scan } from 'lucide-react';
import { analyzeSentences, getHighlightColor } from '@/lib/text-analyzer';
import { motion, AnimatePresence } from 'framer-motion';

interface DraftingBoardProps {
  value: string;
  onChange: (val: string) => void;
  onAnalyze: () => void;
  isAnalyzing: boolean;
}

export const DraftingBoard: React.FC<DraftingBoardProps> = ({ value, onChange, onAnalyze, isAnalyzing }) => {
  const [xrayMode, setXrayMode] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [showSeeMore, setShowSeeMore] = useState(false);
  const [isAtTop, setIsAtTop] = useState(true);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onChange(e.target.value);
    setIsTyping(true);
    setTimeout(() => setIsTyping(false), 500);
  };

  // Check if content exceeds LinkedIn's truncation point (~210 chars)
  useEffect(() => {
    setShowSeeMore(value.length > 210);
  }, [value]);

  // Handle scroll to show/hide truncation line
  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    const target = e.target as HTMLTextAreaElement;
    setIsAtTop(target.scrollTop < 10);
  };

  const sentences = xrayMode ? analyzeSentences(value) : [];

  // Calculate position for truncation line (approximate)
  const truncationPosition = 210;
  const showTruncationLine = value.length > truncationPosition;

  return (
    <div className="flex flex-col gap-4 h-full">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Sparkles className="text-primary" size={18} />
          Drafting Board
        </h2>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Switch 
              id="xray-mode" 
              checked={xrayMode} 
              onCheckedChange={setXrayMode}
              className="data-[state=checked]:bg-primary"
            />
            <Label htmlFor="xray-mode" className="text-sm font-medium cursor-pointer flex items-center gap-1">
              <Scan size={14} />
              X-Ray
            </Label>
          </div>
          <span className="text-xs text-muted-foreground font-mono">
            {value.length} chars
          </span>
        </div>
      </div>
      
      <div className="flex-1 relative group">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/20 to-emerald-500/20 rounded-xl blur opacity-30 group-focus-within:opacity-100 transition duration-500"></div>
        
        {xrayMode && value ? (
          <div className="relative h-full min-h-[400px] glass bg-black/40 border-white/10 rounded-xl p-4 overflow-y-auto">
            <div className="space-y-3">
              {sentences.map((sentence, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  className={`p-3 rounded-lg border ${getHighlightColor(sentence.type)}`}
                >
                  <p className="text-base leading-relaxed mb-2">{sentence.text}</p>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="font-mono text-muted-foreground">
                      {sentence.wordCount} words
                    </span>
                    {sentence.issues.map((issue, i) => (
                      <span key={i} className="text-muted-foreground">• {issue}</span>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        ) : (
          <div className="relative h-full">
            <Textarea
              ref={textareaRef}
              placeholder="Type your LinkedIn post hook and body here..."
              className="relative h-full min-h-[400px] glass bg-black/40 border-white/10 focus:border-primary/50 text-base leading-relaxed resize-none rounded-xl placeholder:text-muted-foreground/50"
              value={value}
              onChange={handleChange}
              onScroll={handleScroll}
            />
            
            {/* LinkedIn Truncation Line */}
            <AnimatePresence>
              {showTruncationLine && isAtTop && !xrayMode && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute left-0 right-0 pointer-events-none"
                  style={{ 
                    top: 'calc(3.5em + 1rem)', // Approximate position for ~210 chars (3-4 lines)
                  }}
                >
                  <div className="relative px-4">
                    <div className="border-t-2 border-dashed border-destructive/60"></div>
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2 bg-background px-2">
                      <span className="text-[10px] font-mono text-destructive/80 whitespace-nowrap">
                        LinkedIn "See More" (~210 chars)
                      </span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>
      
      <motion.div
        animate={{
          boxShadow: isTyping 
            ? '0 0 30px rgba(37, 99, 235, 0.5)' 
            : '0 0 20px rgba(37, 99, 235, 0.3)'
        }}
      >
        <Button 
          onClick={onAnalyze} 
          disabled={isAnalyzing || !value.trim()}
          className="w-full h-12 text-base font-semibold transition-all"
        >
          {isAnalyzing ? "Analyzing Reach Patterns..." : "Analyze Reach"}
        </Button>
      </motion.div>

      {xrayMode && (
        <div className="glass p-3 rounded-lg">
          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-success/20 border border-success/30"></div>
              <span>Punchy (&lt;8 words)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-destructive/20 border border-destructive/30"></div>
              <span>Too Long (&gt;20 words)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded bg-warning/20 border border-warning/30"></div>
              <span>Weak Words</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

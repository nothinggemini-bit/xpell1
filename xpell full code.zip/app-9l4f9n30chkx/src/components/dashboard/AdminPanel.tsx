import React from 'react';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Settings2 } from 'lucide-react';
import { ScoringWeights } from '@/lib/scorer';
import { motion } from 'framer-motion';

interface AdminPanelProps {
  weights: ScoringWeights;
  onChange: (weights: ScoringWeights) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ weights, onChange }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-8 glass rounded-2xl border-primary/30 bg-primary/5 shadow-[0_0_40px_rgba(37,99,235,0.1)]"
    >
      <div className="flex items-center gap-2 mb-8 border-b border-white/10 pb-4">
        <Settings2 className="text-primary" size={24} />
        <h2 className="text-xl font-bold tracking-tight">Algorithm Tuner</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <Label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Hook Weight</Label>
            <span className="text-mono text-primary font-bold">{weights.hookWeight}x</span>
          </div>
          <Slider
            value={[weights.hookWeight]}
            min={0.5}
            max={2.0}
            step={0.1}
            onValueChange={([val]) => onChange({ ...weights, hookWeight: val })}
          />
          <p className="text-xs text-muted-foreground">Adjusts importance of the first sentence structure.</p>
        </div>
        
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <Label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Rhythm Weight</Label>
            <span className="text-mono text-primary font-bold">{weights.rhythmWeight}x</span>
          </div>
          <Slider
            value={[weights.rhythmWeight]}
            min={0.5}
            max={2.0}
            step={0.1}
            onValueChange={([val]) => onChange({ ...weights, rhythmWeight: val })}
          />
          <p className="text-xs text-muted-foreground">Controls impact of sentence alternation and length.</p>
        </div>
        
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <Label className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Base Bias</Label>
            <span className="text-mono text-primary font-bold">{weights.bias}</span>
          </div>
          <Slider
            value={[weights.bias]}
            min={0}
            max={20}
            step={1}
            onValueChange={([val]) => onChange({ ...weights, bias: val })}
          />
          <p className="text-xs text-muted-foreground">The constant starting point for all calculations.</p>
        </div>
      </div>
    </motion.div>
  );
};

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { StreakCounter } from './StreakCounter';
import { Zap, LogOut, User, Home, Swords, History, Database } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface HeaderProps {
  isAdminMode?: boolean;
  onAdminToggle?: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({ isAdminMode = false, onAdminToggle }) => {
  const { profile, signOut } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <header className="flex items-center justify-between px-6 py-4 border-b border-white/10 glass sticky top-0 z-50">
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('/')}>
          <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center shadow-[0_0_20px_rgba(37,99,235,0.4)]">
            <Zap className="text-white fill-white" size={20} />
          </div>
          <h1 className="text-xl font-bold tracking-tight">
            <span className="gradient-text">Xpell</span>
          </h1>
        </div>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate('/')}
            className="gap-2"
          >
            <Home size={16} />
            Dashboard
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate('/hook-lab')}
            className="gap-2"
          >
            <Swords size={16} />
            Hook Lab
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate('/history')}
            className="gap-2"
          >
            <History size={16} />
            History
          </Button>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate('/creators')}
            className="gap-2"
          >
            <Database size={16} />
            Creators
          </Button>
        </nav>
      </div>
      
      <div className="flex items-center gap-4">
        {/* Streak Counter */}
        {profile && (
          <StreakCounter streak={profile.current_streak || 0} />
        )}

        {/* Admin Mode Toggle */}
        {onAdminToggle && (
          <div className="hidden lg:flex items-center gap-3">
            <Label htmlFor="admin-mode" className="text-sm font-medium text-muted-foreground cursor-pointer">
              Admin Mode
            </Label>
            <Switch 
              id="admin-mode" 
              checked={isAdminMode} 
              onCheckedChange={onAdminToggle}
            className="data-[state=checked]:bg-primary"
          />
          </div>
        )}

        {/* User Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="gap-2">
              <User size={16} />
              {profile?.username || 'User'}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56 glass border-white/10">
            <DropdownMenuLabel>
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium">{profile?.full_name}</p>
                <p className="text-xs text-muted-foreground">@{profile?.username}</p>
                {profile?.role_title && (
                  <p className="text-xs text-muted-foreground">{profile.role_title}</p>
                )}
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleSignOut} className="text-warning cursor-pointer">
              <LogOut className="mr-2 h-4 w-4" />
              Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

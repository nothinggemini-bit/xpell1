import React from 'react';
import { CheckCircle2, XCircle } from 'lucide-react';
import { DiagnosticItem } from '@/lib/scorer';
import { motion, AnimatePresence } from 'framer-motion';

interface ChecklistProps {
  items: DiagnosticItem[];
}

export const Checklist: React.FC<ChecklistProps> = ({ items }) => {
  return (
    <div className="flex flex-col gap-4 p-6 glass rounded-2xl h-full">
      <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">Diagnostics</h3>
      
      <div className="flex flex-col gap-3">
        <AnimatePresence mode="popLayout">
          {items.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center justify-between p-3 rounded-lg bg-white/5 border border-white/5"
            >
              <div className="flex items-center gap-3">
                {item.passed ? (
                  <CheckCircle2 className="text-success shrink-0" size={18} />
                ) : (
                  <XCircle className="text-warning shrink-0" size={18} />
                )}
                <span className={`text-sm ${item.passed ? 'text-foreground' : 'text-muted-foreground'}`}>
                  {item.label}
                </span>
              </div>
              <span className="text-xs font-mono text-primary">
                +{item.points}
              </span>
            </motion.div>
          ))}
          {items.length === 0 && (
            <p className="text-sm text-muted-foreground italic">Enter text to see diagnostics.</p>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

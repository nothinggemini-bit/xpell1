import React from 'react';
import { motion } from 'framer-motion';

interface ScoreGaugeProps {
  score: number;
}

export const ScoreGauge: React.FC<ScoreGaugeProps> = ({ score }) => {
  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  const getScoreColor = (s: number) => {
    if (s >= 80) return 'text-success';
    if (s >= 50) return 'text-primary';
    return 'text-warning';
  };

  const getStrokeColor = (s: number) => {
    if (s >= 80) return 'hsl(var(--success))';
    if (s >= 50) return 'hsl(var(--primary))';
    return 'hsl(var(--warning))';
  };

  return (
    <div className="flex flex-col items-center justify-center p-6 glass rounded-2xl relative overflow-hidden group">
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
        <span className="text-4xl font-bold text-mono">2026</span>
      </div>
      
      <div className="relative w-48 h-48">
        <svg className="w-full h-full transform -rotate-90">
          <circle
            cx="96"
            cy="96"
            r={radius}
            stroke="currentColor"
            strokeWidth="12"
            fill="transparent"
            className="text-white/5"
          />
          <motion.circle
            cx="96"
            cy="96"
            r={radius}
            stroke={getStrokeColor(score)}
            strokeWidth="12"
            fill="transparent"
            strokeDasharray={circumference}
            initial={{ strokeDashoffset: circumference }}
            animate={{ strokeDashoffset: offset }}
            transition={{ duration: 1.5, ease: "easeOut" }}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <motion.span 
            key={score}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`text-5xl font-bold text-mono ${getScoreColor(score)}`}
          >
            {score}%
          </motion.span>
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-widest mt-1">
            Viral Prob.
          </span>
        </div>
      </div>
      
      <div className="mt-6 text-center">
        <p className="text-sm text-muted-foreground">
          {score >= 80 ? "Golden Post detected. High reach potential." : 
           score >= 50 ? "Balanced content. Good engagement expected." : 
           "Low reach. Refine the hook or rhythm."}
        </p>
      </div>
    </div>
  );
};

import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

export function CTASection() {
  const navigate = useNavigate();

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="w-full py-16 px-4"
    >
      <div className="max-w-4xl mx-auto text-center space-y-8">
        {/* Main Heading */}
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground">
          Ready to optimize your LinkedIn strategy?
        </h2>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Button
            size="lg"
            className="text-lg px-8 py-6 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-300"
            onClick={() => navigate('/signup')}
          >
            Get Started Free
          </Button>
          
          <Button
            size="lg"
            variant="outline"
            className="text-lg px-8 py-6 border-2 border-border hover:bg-accent/10 font-semibold rounded-lg transition-all duration-300"
            onClick={() => navigate('/login')}
          >
            Sign In
          </Button>
        </div>

        {/* Subtitle */}
        <p className="text-sm md:text-base text-muted-foreground">
          Join creators using glass-box AI to predict viral posts
        </p>
      </div>
    </motion.section>
  );
}

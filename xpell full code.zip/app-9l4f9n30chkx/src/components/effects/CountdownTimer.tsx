import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface CountdownTimerProps {
  isActive: boolean;
  onComplete?: () => void;
}

export const CountdownTimer: React.FC<CountdownTimerProps> = ({ isActive, onComplete }) => {
  const [count, setCount] = useState(30);
  const [prevCount, setPrevCount] = useState(30);

  useEffect(() => {
    if (!isActive) {
      setCount(30);
      setPrevCount(30);
      return;
    }

    if (count <= 0) {
      onComplete?.();
      return;
    }

    const timer = setInterval(() => {
      setCount((prev) => {
        setPrevCount(prev);
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isActive, count, onComplete]);

  if (!isActive || count < 0) return null;

  return (
    <div className="relative w-32 h-40 mx-auto perspective-1000">
      <AnimatePresence mode="wait">
        <motion.div
          key={count}
          initial={{ rotateX: -90, opacity: 0 }}
          animate={{ rotateX: 0, opacity: 1 }}
          exit={{ rotateX: 90, opacity: 0 }}
          transition={{
            duration: 0.6,
            ease: [0.4, 0.0, 0.2, 1],
          }}
          className="absolute inset-0 flex items-center justify-center"
          style={{
            transformStyle: 'preserve-3d',
            transformOrigin: 'center bottom',
          }}
        >
          <div className="relative w-full h-full rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 border-2 border-primary/30 shadow-[0_0_30px_rgba(37,99,235,0.3)] backdrop-blur-sm">
            {/* Top Half Shadow */}
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-b from-black/20 to-transparent pointer-events-none" />
            
            {/* Number Display */}
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-6xl font-bold text-mono text-primary drop-shadow-[0_0_20px_rgba(37,99,235,0.8)]">
                {count}
              </span>
            </div>

            {/* Bottom Edge Highlight */}
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary to-transparent opacity-50" />
            
            {/* Corner Accents */}
            <div className="absolute top-2 left-2 w-3 h-3 border-t-2 border-l-2 border-primary/50 rounded-tl" />
            <div className="absolute top-2 right-2 w-3 h-3 border-t-2 border-r-2 border-primary/50 rounded-tr" />
            <div className="absolute bottom-2 left-2 w-3 h-3 border-b-2 border-l-2 border-primary/50 rounded-bl" />
            <div className="absolute bottom-2 right-2 w-3 h-3 border-b-2 border-r-2 border-primary/50 rounded-br" />
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Reflection Effect */}
      <div className="absolute -bottom-2 left-0 right-0 h-8 bg-gradient-to-b from-primary/10 to-transparent blur-sm opacity-50 rounded-b-2xl" />
    </div>
  );
};

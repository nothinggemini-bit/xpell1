import Home from './pages/Home';
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';
import HookLab from './pages/hook-lab/HookLab';
import Landing from './pages/Landing';
import History from './pages/history/History';
import CreatorsDatabase from './pages/creators/CreatorsDatabase';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Landing',
    path: '/landing',
    element: <Landing />
  },
  {
    name: 'Home',
    path: '/',
    element: <Home />
  },
  {
    name: 'Hook Lab',
    path: '/hook-lab',
    element: <HookLab />
  },
  {
    name: 'History',
    path: '/history',
    element: <History />
  },
  {
    name: 'Creators',
    path: '/creators',
    element: <CreatorsDatabase />
  },
  {
    name: 'Login',
    path: '/login',
    element: <Login />
  },
  {
    name: 'Signup',
    path: '/signup',
    element: <Signup />
  }
];

export default routes;

import { supabase } from './supabase';
import type { UserProfile, Post } from '@/types/index';

// Auth APIs
export const signUp = async (username: string, password: string, userData: {
  full_name: string;
  email?: string;
  followers_count?: number;
  role_title?: string;
  industry?: string;
}) => {
  const { data, error } = await supabase.auth.signUp({
    email: `${username}@miaoda.com`,
    password,
    options: {
      data: userData
    }
  });
  
  if (error) throw error;
  return data;
};

export const signIn = async (username: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email: `${username}@miaoda.com`,
    password
  });
  
  if (error) throw error;
  return data;
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const getCurrentUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

// Profile APIs
export const getProfile = async (userId: string): Promise<UserProfile | null> => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  
  if (error) throw error;
  return data;
};

export const updateProfile = async (userId: string, updates: Partial<UserProfile>) => {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
};

// Post APIs
export const savePost = async (postData: {
  user_id: string;
  content: string;
  score: number;
  post_type?: string;
  framework?: string;
  diagnostics: any;
  explanation: any;
  images?: string[];
  image_analysis?: any;
}) => {
  const { data, error } = await supabase
    .from('posts')
    .insert(postData)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data;
};

export const getUserPosts = async (userId: string, limit = 50): Promise<Post[]> => {
  const { data, error } = await supabase
    .from('posts')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit);
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getPostById = async (postId: string): Promise<Post | null> => {
  const { data, error } = await supabase
    .from('posts')
    .select('*')
    .eq('id', postId)
    .maybeSingle();
  
  if (error) throw error;
  return data;
};

export const deletePost = async (postId: string) => {
  const { error } = await supabase
    .from('posts')
    .delete()
    .eq('id', postId);
  
  if (error) throw error;
};

// Image Upload API
export const uploadImage = async (file: File, userId: string): Promise<string> => {
  const fileExt = file.name.split('.').pop();
  const fileName = `${userId}/${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
  
  const { data, error } = await supabase.storage
    .from('app-9l4f9n30chkx_post_images')
    .upload(fileName, file, {
      cacheControl: '3600',
      upsert: false
    });
  
  if (error) throw error;
  
  const { data: urlData } = supabase.storage
    .from('app-9l4f9n30chkx_post_images')
    .getPublicUrl(data.path);
  
  return urlData.publicUrl;
};

// Image Analysis API
export const analyzeImages = async (images: Array<{ data: string; mimeType: string }>, postContent: string) => {
  const { data, error } = await supabase.functions.invoke('analyze-post-images', {
    body: { images, postContent }
  });
  
  if (error) throw error;
  return data;
};

// Streak Tracking APIs
export const recordActivity = async (userId: string, activityType: string = 'post_analysis') => {
  const { error } = await supabase
    .from('user_activities')
    .insert({ user_id: userId, activity_type: activityType });
  
  if (error && error.code !== '23505') throw error; // Ignore duplicate key errors
  
  // Update streak
  const { error: streakError } = await supabase.rpc('update_user_streak', { p_user_id: userId });
  if (streakError) throw streakError;
};

export const getUserActivities = async (userId: string, limit = 365) => {
  const { data, error } = await supabase
    .from('user_activities')
    .select('activity_date, activity_type')
    .eq('user_id', userId)
    .order('activity_date', { ascending: false })
    .limit(limit);
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const searchUserPosts = async (userId: string, searchTerm: string, limit = 50): Promise<Post[]> => {
  const { data, error } = await supabase
    .from('posts')
    .select('*')
    .eq('user_id', userId)
    .ilike('content', `%${searchTerm}%`)
    .order('created_at', { ascending: false })
    .limit(limit);
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

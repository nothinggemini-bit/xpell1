export type NicheType = 
  | 'general'
  | 'b2b-marketing'
  | 'entrepreneurship'
  | 'career-branding'
  | 'leadership'
  | 'design-creative'
  | 'ai-data'
  | 'sales-revenue'
  | 'cybersecurity'
  | 'hr-future-work'
  | 'customer-success'
  | 'mental-health'
  | 'fintech-crypto'
  | 'real-estate'
  | 'operations'
  | 'logistics'
  | 'legal-compliance';

export interface NicheKeywords {
  positive: string[];
  negative?: string[];
  bonus: number;
}

export const NICHE_KEYWORDS: Record<NicheType, NicheKeywords> = {
  general: {
    positive: ['growth', 'success', 'strategy', 'tips', 'guide'],
    bonus: 0
  },
  'b2b-marketing': {
    positive: ['marketing', 'b2b', 'strategy', 'content', 'seo', 'brand', 'campaign', 'roi', 'leads', 'conversion'],
    bonus: 15
  },
  entrepreneurship: {
    positive: ['startup', 'founder', 'entrepreneur', 'business', 'growth', 'scale', 'exit', 'funding', 'venture'],
    bonus: 15
  },
  'career-branding': {
    positive: ['career', 'personal brand', 'resume', 'interview', 'job', 'networking', 'linkedin', 'professional'],
    bonus: 15
  },
  leadership: {
    positive: ['leadership', 'management', 'team', 'culture', 'innovation', 'vision', 'strategy', 'executive'],
    bonus: 15
  },
  'design-creative': {
    positive: ['design', 'ui', 'ux', 'figma', 'creative', 'visual', 'aesthetic', 'brand', 'typography', 'layout'],
    bonus: 15
  },
  'ai-data': {
    positive: ['ai', 'machine learning', 'data', 'analytics', 'python', 'algorithm', 'model', 'engineering'],
    bonus: 15
  },
  'sales-revenue': {
    positive: ['sales', 'revenue', 'pipeline', 'deal', 'quota', 'crm', 'closing', 'prospecting', 'outreach'],
    bonus: 15
  },
  cybersecurity: {
    positive: ['security', 'cyber', 'privacy', 'encryption', 'threat', 'vulnerability', 'compliance', 'risk'],
    bonus: 15
  },
  'hr-future-work': {
    positive: ['hr', 'human resources', 'talent', 'recruitment', 'remote work', 'culture', 'employee', 'hiring'],
    bonus: 15
  },
  'customer-success': {
    positive: ['customer success', 'retention', 'churn', 'onboarding', 'support', 'satisfaction', 'engagement'],
    bonus: 15
  },
  'mental-health': {
    positive: ['mental health', 'wellness', 'burnout', 'stress', 'mindfulness', 'work-life balance', 'therapy'],
    bonus: 15
  },
  'fintech-crypto': {
    positive: ['fintech', 'crypto', 'blockchain', 'defi', 'finance', 'payment', 'banking', 'investment'],
    bonus: 15
  },
  'real-estate': {
    positive: ['real estate', 'property', 'housing', 'urban', 'development', 'investment', 'market', 'commercial'],
    bonus: 15
  },
  operations: {
    positive: ['operations', 'efficiency', 'process', 'optimization', 'productivity', 'workflow', 'automation'],
    bonus: 15
  },
  logistics: {
    positive: ['logistics', 'supply chain', 'shipping', 'warehouse', 'inventory', 'distribution', 'freight'],
    bonus: 15
  },
  'legal-compliance': {
    positive: ['legal', 'compliance', 'regulation', 'law', 'ethics', 'policy', 'governance', 'contract'],
    bonus: 15
  }
};

export const getNicheLabel = (niche: NicheType): string => {
  const labels: Record<NicheType, string> = {
    general: 'General',
    'b2b-marketing': 'B2B Marketing & Strategy',
    entrepreneurship: 'Entrepreneurship & Growth',
    'career-branding': 'Career & Personal Branding',
    leadership: 'Leadership & Innovation',
    'design-creative': 'Design & Creative Strategy',
    'ai-data': 'AI & Data Engineering',
    'sales-revenue': 'Sales & Revenue Operations',
    cybersecurity: 'Cybersecurity & Data Privacy',
    'hr-future-work': 'Human Resources & Future of Work',
    'customer-success': 'Customer Success',
    'mental-health': 'Mental Health & Wellness',
    'fintech-crypto': 'Fintech & Crypto',
    'real-estate': 'Real Estate & Urban Planning',
    operations: 'Operations & Efficiency',
    logistics: 'Logistics & Supply Chain',
    'legal-compliance': 'Legal, Compliance & Ethics'
  };
  return labels[niche];
};

export const analyzeNicheAlignment = (text: string, niche: NicheType): {
  score: number;
  matchedKeywords: string[];
  wrongKeywords: string[];
  warning?: string;
} => {
  const lowerText = text.toLowerCase();
  const nicheData = NICHE_KEYWORDS[niche];
  
  const matchedKeywords: string[] = [];
  const wrongKeywords: string[] = [];
  
  // Check positive keywords
  nicheData.positive.forEach(keyword => {
    if (lowerText.includes(keyword.toLowerCase())) {
      matchedKeywords.push(keyword);
    }
  });
  
  // Check negative keywords (wrong lingo)
  if (nicheData.negative) {
    nicheData.negative.forEach(keyword => {
      if (lowerText.includes(keyword.toLowerCase())) {
        wrongKeywords.push(keyword);
      }
    });
  }
  
  const score = matchedKeywords.length * nicheData.bonus;
  
  let warning: string | undefined;
  if (wrongKeywords.length > 0 && niche !== 'general') {
    warning = `Wrong Lingo: You are using ${wrongKeywords.join(', ')} which doesn't match your ${getNicheLabel(niche)} audience.`;
  }
  
  return { score, matchedKeywords, wrongKeywords, warning };
};

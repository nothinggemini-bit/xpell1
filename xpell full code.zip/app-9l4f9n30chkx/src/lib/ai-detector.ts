export interface AIDetectionResult {
  score: number; // 0-100, where 0 is human and 100 is AI
  indicators: string[];
  confidence: 'low' | 'medium' | 'high';
}

const AI_BUZZWORDS = [
  'delve', 'unlock', 'unleash', 'navigate', 'landscape', 'dynamic',
  'multifaceted', 'transformative', 'tapestry', 'robust', 'leverage',
  'synergy', 'paradigm', 'holistic', 'seamless', 'innovative'
];

const AI_PHRASES = [
  'in today\'s fast-paced',
  'it\'s important to note',
  'excited to share',
  'humbled to announce',
  'digital world',
  'at the end of the day'
];

export const detectAIGeneration = (text: string): AIDetectionResult => {
  const indicators: string[] = [];
  let score = 0;

  // 1. Check for em dash overuse (—)
  const emDashCount = (text.match(/—/g) || []).length;
  if (emDashCount > 2) {
    indicators.push(`Excessive em dashes (${emDashCount}) - AI often uses these for "clarity"`);
    score += 15;
  }

  // 2. Check for emoji patterns
  const emojiMatches = text.match(/[\u{1F300}-\u{1F9FF}]/gu) || [];
  if (emojiMatches.length > 0) {
    // Check if emojis are at end of sentences (AI pattern)
    const sentenceEndEmojis = (text.match(/[.!?]\s*[\u{1F300}-\u{1F9FF}]/gu) || []).length;
    if (sentenceEndEmojis > 2) {
      indicators.push('Emojis consistently placed at sentence ends (AI pattern)');
      score += 10;
    }

    // Check for bullet point emojis (✅, ➡️, 🔵)
    if (text.includes('✅') || text.includes('➡️') || text.includes('🔵')) {
      indicators.push('Professional bullet-point emojis (✅, ➡️, 🔵) - common AI formatting');
      score += 10;
    }
  }

  // 3. Check for AI buzzwords
  const lowerText = text.toLowerCase();
  const foundBuzzwords = AI_BUZZWORDS.filter(word => lowerText.includes(word));
  if (foundBuzzwords.length > 2) {
    indicators.push(`Corporate buzzwords detected: ${foundBuzzwords.slice(0, 3).join(', ')}`);
    score += foundBuzzwords.length * 5;
  }

  // 4. Check for AI phrases
  const foundPhrases = AI_PHRASES.filter(phrase => lowerText.includes(phrase));
  if (foundPhrases.length > 0) {
    indicators.push(`AI cliché phrases: "${foundPhrases[0]}"`);
    score += foundPhrases.length * 10;
  }

  // 5. Check for Hook-Body-CTA structure
  const lines = text.split('\n').filter(line => line.trim());
  const hasQuestion = text.includes('?');
  const endsWithQuestion = text.trim().endsWith('?');
  if (lines.length > 3 && hasQuestion && endsWithQuestion) {
    indicators.push('Rigid Hook-Body-CTA structure with question ending');
    score += 10;
  }

  // 6. Check for uniform sentence length (AI tends to be consistent)
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 10);
  if (sentences.length > 3) {
    const lengths = sentences.map(s => s.trim().split(/\s+/).length);
    const avgLength = lengths.reduce((a, b) => a + b, 0) / lengths.length;
    const variance = lengths.reduce((sum, len) => sum + Math.pow(len - avgLength, 2), 0) / lengths.length;
    
    // Low variance = uniform length = AI-like
    if (variance < 20 && sentences.length > 4) {
      indicators.push('Uniform sentence lengths (low burstiness) - AI characteristic');
      score += 15;
    }
  }

  // 7. Check for perfect spacing (double line breaks everywhere)
  const doubleBreaks = (text.match(/\n\n/g) || []).length;
  const singleBreaks = (text.match(/\n/g) || []).length - (doubleBreaks * 2);
  if (doubleBreaks > 3 && singleBreaks === 0) {
    indicators.push('Perfect double-spacing throughout - AI formatting');
    score += 10;
  }

  // 8. Check for lack of personal details
  const personalMarkers = ['i ', 'my ', 'me ', 'i\'m', 'i\'ve', 'last week', 'yesterday', 'today'];
  const hasPersonalDetails = personalMarkers.some(marker => lowerText.includes(marker));
  if (!hasPersonalDetails && text.length > 200) {
    indicators.push('Lacks personal anecdotes or specific details');
    score += 10;
  }

  // 9. Check for self-deprecation or vulnerability
  const vulnerabilityMarkers = ['failed', 'mistake', 'wrong', 'embarrassed', 'struggled', 'difficult'];
  const hasVulnerability = vulnerabilityMarkers.some(marker => lowerText.includes(marker));
  if (!hasVulnerability && text.length > 300) {
    indicators.push('No self-deprecation or vulnerability - AI tends to be overly polished');
    score += 5;
  }

  // 10. Check for sentence fragments (humans use them, AI rarely does)
  const fragments = sentences.filter(s => {
    const words = s.trim().split(/\s+/);
    return words.length <= 3 && !s.includes('?');
  });
  if (fragments.length === 0 && sentences.length > 5) {
    indicators.push('No sentence fragments - humans often use short, punchy phrases');
    score += 10;
  }

  // Cap score at 100
  score = Math.min(100, score);

  // Determine confidence level
  let confidence: 'low' | 'medium' | 'high';
  if (score < 30) {
    confidence = 'low';
  } else if (score < 60) {
    confidence = 'medium';
  } else {
    confidence = 'high';
  }

  return {
    score,
    indicators,
    confidence
  };
};

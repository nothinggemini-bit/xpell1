/**
 * Input Validation Utilities
 * Provides comprehensive validation functions for user inputs
 */

export interface ValidationResult {
  isValid: boolean;
  error?: string;
}

/**
 * Validates LinkedIn post content
 * @param content - The post content to validate
 * @returns ValidationResult with isValid flag and optional error message
 */
export function validatePostContent(content: string): ValidationResult {
  const trimmed = content.trim();
  
  // Validation 1: Check if input is empty or only whitespace
  if (!trimmed) {
    return {
      isValid: false,
      error: 'Post content cannot be empty. Please enter your LinkedIn post text.'
    };
  }
  
  // Validation 2: Check minimum character length
  if (trimmed.length < 10) {
    return {
      isValid: false,
      error: 'Post content is too short. Please enter at least 10 characters for accurate analysis.'
    };
  }
  
  // Validation 3: Check maximum character length (LinkedIn limit)
  if (trimmed.length > 3000) {
    return {
      isValid: false,
      error: 'Post content exceeds LinkedIn\'s 3000 character limit. Please shorten your post.'
    };
  }
  
  // Validation 4: Check if content contains at least minimum words
  const wordCount = trimmed.split(/\s+/).filter(word => /[a-zA-Z0-9]/.test(word)).length;
  if (wordCount < 3) {
    return {
      isValid: false,
      error: 'Post must contain at least 3 words for meaningful analysis.'
    };
  }
  
  return { isValid: true };
}

/**
 * Validates hook content for A/B testing
 * @param hookA - First hook content
 * @param hookB - Second hook content
 * @returns ValidationResult with isValid flag and optional error message
 */
export function validateHooks(hookA: string, hookB: string): ValidationResult {
  const trimmedA = hookA.trim();
  const trimmedB = hookB.trim();
  
  // Validation 1: Check if either hook is empty
  if (!trimmedA || !trimmedB) {
    return {
      isValid: false,
      error: 'Both hooks must be filled. Please enter text for both Option A and Option B.'
    };
  }
  
  // Validation 2: Check minimum length for hooks
  if (trimmedA.length < 5) {
    return {
      isValid: false,
      error: 'Option A is too short. Please enter at least 5 characters.'
    };
  }
  
  if (trimmedB.length < 5) {
    return {
      isValid: false,
      error: 'Option B is too short. Please enter at least 5 characters.'
    };
  }
  
  // Validation 3: Check maximum length for hooks
  if (trimmedA.length > 200) {
    return {
      isValid: false,
      error: 'Option A is too long. Hooks should be concise (max 200 characters).'
    };
  }
  
  if (trimmedB.length > 200) {
    return {
      isValid: false,
      error: 'Option B is too long. Hooks should be concise (max 200 characters).'
    };
  }
  
  // Validation 4: Check if hooks are identical
  if (trimmedA.toLowerCase() === trimmedB.toLowerCase()) {
    return {
      isValid: false,
      error: 'Both hooks are identical. Please enter different hooks for A/B testing.'
    };
  }
  
  // Validation 5: Check if hooks contain minimum words
  const wordsA = trimmedA.split(/\s+/).filter(word => /[a-zA-Z0-9]/.test(word)).length;
  const wordsB = trimmedB.split(/\s+/).filter(word => /[a-zA-Z0-9]/.test(word)).length;
  
  if (wordsA < 2) {
    return {
      isValid: false,
      error: 'Option A must contain at least 2 words.'
    };
  }
  
  if (wordsB < 2) {
    return {
      isValid: false,
      error: 'Option B must contain at least 2 words.'
    };
  }
  
  return { isValid: true };
}

/**
 * Validates single hook content
 * @param hook - Hook content to validate
 * @param label - Label for the hook (e.g., "Option A")
 * @returns ValidationResult with isValid flag and optional error message
 */
export function validateSingleHook(hook: string, label: string = 'Hook'): ValidationResult {
  const trimmed = hook.trim();
  
  // Check if empty
  if (!trimmed) {
    return {
      isValid: false,
      error: `${label} cannot be empty.`
    };
  }
  
  // Check minimum length
  if (trimmed.length < 5) {
    return {
      isValid: false,
      error: `${label} is too short. Please enter at least 5 characters.`
    };
  }
  
  // Check maximum length
  if (trimmed.length > 200) {
    return {
      isValid: false,
      error: `${label} is too long. Hooks should be concise (max 200 characters).`
    };
  }
  
  // Check word count
  const wordCount = trimmed.split(/\s+/).filter(word => /[a-zA-Z0-9]/.test(word)).length;
  if (wordCount < 2) {
    return {
      isValid: false,
      error: `${label} must contain at least 2 words.`
    };
  }
  
  return { isValid: true };
}

/**
 * Validates email format
 * @param email - Email address to validate
 * @returns ValidationResult with isValid flag and optional error message
 */
export function validateEmail(email: string): ValidationResult {
  const trimmed = email.trim();
  
  if (!trimmed) {
    return {
      isValid: false,
      error: 'Email address is required.'
    };
  }
  
  // Basic email regex pattern
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  if (!emailPattern.test(trimmed)) {
    return {
      isValid: false,
      error: 'Please enter a valid email address.'
    };
  }
  
  return { isValid: true };
}

/**
 * Validates password strength
 * @param password - Password to validate
 * @returns ValidationResult with isValid flag and optional error message
 */
export function validatePassword(password: string): ValidationResult {
  if (!password) {
    return {
      isValid: false,
      error: 'Password is required.'
    };
  }
  
  if (password.length < 6) {
    return {
      isValid: false,
      error: 'Password must be at least 6 characters long.'
    };
  }
  
  return { isValid: true };
}

/**
 * Validates username
 * @param username - Username to validate
 * @returns ValidationResult with isValid flag and optional error message
 */
export function validateUsername(username: string): ValidationResult {
  const trimmed = username.trim();
  
  if (!trimmed) {
    return {
      isValid: false,
      error: 'Username is required.'
    };
  }
  
  if (trimmed.length < 3) {
    return {
      isValid: false,
      error: 'Username must be at least 3 characters long.'
    };
  }
  
  if (trimmed.length > 30) {
    return {
      isValid: false,
      error: 'Username must be less than 30 characters.'
    };
  }
  
  // Check for valid characters (alphanumeric, underscore, hyphen)
  const usernamePattern = /^[a-zA-Z0-9_-]+$/;
  if (!usernamePattern.test(trimmed)) {
    return {
      isValid: false,
      error: 'Username can only contain letters, numbers, underscores, and hyphens.'
    };
  }
  
  return { isValid: true };
}

/**
 * Sanitizes user input by removing potentially harmful characters
 * @param input - Input string to sanitize
 * @returns Sanitized string
 */
export function sanitizeInput(input: string): string {
  return input
    .trim()
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
    .replace(/<[^>]*>/g, ''); // Remove HTML tags
}

/**
 * Checks if input contains only whitespace or special characters
 * @param input - Input string to check
 * @returns true if input is meaningful, false otherwise
 */
export function hasMeaningfulContent(input: string): boolean {
  const trimmed = input.trim();
  if (!trimmed) return false;
  
  // Check if there's at least one alphanumeric character
  return /[a-zA-Z0-9]/.test(trimmed);
}

/**
 * Gets word count from text
 * @param text - Text to count words from
 * @returns Number of words
 */
export function getWordCount(text: string): number {
  return text.trim().split(/\s+/).filter(word => /[a-zA-Z0-9]/.test(word)).length;
}

/**
 * Gets character count (excluding leading/trailing whitespace)
 * @param text - Text to count characters from
 * @returns Number of characters
 */
export function getCharacterCount(text: string): number {
  return text.trim().length;
}

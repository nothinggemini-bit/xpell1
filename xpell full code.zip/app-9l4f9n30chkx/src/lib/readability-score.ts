/**
 * Readability & Scanning Score Calculator
 * LinkedIn users scan rather than read - optimize for F-pattern
 */

export interface ReadabilityScore {
  scanningScore: number;
  grade: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  avgLinesPerParagraph: number;
  totalLines: number;
  totalParagraphs: number;
  flaws: string[];
  improvements: string[];
}

/**
 * Calculate scanning score based on paragraph density
 * Formula: Score = 100 - (avgLinesPerParagraph - 3) * 20
 * Optimal: 1-3 lines per paragraph
 */
export const calculateReadabilityScore = (content: string): ReadabilityScore => {
  const lines = content.split('\n').filter(line => line.trim());
  const paragraphs = content.split('\n\n').filter(p => p.trim());
  
  const totalLines = lines.length;
  const totalParagraphs = Math.max(paragraphs.length, 1);
  const avgLinesPerParagraph = totalLines / totalParagraphs;
  
  // Calculate scanning score (0-100)
  let scanningScore = 100;
  
  // Penalty for long paragraphs
  if (avgLinesPerParagraph > 3) {
    scanningScore -= (avgLinesPerParagraph - 3) * 20;
  }
  
  // Bonus for optimal formatting
  if (avgLinesPerParagraph <= 2) {
    scanningScore = Math.min(100, scanningScore + 10);
  }
  
  // Check for visual aids
  const hasBullets = content.includes('•') || content.includes('-');
  const hasNumbers = /^\d+[.)]/m.test(content);
  const hasEmojis = /[\u{1F300}-\u{1F9FF}]/u.test(content);
  
  if (hasBullets) scanningScore += 5;
  if (hasNumbers) scanningScore += 5;
  if (hasEmojis) scanningScore += 3;
  
  scanningScore = Math.max(0, Math.min(100, scanningScore));
  
  // Determine grade
  let grade: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  if (scanningScore >= 85) grade = 'Excellent';
  else if (scanningScore >= 70) grade = 'Good';
  else if (scanningScore >= 50) grade = 'Fair';
  else grade = 'Poor';
  
  // Identify flaws
  const flaws: string[] = [];
  const improvements: string[] = [];
  
  if (avgLinesPerParagraph > 5) {
    flaws.push(`Paragraphs too long (${avgLinesPerParagraph.toFixed(1)} lines avg). Readers will bounce.`);
    improvements.push('Break every paragraph into 1-3 line chunks. Use double line breaks.');
  } else if (avgLinesPerParagraph > 3) {
    flaws.push(`Paragraphs slightly dense (${avgLinesPerParagraph.toFixed(1)} lines avg).`);
    improvements.push('Aim for 2-3 lines per paragraph for optimal scanning.');
  }
  
  if (!hasBullets && totalLines > 8) {
    flaws.push('No bullet points detected. Post lacks visual hierarchy.');
    improvements.push('Add bullets (•) or dashes (-) to create scannable lists.');
  }
  
  if (!hasNumbers && totalLines > 10) {
    flaws.push('No numbered lists. Readers love countable takeaways.');
    improvements.push('Use "5 ways to..." or "3 lessons from..." format.');
  }
  
  if (!hasEmojis) {
    improvements.push('Consider adding 1-2 relevant emojis (⚡🎯💡) for visual breaks.');
  }
  
  // Check for wall of text
  const longestParagraph = Math.max(...paragraphs.map(p => p.split('\n').length));
  if (longestParagraph > 7) {
    flaws.push(`One paragraph has ${longestParagraph} lines. That's a wall of text.`);
    improvements.push('Split long paragraphs at natural thought breaks.');
  }
  
  // Check sentence length
  const sentences = content.split(/[.!?]+/).filter(s => s.trim());
  const avgWordsPerSentence = sentences.reduce((sum, s) => sum + s.split(/\s+/).length, 0) / Math.max(sentences.length, 1);
  
  if (avgWordsPerSentence > 20) {
    flaws.push(`Sentences too long (${avgWordsPerSentence.toFixed(1)} words avg). Hard to scan.`);
    improvements.push('Cut sentences to 8-15 words. One idea per sentence.');
  }
  
  return {
    scanningScore: Math.round(scanningScore),
    grade,
    avgLinesPerParagraph: parseFloat(avgLinesPerParagraph.toFixed(1)),
    totalLines,
    totalParagraphs,
    flaws,
    improvements
  };
};

/**
 * Generate readability insights for display
 */
export const getReadabilityInsights = (score: ReadabilityScore): string[] => {
  const insights: string[] = [];
  
  if (score.grade === 'Excellent') {
    insights.push('✅ Perfect scanning structure! This will perform well on mobile.');
    insights.push(`📊 ${score.avgLinesPerParagraph} lines per paragraph is optimal for F-pattern reading.`);
  } else if (score.grade === 'Good') {
    insights.push('✅ Good readability. Minor tweaks will make it excellent.');
    insights.push(`📊 ${score.avgLinesPerParagraph} lines per paragraph - close to optimal.`);
  } else if (score.grade === 'Fair') {
    insights.push('⚠️ Readability needs improvement. Readers may skim past this.');
    insights.push(`📊 ${score.avgLinesPerParagraph} lines per paragraph - aim for 2-3.`);
  } else {
    insights.push('❌ Poor readability. High risk of scroll-aways.');
    insights.push(`📊 ${score.avgLinesPerParagraph} lines per paragraph - way too dense.`);
  }
  
  insights.push(`📝 ${score.totalParagraphs} paragraphs, ${score.totalLines} lines total.`);
  
  return insights;
};

/**
 * Hashtag Suggestion Engine
 * Based on niche-specific viral patterns and trending topics
 */

export interface HashtagSuggestion {
  tag: string;
  category: 'Trending' | 'Niche-Specific' | 'Engagement-Booster' | 'Reach-Expander';
  reasoning: string;
  estimatedReach: string;
}

/**
 * Niche-specific hashtag databases
 */
const HASHTAG_DATABASE: Record<string, HashtagSuggestion[]> = {
  'general': [
    { tag: '#LinkedInTips', category: 'Engagement-Booster', reasoning: 'High engagement rate in general content', estimatedReach: '500K-1M' },
    { tag: '#CareerAdvice', category: 'Reach-Expander', reasoning: 'Broad appeal, high search volume', estimatedReach: '2M+' },
    { tag: '#ProfessionalDevelopment', category: 'Niche-Specific', reasoning: 'Attracts growth-minded professionals', estimatedReach: '1M-2M' },
    { tag: '#Leadership', category: 'Trending', reasoning: 'Consistently trending topic', estimatedReach: '3M+' },
    { tag: '#Productivity', category: 'Engagement-Booster', reasoning: 'High save rate', estimatedReach: '1.5M+' }
  ],
  'saas': [
    { tag: '#SaaS', category: 'Niche-Specific', reasoning: 'Core industry tag', estimatedReach: '800K-1.5M' },
    { tag: '#B2BMarketing', category: 'Niche-Specific', reasoning: 'Targets decision-makers', estimatedReach: '600K-1M' },
    { tag: '#ProductManagement', category: 'Engagement-Booster', reasoning: 'High engagement from PMs', estimatedReach: '500K-800K' },
    { tag: '#StartupGrowth', category: 'Trending', reasoning: 'Popular among founders', estimatedReach: '1M-2M' },
    { tag: '#TechInnovation', category: 'Reach-Expander', reasoning: 'Broad tech audience', estimatedReach: '2M+' }
  ],
  'student': [
    { tag: '#CareerTips', category: 'Niche-Specific', reasoning: 'High engagement from students', estimatedReach: '1M-2M' },
    { tag: '#JobSearch', category: 'Trending', reasoning: 'Always relevant for students', estimatedReach: '2M+' },
    { tag: '#InternshipAdvice', category: 'Engagement-Booster', reasoning: 'High save rate among students', estimatedReach: '500K-1M' },
    { tag: '#ResumeBuilding', category: 'Niche-Specific', reasoning: 'Specific pain point', estimatedReach: '800K-1.5M' },
    { tag: '#CollegeToCareer', category: 'Reach-Expander', reasoning: 'Broad student appeal', estimatedReach: '1.5M+' }
  ],
  'design': [
    { tag: '#UXDesign', category: 'Niche-Specific', reasoning: 'Core design community', estimatedReach: '1M-2M' },
    { tag: '#DesignThinking', category: 'Trending', reasoning: 'Popular methodology', estimatedReach: '1.5M+' },
    { tag: '#UIInspiration', category: 'Engagement-Booster', reasoning: 'High visual engagement', estimatedReach: '800K-1.5M' },
    { tag: '#CreativeProcess', category: 'Reach-Expander', reasoning: 'Appeals beyond designers', estimatedReach: '1M+' },
    { tag: '#DesignCareers', category: 'Niche-Specific', reasoning: 'Career-focused designers', estimatedReach: '500K-800K' }
  ]
};

/**
 * Universal high-performing hashtags
 */
const UNIVERSAL_HASHTAGS: HashtagSuggestion[] = [
  { tag: '#LinkedIn', category: 'Reach-Expander', reasoning: 'Platform-wide visibility', estimatedReach: '10M+' },
  { tag: '#CareerGrowth', category: 'Trending', reasoning: 'Universal professional interest', estimatedReach: '3M+' },
  { tag: '#BusinessStrategy', category: 'Engagement-Booster', reasoning: 'High engagement from executives', estimatedReach: '2M+' },
  { tag: '#Innovation', category: 'Trending', reasoning: 'Broad appeal across industries', estimatedReach: '5M+' },
  { tag: '#PersonalBranding', category: 'Engagement-Booster', reasoning: 'High save and share rate', estimatedReach: '2M+' }
];

/**
 * Content-based hashtag suggestions
 */
const analyzeContentForHashtags = (content: string): HashtagSuggestion[] => {
  const suggestions: HashtagSuggestion[] = [];
  const lowerContent = content.toLowerCase();
  
  // Detect content themes
  const themes: Record<string, HashtagSuggestion> = {
    'ai|artificial intelligence|machine learning': {
      tag: '#ArtificialIntelligence',
      category: 'Trending',
      reasoning: 'AI content is highly viral right now',
      estimatedReach: '5M+'
    },
    'remote work|work from home|hybrid': {
      tag: '#RemoteWork',
      category: 'Trending',
      reasoning: 'Hot topic in 2026 workplace discussions',
      estimatedReach: '3M+'
    },
    'founder|startup|entrepreneur': {
      tag: '#Entrepreneurship',
      category: 'Engagement-Booster',
      reasoning: 'High engagement from founder community',
      estimatedReach: '2M+'
    },
    'sales|revenue|growth': {
      tag: '#SalesStrategy',
      category: 'Niche-Specific',
      reasoning: 'Attracts sales professionals',
      estimatedReach: '1.5M+'
    },
    'marketing|brand|content': {
      tag: '#MarketingStrategy',
      category: 'Niche-Specific',
      reasoning: 'Core marketing audience',
      estimatedReach: '2M+'
    },
    'data|analytics|metrics': {
      tag: '#DataDriven',
      category: 'Engagement-Booster',
      reasoning: 'Appeals to analytical professionals',
      estimatedReach: '1M+'
    }
  };
  
  for (const [pattern, hashtag] of Object.entries(themes)) {
    const regex = new RegExp(pattern, 'i');
    if (regex.test(lowerContent)) {
      suggestions.push(hashtag);
    }
  }
  
  return suggestions;
};

/**
 * Generate hashtag suggestions based on niche and content
 */
export const generateHashtagSuggestions = (content: string, niche: string): HashtagSuggestion[] => {
  const suggestions: HashtagSuggestion[] = [];
  
  // Get niche-specific hashtags
  const nicheHashtags = HASHTAG_DATABASE[niche] || HASHTAG_DATABASE['general'];
  suggestions.push(...nicheHashtags.slice(0, 3));
  
  // Add content-based hashtags
  const contentHashtags = analyzeContentForHashtags(content);
  suggestions.push(...contentHashtags.slice(0, 2));
  
  // Add universal high-performers
  suggestions.push(...UNIVERSAL_HASHTAGS.slice(0, 2));
  
  // Remove duplicates and limit to 7 hashtags (LinkedIn best practice)
  const uniqueSuggestions = suggestions.filter((tag, index, self) =>
    index === self.findIndex(t => t.tag === tag.tag)
  ).slice(0, 7);
  
  return uniqueSuggestions;
};

/**
 * Format hashtags for copy-paste
 */
export const formatHashtagsForPost = (suggestions: HashtagSuggestion[]): string => {
  return suggestions.map(s => s.tag).join(' ');
};

/**
 * Get hashtag strategy explanation
 */
export const getHashtagStrategy = (suggestions: HashtagSuggestion[]): string => {
  const categories = suggestions.reduce((acc, s) => {
    acc[s.category] = (acc[s.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  let strategy = 'Hashtag Strategy: ';
  
  if (categories['Niche-Specific']) {
    strategy += `${categories['Niche-Specific']} niche tags for targeted reach, `;
  }
  if (categories['Trending']) {
    strategy += `${categories['Trending']} trending tags for visibility, `;
  }
  if (categories['Engagement-Booster']) {
    strategy += `${categories['Engagement-Booster']} engagement boosters, `;
  }
  if (categories['Reach-Expander']) {
    strategy += `${categories['Reach-Expander']} reach expanders`;
  }
  
  return strategy.trim().replace(/,\s*$/, '.');
};

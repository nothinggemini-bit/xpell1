export interface SentenceAnalysis {
  text: string;
  wordCount: number;
  type: 'good' | 'long' | 'weak';
  issues: string[];
}

const WEAK_WORDS = ['think', 'believe', 'hope', 'maybe', 'perhaps', 'possibly', 'probably', 'seems', 'appears', 'might'];

export const analyzeSentences = (text: string): SentenceAnalysis[] => {
  // Split by periods, exclamation marks, question marks
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  
  return sentences.map(sentence => {
    const trimmed = sentence.trim();
    const words = trimmed.split(/\s+/);
    const wordCount = words.length;
    const lowerText = trimmed.toLowerCase();
    
    const issues: string[] = [];
    let type: 'good' | 'long' | 'weak' = 'good';
    
    // Check for weak words
    const foundWeakWords = WEAK_WORDS.filter(weak => 
      lowerText.includes(weak)
    );
    
    if (foundWeakWords.length > 0) {
      type = 'weak';
      issues.push(`Weak words: ${foundWeakWords.join(', ')}`);
    }
    
    // Check length
    if (wordCount > 20) {
      type = 'long';
      issues.push(`Too long (${wordCount} words). Break into shorter sentences.`);
    } else if (wordCount < 8 && type === 'good') {
      issues.push(`Punchy and scannable!`);
    }
    
    return {
      text: trimmed,
      wordCount,
      type,
      issues
    };
  });
};

export const getHighlightColor = (type: 'good' | 'long' | 'weak'): string => {
  switch (type) {
    case 'good':
      return 'bg-success/20 border-success/30';
    case 'long':
      return 'bg-destructive/20 border-destructive/30';
    case 'weak':
      return 'bg-warning/20 border-warning/30';
  }
};

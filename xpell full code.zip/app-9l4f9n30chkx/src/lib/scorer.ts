import type { NicheType } from './niche-keywords';
import { analyzeNicheAlignment } from './niche-keywords';

export interface ScoringWeights {
  hookWeight: number;
  rhythmWeight: number;
  bias: number;
}

export interface DiagnosticItem {
  id: string;
  label: string;
  passed: boolean;
  points: number;
}

export interface ScoreResult {
  score: number;
  diagnostics: DiagnosticItem[];
  explanation: string[];
  postType?: string;
  framework?: string;
  nicheScore?: number;
  nicheWarning?: string;
}

// Enhanced LinkedIn 2026 Algorithm Scoring Model
export const calculateViralScore = (
  text: string, 
  weights: ScoringWeights,
  niche: NicheType = 'general'
): ScoreResult => {
  const lines = text.split('\n').filter(l => l.trim().length > 0);
  if (lines.length === 0) {
    return { score: 0, diagnostics: [], explanation: ["Please enter some text to analyze."] };
  }

  const hook = lines[0].trim();
  const hookWords = hook.split(/\s+/);
  const fullText = text.toLowerCase();
  
  let hookQuality = 0;
  let contentDepth = 0;
  const diagnostics: DiagnosticItem[] = [];
  const explanation: string[] = [];

  // === HOOK ANALYSIS (360 Brew: Frontload Value) ===
  const isHookShort = hookWords.length <= 8;
  if (isHookShort) {
    hookQuality += 30;
    diagnostics.push({ id: 'hook-length', label: 'Hook ≤ 8 words (scroll-stop)', passed: true, points: 30 });
  } else {
    diagnostics.push({ id: 'hook-length', label: 'Hook too long (>8 words)', passed: false, points: 0 });
    explanation.push("⚠️ Hook exceeds 8 words. Shorten for immediate scroll-stop impact.");
  }

  const hasNumbers = /\d+/.test(hook);
  if (hasNumbers) {
    hookQuality += 15;
    diagnostics.push({ id: 'hook-numbers', label: 'Numbers in hook (data-driven)', passed: true, points: 15 });
  }

  const hasPOV = /\b(I|You|We|Me|My|Your|Our)\b/i.test(hook);
  if (hasPOV) {
    hookQuality += 15;
    diagnostics.push({ id: 'hook-pov', label: 'POV/Personal angle', passed: true, points: 15 });
  }

  // Contrarian/Paradox Hook Detection
  const contrarian = /(stop|don't|never|avoid|quit|wrong|myth)/i.test(hook);
  if (contrarian) {
    hookQuality += 10;
    diagnostics.push({ id: 'hook-contrarian', label: 'Contrarian hook (attention)', passed: true, points: 10 });
  }

  // === POST TYPE CLASSIFICATION (5 Post Funnel) ===
  let postType = "Unknown";
  let frameworkBonus = 0;

  // Awareness (Quotable)
  if (lines.length <= 5 && /\b(secret|truth|reality|fact)\b/i.test(fullText)) {
    postType = "Awareness (Quotable)";
    frameworkBonus += 5;
  }
  
  // Personal Story (Origin/Adversity)
  if (/(why i|my story|i started|i failed|burned out|decided to)/i.test(fullText)) {
    postType = "Personal Story";
    frameworkBonus += 10;
    diagnostics.push({ id: 'story-type', label: 'Personal story detected', passed: true, points: 10 });
  }

  // Education (A-to-B Guide)
  if (/(how to|here's what|step|guide|framework|playbook)/i.test(fullText) && /\d+\./m.test(text)) {
    postType = "Education (Guide)";
    frameworkBonus += 8;
    diagnostics.push({ id: 'education-format', label: 'Educational guide format', passed: true, points: 8 });
  }

  // IP Framework
  if (/(framework|method|system|process|formula)/i.test(fullText)) {
    postType = "IP Framework";
    frameworkBonus += 12;
    diagnostics.push({ id: 'ip-framework', label: 'Proprietary framework/IP', passed: true, points: 12 });
  }

  // Conversion (Case Study)
  if (/(case study|client|went from|increased|result|revenue|followers)/i.test(fullText) && hasNumbers) {
    postType = "Conversion (Case Study)";
    frameworkBonus += 15;
    diagnostics.push({ id: 'case-study', label: 'Case study with metrics', passed: true, points: 15 });
  }

  contentDepth += frameworkBonus;

  // === SERVE FRAMEWORK DETECTION ===
  const serveElements: string[] = [];
  if (/(consistent|daily|show up)/i.test(fullText)) serveElements.push("Show up");
  if (/(educate|teach|learn|guide)/i.test(fullText)) serveElements.push("Educate");
  if (/(story|personal|human|relate)/i.test(fullText)) serveElements.push("Relate");
  if (/(value|give|help|solve)/i.test(fullText)) serveElements.push("Value");
  if (/(engage|comment|connect|dm)/i.test(fullText)) serveElements.push("Engage");

  if (serveElements.length >= 3) {
    contentDepth += 10;
    diagnostics.push({ 
      id: 'serve-framework', 
      label: `SERVE elements: ${serveElements.join(', ')}`, 
      passed: true, 
      points: 10 
    });
  }

  // === VISUAL RHYTHM (360 Brew: Clarity) ===
  let rhythmScore = 0;
  const sentenceLengths = lines.map(line => line.split(/\s+/).length);
  
  let alternations = 0;
  for (let i = 0; i < sentenceLengths.length - 1; i++) {
    const diff = Math.abs(sentenceLengths[i] - sentenceLengths[i+1]);
    if (diff > 5) alternations++;
  }

  if (alternations >= 2) {
    rhythmScore += 20;
    diagnostics.push({ id: 'rhythm-visual', label: 'Visual rhythm (short/long)', passed: true, points: 20 });
  } else {
    diagnostics.push({ id: 'rhythm-monotone', label: 'Monotonous structure', passed: false, points: 0 });
    explanation.push("⚠️ Alternate short/long sentences for visual rhythm.");
  }

  // F-Pattern Optimization (3-7 lines ideal)
  if (lines.length >= 3 && lines.length <= 7) {
    rhythmScore += 10;
    diagnostics.push({ id: 'f-pattern', label: 'F-pattern optimized length', passed: true, points: 10 });
  } else if (lines.length > 15) {
    explanation.push("⚠️ Post may be too long. Consider breaking into carousel.");
  }

  // === DEPTH & VALUE (360 Brew) ===
  const wordCount = text.split(/\s+/).length;
  if (wordCount >= 50 && wordCount <= 200) {
    contentDepth += 10;
    diagnostics.push({ id: 'depth-optimal', label: 'Optimal depth (50-200 words)', passed: true, points: 10 });
  }

  // Actionable CTA
  const hasCTA = /(dm me|comment|share|steal this|save this|tag someone|link in|start today)/i.test(fullText);
  if (hasCTA) {
    contentDepth += 8;
    diagnostics.push({ id: 'cta-present', label: 'Clear CTA (engagement)', passed: true, points: 8 });
  } else {
    diagnostics.push({ id: 'cta-missing', label: 'No clear CTA', passed: false, points: 0 });
    explanation.push("💡 Add CTA: 'DM me', 'Comment below', 'Save this'");
  }

  // Media Suggestion (IRL-to-URL)
  const hasMediaHint = /(image|photo|video|carousel|infographic)/i.test(fullText);
  if (hasMediaHint) {
    contentDepth += 5;
    diagnostics.push({ id: 'media-hint', label: 'Media format mentioned', passed: true, points: 5 });
  } else {
    explanation.push("💡 Add media: Images/video increase engagement 2-3x");
  }

  // Avoid Spam Patterns
  const hasSpam = /(click here|buy now|limited time|act fast|guaranteed)/i.test(fullText);
  if (hasSpam) {
    contentDepth -= 20;
    diagnostics.push({ id: 'spam-detected', label: 'Spam language detected', passed: false, points: -20 });
    explanation.push("❌ Remove spam triggers: 'click here', 'buy now', etc.");
  }

  // === NICHE-SPECIFIC KEYWORD ANALYSIS ===
  const nicheAnalysis = analyzeNicheAlignment(fullText, niche);
  if (nicheAnalysis.matchedKeywords.length > 0) {
    contentDepth += nicheAnalysis.score;
    diagnostics.push({
      id: 'niche-keywords',
      label: `${niche.toUpperCase()} keywords: ${nicheAnalysis.matchedKeywords.join(', ')}`,
      passed: true,
      points: nicheAnalysis.score
    });
  }

  // === FINAL SCORE CALCULATION ===
  // Score = (HookWeight * HookQuality) + (RhythmWeight * (RhythmScore + ContentDepth)) + Bias
  // CAP AT 90% to prevent over-hyping
  const rawScore = (weights.hookWeight * hookQuality) + 
                   (weights.rhythmWeight * (rhythmScore + contentDepth)) + 
                   weights.bias;
  const cappedScore = Math.min(90, Math.max(0, Math.round(rawScore)));
  const finalScore = cappedScore;

  // Explanation Summary
  explanation.unshift(`📊 Post Type: ${postType}`);
  explanation.push(`🧮 Formula: (${weights.hookWeight} × ${hookQuality}) + (${weights.rhythmWeight} × ${rhythmScore + contentDepth}) + ${weights.bias} = ${finalScore}%`);

  if (finalScore >= 80) {
    explanation.push("🚀 Excellent Post! Strong viral potential. Consider thought leader ads.");
  } else if (finalScore >= 60) {
    explanation.push("✅ Solid post. Optimize hook or add case study for boost.");
  } else {
    explanation.push("⚠️ Needs work. Focus on: shorter hook, visual rhythm, clear CTA.");
  }
  
  explanation.push("💡 Note: Scores capped at 90% to encourage continuous improvement.");

  return {
    score: finalScore,
    diagnostics,
    explanation,
    postType,
    framework: serveElements.length >= 3 ? "SERVE Aligned" : "Needs Framework",
    nicheScore: nicheAnalysis.score,
    nicheWarning: nicheAnalysis.warning
  };
};

/**
 * Calculate follower-based score adjustment
 * Adjusts viral score based on follower count tiers
 */
export const calculateFollowerAdjustment = (followersCount: number): number => {
  if (followersCount < 500) {
    return -4; // Emerging creators face lower reach
  } else if (followersCount >= 2000 && followersCount < 12000) {
    return 4; // Established creators get boost
  } else if (followersCount >= 12000 && followersCount < 40000) {
    return 7; // Influential creators get significant boost
  } else if (followersCount >= 40000 && followersCount < 100000) {
    return 10; // Top creators get major boost
  } else if (followersCount >= 100000) {
    return 15; // Elite creators get maximum boost
  }
  return 0; // 500-2000 followers: neutral range
};

/**
 * Calculate image quality score
 * Analyzes image count and quality for impression boost
 */
export const calculateImageScore = (imageCount: number): number => {
  if (imageCount === 0) return 0;
  if (imageCount === 1) return 5; // Single image: +5%
  if (imageCount === 2) return 8; // Two images: +8%
  if (imageCount === 3) return 12; // Three images: +12%
  if (imageCount >= 4) return 15; // Four+ images: +15% (max)
  return 0;
};

/**
 * Apply follower and image adjustments to base score
 */
export const applyScoreAdjustments = (
  baseScore: number,
  followersCount: number,
  imageCount: number
): { finalScore: number; followerAdjustment: number; imageBoost: number } => {
  const followerAdjustment = calculateFollowerAdjustment(followersCount);
  const imageBoost = calculateImageScore(imageCount);
  
  // Apply adjustments as percentage modifiers
  let finalScore = baseScore;
  
  // Apply follower adjustment
  finalScore = finalScore + (baseScore * (followerAdjustment / 100));
  
  // Apply image boost
  finalScore = finalScore + (baseScore * (imageBoost / 100));
  
  // Cap at 90%
  finalScore = Math.min(90, Math.max(0, Math.round(finalScore)));
  
  return {
    finalScore,
    followerAdjustment,
    imageBoost
  };
};

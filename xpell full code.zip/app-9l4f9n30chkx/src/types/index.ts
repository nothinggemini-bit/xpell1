export interface Option {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
  withCount?: boolean;
}

export interface UserProfile {
  id: string;
  username: string;
  full_name: string;
  email?: string;
  followers_count: number;
  role_title?: string;
  industry?: string;
  role: 'user' | 'admin';
  current_streak: number;
  longest_streak: number;
  last_activity_date?: string;
  created_at: string;
  updated_at: string;
}

export interface Post {
  id: string;
  user_id: string;
  content: string;
  score: number;
  post_type?: string;
  framework?: string;
  diagnostics: any;
  explanation: any;
  images?: string[];
  image_analysis?: ImageAnalysisResult;
  created_at: string;
}

export interface ImageAnalysisResult {
  overallQuality: number;
  images: Array<{
    index: number;
    quality: number;
    description: string;
    relevance: number;
    strengths: string[];
    improvements: string[];
  }>;
  recommendations: string[];
  suggestedImageTypes: string[];
}

export interface DetailedScoreBreakdown {
  hookScore: number;
  hookAnalysis: string;
  paragraphs: Array<{
    index: number;
    content: string;
    score: number;
    feedback: string;
  }>;
  imageScore?: number;
  imageAnalysis?: ImageAnalysisResult;
  alternativeHooks: string[];
  improvementSuggestions: string[];
}

import React, { useState } from 'react';
import { Header } from '@/components/dashboard/Header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Users, TrendingUp, Search, Filter, Database } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import LiquidEther from '@/components/effects/LiquidEther';
import { TrainingDataMarquee } from '@/components/analysis/TrainingDataMarquee';
import { TRAINING_CREATORS } from '@/lib/training-data';

interface CreatorData {
  name: string;
  niche: string;
  expertise: string;
  keyMetric: string;
  pattern: string;
}

// Convert TRAINING_CREATORS to CreatorData format
const CREATOR_DATABASE: CreatorData[] = TRAINING_CREATORS.map(creator => ({
  name: creator.name,
  niche: creator.category,
  expertise: creator.expertise,
  keyMetric: creator.avgEngagement,
  pattern: creator.keyPattern
}));

const CreatorsDatabase: React.FC = () => {
  const [selectedNiche, setSelectedNiche] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');
  
  const niches = ['All', ...Array.from(new Set(CREATOR_DATABASE.map(c => c.niche)))].sort();
  
  const filteredCreators = CREATOR_DATABASE.filter(creator => {
    const matchesNiche = selectedNiche === 'All' || creator.niche === selectedNiche;
    const matchesSearch = searchTerm === '' || 
      creator.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      creator.expertise.toLowerCase().includes(searchTerm.toLowerCase()) ||
      creator.pattern.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesNiche && matchesSearch;
  });

  const getNicheColor = (niche: string) => {
    const colors: Record<string, string> = {
      'B2B Marketing': 'bg-blue-500/10 text-blue-500 border-blue-500/20',
      'Entrepreneurship': 'bg-green-500/10 text-green-500 border-green-500/20',
      'Career': 'bg-purple-500/10 text-purple-500 border-purple-500/20',
      'Leadership': 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
      'Design': 'bg-pink-500/10 text-pink-500 border-pink-500/20',
      'AI & Data': 'bg-cyan-500/10 text-cyan-500 border-cyan-500/20',
      'HR & Future of Work': 'bg-indigo-500/10 text-indigo-500 border-indigo-500/20',
      'Sales': 'bg-red-500/10 text-red-500 border-red-500/20',
      'Workplace Wellness': 'bg-teal-500/10 text-teal-500 border-teal-500/20',
      'Cybersecurity': 'bg-orange-500/10 text-orange-500 border-orange-500/20',
      'Supply Chain': 'bg-lime-500/10 text-lime-500 border-lime-500/20',
    };
    return colors[niche] || 'bg-muted/10 text-muted-foreground border-muted/20';
  };

  return (
    <div className="min-h-screen flex flex-col cyber-grid relative">
      {/* Advanced Fluid Cursor Effect */}
      <LiquidEther 
        mouseForce={20}
        cursorSize={100}
        resolution={0.5}
        colors={['#2563EB', '#10B981', '#F59E0B']}
        autoDemo={true}
        autoSpeed={0.5}
        autoIntensity={2.0}
        autoResumeDelay={3000}
      />
      
      <Header />
      
      {/* Training Data Marquee */}
      <TrainingDataMarquee />

      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Page Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <Database className="text-primary" size={32} />
            <div>
              <h1 className="text-3xl font-bold">Creator Training Database</h1>
              <p className="text-muted-foreground">
                AI trained on posts from these verified creators across multiple niches
              </p>
            </div>
          </div>
        </motion.div>

        {/* Stats Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          <Card className="glass border-primary/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-primary mb-1">{CREATOR_DATABASE.length}</div>
              <div className="text-sm text-muted-foreground">Creators</div>
            </CardContent>
          </Card>
          <Card className="glass border-success/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-success mb-1">{niches.length - 1}</div>
              <div className="text-sm text-muted-foreground">Niches</div>
            </CardContent>
          </Card>
          <Card className="glass border-warning/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-warning mb-1">34k+</div>
              <div className="text-sm text-muted-foreground">Posts</div>
            </CardContent>
          </Card>
          <Card className="glass border-destructive/20">
            <CardContent className="p-6 text-center">
              <div className="text-3xl font-bold text-destructive mb-1">89%</div>
              <div className="text-sm text-muted-foreground">Accuracy</div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <Card className="glass border-primary/20">
            <CardContent className="p-6">
              {/* Search Bar */}
              <div className="mb-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
                  <Input
                    placeholder="Search creators, expertise, or patterns..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 glass"
                  />
                </div>
              </div>

              {/* Niche Filter Buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <Filter size={16} className="text-muted-foreground" />
                {niches.map((niche) => (
                  <Button
                    key={niche}
                    variant={selectedNiche === niche ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedNiche(niche)}
                    className="text-xs"
                  >
                    {niche}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Results Count */}
        <div className="mb-4 text-sm text-muted-foreground">
          Showing {filteredCreators.length} of {CREATOR_DATABASE.length} creators
        </div>

        {/* Creator Grid */}
        <div className="grid grid-cols-1 gap-4">
          <AnimatePresence mode="popLayout">
            {filteredCreators.map((creator, index) => (
              <motion.div
                key={creator.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ delay: index * 0.02 }}
                layout
              >
                <Card className="glass border-white/10 hover:border-primary/30 transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2 flex-wrap">
                          <h3 className="text-lg font-semibold">{creator.name}</h3>
                          <Badge variant="outline" className={`text-xs ${getNicheColor(creator.niche)}`}>
                            {creator.niche}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">{creator.expertise}</p>
                        <div className="flex items-start gap-4 flex-wrap text-sm">
                          <div className="flex items-center gap-2">
                            <TrendingUp size={16} className="text-success shrink-0" />
                            <span className="text-success font-semibold">{creator.keyMetric}</span>
                          </div>
                          <div className="flex items-start gap-2">
                            <span className="text-muted-foreground">•</span>
                            <span className="text-muted-foreground">{creator.pattern}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* No Results */}
        {filteredCreators.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <Users className="mx-auto text-muted-foreground mb-4" size={48} />
            <p className="text-muted-foreground">No creators found matching your criteria</p>
          </motion.div>
        )}
      </main>

      <footer className="py-6 border-t border-white/5 text-center">
        <p className="text-xs text-muted-foreground opacity-50 font-mono">
          &copy; 2026 Xpell | AI-Powered LinkedIn Viral Score Predictor
        </p>
      </footer>
    </div>
  );
};

export default CreatorsDatabase;

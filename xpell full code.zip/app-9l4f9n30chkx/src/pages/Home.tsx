import React, { useState, useEffect } from 'react';
import { Header } from '@/components/dashboard/Header';
import { DraftingBoard } from '@/components/dashboard/DraftingBoard';
import { ImageUpload } from '@/components/dashboard/ImageUpload';
import { ScoreGauge } from '@/components/dashboard/ScoreGauge';
import { Checklist } from '@/components/dashboard/Checklist';
import { WhyBox } from '@/components/dashboard/WhyBox';
import { AdminPanel } from '@/components/dashboard/AdminPanel';
import { LearnedPatterns } from '@/components/dashboard/LearnedPatterns';
import { TrainingDataMarquee } from '@/components/analysis/TrainingDataMarquee';
import { AIInsightsPanel } from '@/components/analysis/AIInsightsPanel';
import { HookRefiner } from '@/components/analysis/HookRefiner';
import { HashtagPanel } from '@/components/analysis/HashtagPanel';
import { ImageAnalysisResults } from '@/components/analysis/ImageAnalysisResults';
import { FollowerScoreIndicator } from '@/components/analysis/FollowerScoreIndicator';
import { FollowerAdjustmentBox } from '@/components/analysis/FollowerAdjustmentBox';
import { AIDetectionPanel } from '@/components/analysis/AIDetectionPanel';
import { CountdownTimer } from '@/components/effects/CountdownTimer';
import { calculateViralScore, ScoringWeights, ScoreResult, applyScoreAdjustments } from '@/lib/scorer';
import { validatePostContent } from '@/lib/input-validation';
import { analyzeHook } from '@/lib/hook-analyzer';
import { generateHashtagSuggestions } from '@/lib/hashtag-suggestions';
import { detectAIGeneration, AIDetectionResult } from '@/lib/ai-detector';
import { motion, AnimatePresence } from 'framer-motion';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle, Sparkles, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { recordActivity, savePost } from '@/db/api';
import { supabase } from '@/db/supabase';
import LiquidEther from '@/components/effects/LiquidEther';
import type { NicheType } from '@/lib/niche-keywords';
import { getNicheLabel } from '@/lib/niche-keywords';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const Home: React.FC = () => {
  const { user, profile, refreshProfile } = useAuth();
  const { toast } = useToast();
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [draft, setDraft] = useState('');
  const [images, setImages] = useState<File[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [useAIAnalysis, setUseAIAnalysis] = useState(true);
  const [niche, setNiche] = useState<NicheType>('general');
  const [weights, setWeights] = useState<ScoringWeights>({
    hookWeight: 1.2,
    rhythmWeight: 0.8,
    bias: 10
  });
  
  const [analysis, setAnalysis] = useState<ScoreResult | null>(null);
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [aiError, setAiError] = useState<string | null>(null);
  const [imageAnalysisResults, setImageAnalysisResults] = useState<any>(null);
  const [followerAdjustment, setFollowerAdjustment] = useState<number>(0);
  const [imageBoost, setImageBoost] = useState<number>(0);
  const [hookAnalysis, setHookAnalysis] = useState<any>(null);
  const [hashtagSuggestions, setHashtagSuggestions] = useState<any[]>([]);
  const [aiDetection, setAiDetection] = useState<AIDetectionResult | null>(null);
  const [manualFollowerCount, setManualFollowerCount] = useState<number>(0);
  const [hasManuallySetFollowers, setHasManuallySetFollowers] = useState<boolean>(false);

  // Initialize manual follower count from profile only once
  useEffect(() => {
    if (!hasManuallySetFollowers && profile?.followers_count !== undefined) {
      setManualFollowerCount(profile.followers_count);
    }
  }, [profile, hasManuallySetFollowers]);

  // Handler for manual follower count changes
  const handleFollowerCountChange = (count: number) => {
    setManualFollowerCount(count);
    setHasManuallySetFollowers(true);
  };

  const handleAnalyze = async () => {
    // Input Validation using validation utility
    const validation = validatePostContent(draft);
    
    if (!validation.isValid) {
      toast({
        variant: "destructive",
        title: "Validation Error",
        description: validation.error,
      });
      return;
    }
    
    setIsAnalyzing(true);
    
    // Record activity for streak
    if (user) {
      try {
        await recordActivity(user.id, 'post_analysis');
        await refreshProfile(); // Refresh to get updated streak
      } catch (error) {
        console.error('Failed to record activity:', error);
      }
    }

    try {
      // Generate hook alternatives and hashtag suggestions immediately
      const hookResult = analyzeHook(draft, niche);
      setHookAnalysis(hookResult);
      
      const hashtagResult = generateHashtagSuggestions(draft, niche);
      setHashtagSuggestions(hashtagResult);

      // Run AI detection analysis
      const aiDetectionResult = detectAIGeneration(draft);
      setAiDetection(aiDetectionResult);

      // If AI analysis is enabled and user is logged in, call Edge Function
      if (useAIAnalysis && user) {
        try {
          console.log('Calling AI analysis Edge Function...');
          console.log('Supabase URL:', import.meta.env.VITE_SUPABASE_URL);
          console.log('User ID:', user.id);
          console.log('Images:', images.length);
          setAiError(null); // Clear previous errors
          
          const { data, error } = await supabase.functions.invoke('analyze-post', {
            body: {
              content: draft,
              niche: niche,
              userId: user.id,
              imageCount: images.length
            }
          });

          console.log('AI Analysis Response:', { data, error });

          if (error) {
            console.error('AI Analysis Error:', error);
            console.error('Error name:', error.name);
            console.error('Error message:', error.message);
            
            // Try to get more error details
            const errorMessage = error?.message || error?.toString() || 'Unknown error';
            let errorContext = null;
            try {
              if (error?.context && typeof error.context.text === 'function') {
                errorContext = await error.context.text();
              }
            } catch (e) {
              console.error('Failed to read error context:', e);
            }
            console.error('Error details:', { errorMessage, errorContext });
            
            // Store the error for display
            const fullError = `${error.name || 'Error'}: ${errorMessage}${errorContext ? ' - ' + errorContext : ''}`;
            setAiError(fullError);
            
            toast({
              variant: "destructive",
              title: "AI Analysis Failed",
              description: "Falling back to standard analysis",
            });
            // Fall back to standard analysis with adjustments
            const baseResult = calculateViralScore(draft, weights, niche);
            const followersCount = manualFollowerCount;
            const adjustments = applyScoreAdjustments(baseResult.score, followersCount, images.length);
            setAnalysis({ ...baseResult, score: adjustments.finalScore });
            setFollowerAdjustment(adjustments.followerAdjustment);
            setImageBoost(adjustments.imageBoost);
          } else {
            console.log('AI Analysis Success:', data);
            setAiAnalysis(data);
            setAiError(null);
            
            // Set image analysis results if available
            if (data.imageAnalysis) {
              setImageAnalysisResults(data.imageAnalysis);
            }
            
            // Also run standard analysis for comparison with adjustments
            const baseResult = calculateViralScore(draft, weights, niche);
            const followersCount = manualFollowerCount;
            const adjustments = applyScoreAdjustments(baseResult.score, followersCount, images.length);
            setAnalysis({ ...baseResult, score: adjustments.finalScore });
            setFollowerAdjustment(adjustments.followerAdjustment);
            setImageBoost(adjustments.imageBoost);
          }
        } catch (err) {
          console.error('AI Analysis Exception:', err);
          console.error('Exception type:', err?.constructor?.name);
          const errorMsg = err instanceof Error ? `${err.name}: ${err.message}` : String(err);
          setAiError(errorMsg);
          
          toast({
            variant: "destructive",
            title: "AI Analysis Failed",
            description: "Falling back to standard analysis",
          });
          // Fall back to standard analysis with adjustments
          const baseResult = calculateViralScore(draft, weights, niche);
          const followersCount = manualFollowerCount;
          const adjustments = applyScoreAdjustments(baseResult.score, followersCount, images.length);
          setAnalysis({ ...baseResult, score: adjustments.finalScore });
          setFollowerAdjustment(adjustments.followerAdjustment);
          setImageBoost(adjustments.imageBoost);
        }
      } else {
        // Standard analysis only with adjustments
        const baseResult = calculateViralScore(draft, weights, niche);
        const followersCount = manualFollowerCount;
        const adjustments = applyScoreAdjustments(baseResult.score, followersCount, images.length);
        setAnalysis({ ...baseResult, score: adjustments.finalScore });
        setFollowerAdjustment(adjustments.followerAdjustment);
        setImageBoost(adjustments.imageBoost);
      }

      // Save post to history if user is logged in
      if (user && analysis) {
        try {
          await savePost({
            user_id: user.id,
            content: draft,
            score: aiAnalysis?.score || analysis.score,
            post_type: niche,
            diagnostics: analysis.diagnostics,
            explanation: analysis.explanation,
          });
        } catch (error) {
          console.error('Failed to save post to history:', error);
        }
      }
    } catch (error) {
      console.error('Analysis error:', error);
      toast({
        variant: "destructive",
        title: "Analysis Error",
        description: "Failed to analyze post. Please try again.",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Real-time update when weights, niche, or follower count change
  useEffect(() => {
    if (draft.trim() && analysis) {
      const result = calculateViralScore(draft, weights, niche);
      const adjustments = applyScoreAdjustments(result.score, manualFollowerCount, images.length);
      setAnalysis({ ...result, score: adjustments.finalScore });
      setFollowerAdjustment(adjustments.followerAdjustment);
      setImageBoost(adjustments.imageBoost);
    }
  }, [weights, niche, manualFollowerCount]);

  return (
    <div className="min-h-screen flex flex-col cyber-grid relative">
      {/* Advanced Fluid Cursor Effect */}
      <LiquidEther 
        mouseForce={20}
        cursorSize={100}
        resolution={0.5}
        colors={['#2563EB', '#10B981', '#F59E0B']}
        autoDemo={true}
        autoSpeed={0.5}
        autoIntensity={2.0}
        autoResumeDelay={3000}
      />
      
      <Header isAdminMode={isAdminMode} onAdminToggle={setIsAdminMode} />
      
      {/* Training Data Marquee */}
      <TrainingDataMarquee />
      
      <LearnedPatterns />

      <main className="flex-1 container mx-auto px-4 py-8">
        {/* Countdown Timer - Floating at Top Center */}
        <AnimatePresence>
          {isAnalyzing && (
            <motion.div
              initial={{ opacity: 0, y: -50, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -50, scale: 0.8 }}
              transition={{ duration: 0.5, ease: [0.4, 0.0, 0.2, 1] }}
              className="mb-8 flex justify-center"
            >
              <div className="glass p-6 rounded-2xl border-2 border-primary/30 shadow-[0_0_40px_rgba(37,99,235,0.4)]">
                <CountdownTimer isActive={isAnalyzing} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {isAdminMode && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="mb-8 overflow-hidden"
            >
              <AdminPanel weights={weights} onChange={setWeights} />
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Panel: Input */}
          <div className="lg:col-span-7 space-y-6">
            {/* Niche Selector */}
            <div className="glass p-4 rounded-lg space-y-2">
              <Label htmlFor="niche-select" className="text-sm font-semibold uppercase tracking-wider">
                Target Audience
              </Label>
              <Select value={niche} onValueChange={(val) => setNiche(val as NicheType)}>
                <SelectTrigger id="niche-select" className="glass">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="glass border-white/10 max-h-[400px]">
                  <SelectItem value="general">General</SelectItem>
                  <SelectItem value="b2b-marketing">B2B Marketing & Strategy</SelectItem>
                  <SelectItem value="entrepreneurship">Entrepreneurship & Growth</SelectItem>
                  <SelectItem value="career-branding">Career & Personal Branding</SelectItem>
                  <SelectItem value="leadership">Leadership & Innovation</SelectItem>
                  <SelectItem value="design-creative">Design & Creative Strategy</SelectItem>
                  <SelectItem value="ai-data">AI & Data Engineering</SelectItem>
                  <SelectItem value="sales-revenue">Sales & Revenue Operations</SelectItem>
                  <SelectItem value="cybersecurity">Cybersecurity & Data Privacy</SelectItem>
                  <SelectItem value="hr-future-work">Human Resources & Future of Work</SelectItem>
                  <SelectItem value="customer-success">Customer Success</SelectItem>
                  <SelectItem value="mental-health">Mental Health & Wellness</SelectItem>
                  <SelectItem value="fintech-crypto">Fintech & Crypto</SelectItem>
                  <SelectItem value="real-estate">Real Estate & Urban Planning</SelectItem>
                  <SelectItem value="operations">Operations & Efficiency</SelectItem>
                  <SelectItem value="logistics">Logistics & Supply Chain</SelectItem>
                  <SelectItem value="legal-compliance">Legal, Compliance & Ethics</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                AI will optimize scoring for your selected audience
              </p>
            </div>

            {/* AI Analysis Toggle */}
            {user && (
              <div className="glass p-4 rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="text-primary" size={18} />
                  <span className="text-sm font-semibold">AI-Powered Analysis</span>
                </div>
                <Button
                  variant={useAIAnalysis ? "default" : "outline"}
                  size="sm"
                  onClick={() => setUseAIAnalysis(!useAIAnalysis)}
                >
                  {useAIAnalysis ? 'Enabled' : 'Disabled'}
                </Button>
              </div>
            )}

            {/* Niche Warning */}
            {analysis?.nicheWarning && (
              <Alert variant="destructive" className="glass border-warning/30 bg-warning/10">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{analysis.nicheWarning}</AlertDescription>
              </Alert>
            )}

            <DraftingBoard 
              value={draft} 
              onChange={setDraft} 
              onAnalyze={handleAnalyze} 
              isAnalyzing={isAnalyzing} 
            />

            {/* Image Upload Section */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-semibold uppercase tracking-wider">
                  Post Images (Optional)
                </Label>
                <span className="text-xs text-primary">
                  Boost impressions by up to 15%
                </span>
              </div>
              <ImageUpload 
                images={images}
                onImagesChange={setImages}
                maxImages={5}
                maxSizeMB={5}
              />
            </div>

            {/* Follower Score Indicator - Below Image Upload */}
            {user && (analysis || aiAnalysis) && (
              <FollowerScoreIndicator 
                followersCount={manualFollowerCount}
                scoreAdjustment={followerAdjustment}
              />
            )}

            {/* AI Detection Panel - Below Follower Indicator */}
            {aiDetection && (
              <AIDetectionPanel result={aiDetection} />
            )}
          </div>

          {/* Right Panel: Diagnostics */}
          <div className="lg:col-span-5 flex flex-col gap-8">
            {/* Follower Adjustment Box - Always visible */}
            <FollowerAdjustmentBox
              followerCount={manualFollowerCount}
              onFollowerCountChange={handleFollowerCountChange}
              adjustment={followerAdjustment}
            />

            {isAnalyzing ? (
              <div className="glass p-8 rounded-lg flex flex-col items-center justify-center gap-4">
                <Loader2 className="animate-spin text-primary" size={48} />
                <p className="text-sm text-muted-foreground">Analyzing with AI...</p>
              </div>
            ) : (
              <>
                <ScoreGauge score={aiAnalysis?.score || analysis?.score || 0} />
                
                {/* Tabs for different analysis views */}
                {(analysis || aiAnalysis) && (
                  <Tabs defaultValue="standard" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="standard">Standard</TabsTrigger>
                      <TabsTrigger 
                        value="ai" 
                        className="relative overflow-hidden data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/20 data-[state=active]:via-primary/10 data-[state=active]:to-primary/20 data-[state=active]:shadow-[0_0_20px_rgba(37,99,235,0.3)] data-[state=active]:border-primary/30"
                      >
                        <span className="relative z-10 flex items-center">
                          AI Insights {aiAnalysis && <Sparkles className="ml-1" size={14} />}
                        </span>
                        {/* Animated glow effect */}
                        <span className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/20 to-transparent animate-shimmer" />
                      </TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="standard" className="space-y-6 mt-6">
                      <Checklist items={analysis?.diagnostics || []} />
                      <WhyBox 
                        explanations={analysis?.explanation || []} 
                        postType={analysis?.postType}
                        framework={analysis?.framework}
                      />
                    </TabsContent>
                    
                    <TabsContent value="ai" className="space-y-6 mt-6">
                      {aiAnalysis ? (
                        <AIInsightsPanel analysis={aiAnalysis} />
                      ) : (
                        <div className="glass p-8 rounded-lg text-center space-y-4">
                          <Sparkles className="mx-auto text-primary" size={48} />
                          <div>
                            <h3 className="text-lg font-semibold mb-2">AI Insights</h3>
                            <p className="text-muted-foreground text-sm">
                              {user 
                                ? "AI Insights will appear here after analyzing your post with AI-Powered Analysis enabled."
                                : "Sign in to unlock AI-powered insights trained on 34,000+ viral LinkedIn posts."}
                            </p>
                            {aiError && (
                              <div className="mt-4 p-4 bg-destructive/10 border border-destructive/30 rounded-lg text-left">
                                <p className="text-xs font-mono text-destructive break-all">
                                  <strong>Error:</strong> {aiError}
                                </p>
                              </div>
                            )}
                          </div>
                          {!user && (
                            <Button 
                              onClick={() => window.location.href = '/login'}
                              className="mt-4"
                            >
                              Sign In to Enable AI Analysis
                            </Button>
                          )}
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                )}
              </>
            )}
          </div>
        </div>

        {/* Hook Refiner and Hashtag Suggestions (shown after analysis) */}
        {(hookAnalysis || hashtagSuggestions.length > 0) && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8"
          >
            {hookAnalysis && (
              <HookRefiner analysis={hookAnalysis} />
            )}
            {hashtagSuggestions.length > 0 && (
              <HashtagPanel suggestions={hashtagSuggestions} />
            )}
          </motion.div>
        )}

        {/* Image Analysis Results (shown after analysis with images) */}
        {imageAnalysisResults && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-8"
          >
            <ImageAnalysisResults 
              results={imageAnalysisResults.results || []}
              totalImpressionBoost={imageBoost}
            />
          </motion.div>
        )}
      </main>

      <footer className="py-6 border-t border-white/5 text-center">
        <p className="text-xs text-muted-foreground opacity-50 font-mono">
          &copy; 2026 Xpell | AI-Powered LinkedIn Viral Score Predictor
        </p>
      </footer>
    </div>
  );
};

export default Home;

import React, { useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import LiquidEther from '@/components/effects/LiquidEther';
import ScrollFloat from '@/components/effects/ScrollFloat';
import { Button } from '@/components/ui/button';
import { ArrowDown, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

const Landing: React.FC = () => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const scrollToFeatures = () => {
    const featuresSection = document.getElementById('features-section');
    if (featuresSection) {
      featuresSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Advanced Fluid Cursor Effect - Fixed Background */}
      <LiquidEther 
        mouseForce={25}
        cursorSize={120}
        resolution={0.6}
        colors={['#2563EB', '#10B981', '#8B5CF6']}
        autoDemo={true}
        autoSpeed={0.6}
        autoIntensity={2.5}
        autoResumeDelay={2000}
      />

      <div ref={scrollContainerRef} className="relative w-full h-screen overflow-y-scroll snap-y snap-mandatory">
        {/* Hero Section - First Viewport */}
        <section className="relative h-screen w-full flex items-center justify-center snap-start">
          <div className="absolute inset-0 bg-gradient-to-br from-background/80 via-background/60 to-primary/10" />
        
        <div className="relative z-10 text-center space-y-8 px-4">
          {/* 3D Title Effect */}
          <motion.div
            initial={{ opacity: 0, y: -50, rotateX: 45 }}
            animate={{ opacity: 1, y: 0, rotateX: 0 }}
            transition={{ duration: 1.2, ease: 'easeOut' }}
            className="perspective-1000"
          >
            <h1 className="text-8xl md:text-9xl font-black tracking-tighter">
              <span className="block bg-gradient-to-br from-primary via-blue-400 to-emerald-400 bg-clip-text text-transparent drop-shadow-2xl"
                    style={{
                      textShadow: '0 10px 40px rgba(37, 99, 235, 0.3)',
                      transform: 'translateZ(50px)',
                    }}>
                Xpell
              </span>
            </h1>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="text-xl md:text-2xl text-muted-foreground font-semibold mt-8 md:mt-12"
          >
            LinkedIn optimization reimagined
          </motion.p>

          {/* Scroll Indicator */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 1, repeat: Infinity, repeatType: 'reverse' }}
            className="mt-12 md:mt-16 cursor-pointer"
            onClick={scrollToFeatures}
          >
            <div className="flex flex-col items-center gap-2 text-muted-foreground hover:text-primary transition-colors">
              <span className="text-sm font-medium">Scroll to explore</span>
              <ArrowDown size={24} className="animate-bounce" />
            </div>
          </motion.div>
        </div>

        {/* Floating Particles */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-primary/30 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -30, 0],
                opacity: [0.3, 0.8, 0.3],
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </div>
      </section>

      {/* Features Section - Second Viewport with ScrollFloat */}
      <section id="features-section" className="relative min-h-screen w-full flex items-center justify-center snap-start py-20">
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-primary/10 to-background/60" />
        
        <div className="relative z-10 w-full max-w-6xl mx-auto px-4 space-y-16">
          {/* Main Heading */}
          <div className="text-center space-y-6">
            <ScrollFloat
              scrollContainerRef={scrollContainerRef}
              containerClassName="mb-4"
              textClassName="text-5xl md:text-7xl font-bold"
              animationDuration={1.2}
              stagger={0.05}
            >
              Predict Your LinkedIn Success
            </ScrollFloat>

            <ScrollFloat
              scrollContainerRef={scrollContainerRef}
              containerClassName=""
              textClassName="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto"
              animationDuration={1}
              stagger={0.02}
              scrollStart="top bottom-=20%"
            >
              Glass-box AI that shows you exactly why your posts will go viral—before you hit publish
            </ScrollFloat>
          </div>

          {/* Feature Grid */}
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: '⚔️',
                title: 'Hook Lab',
                description: 'A/B test your hooks with real-time scoring. See which opening line stops the scroll.',
                color: 'from-red-500 to-orange-500'
              },
              {
                icon: '🔍',
                title: 'X-Ray Mode',
                description: 'Visual heatmap reveals sentence length issues, weak words, and retention killers instantly.',
                color: 'from-blue-500 to-cyan-500'
              },
              {
                icon: '🎯',
                title: 'Niche Optimizer',
                description: 'Target SaaS, Design, or Career audiences with keyword weighting that matches your ICP.',
                color: 'from-purple-500 to-pink-500'
              },
              {
                icon: '📊',
                title: 'Viral Score',
                description: 'Single-layer math model predicts reach probability (0-90%) using 2026 algorithm patterns.',
                color: 'from-green-500 to-emerald-500'
              },
              {
                icon: '🔥',
                title: 'Streak System',
                description: 'GitHub-style contribution graph tracks daily analysis. Build consistency, see your growth.',
                color: 'from-orange-500 to-yellow-500'
              },
              {
                icon: '💡',
                title: 'Why Box',
                description: 'Transparent explanations show exact math rules triggering your score. No black boxes.',
                color: 'from-indigo-500 to-blue-500'
              }
            ].map((feature, idx) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1, duration: 0.6 }}
                viewport={{ once: true }}
                className="glass rounded-2xl p-6 border-white/10 hover:border-primary/30 transition-all hover:scale-105 group"
              >
                <div className={`text-5xl mb-4 bg-gradient-to-br ${feature.color} bg-clip-text text-transparent`}>
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>

          {/* CTA Section */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center space-y-6"
          >
            <ScrollFloat
              scrollContainerRef={scrollContainerRef}
              containerClassName=""
              textClassName="text-2xl md:text-3xl font-semibold"
              animationDuration={1}
              stagger={0.03}
            >
              Ready to optimize your LinkedIn strategy?
            </ScrollFloat>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button
                onClick={() => navigate('/signup')}
                size="lg"
                className="text-lg px-8 py-6 shadow-[0_0_30px_rgba(37,99,235,0.4)] hover:shadow-[0_0_40px_rgba(37,99,235,0.6)] transition-all"
              >
                Get Started Free
              </Button>
              <Button
                onClick={() => navigate('/login')}
                size="lg"
                variant="outline"
                className="text-lg px-8 py-6 glass border-white/20 hover:bg-white/10"
              >
                Sign In
              </Button>
            </div>

            <p className="text-sm text-muted-foreground">
              Join creators using glass-box AI to predict viral posts
            </p>
          </motion.div>
        </div>
      </section>
      </div>
    </>
  );
};

export default Landing;

import React, { useState } from 'react';
import { Header } from '@/components/dashboard/Header';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { calculateViralScore, ScoringWeights } from '@/lib/scorer';
import { validateHooks } from '@/lib/input-validation';
import { motion, AnimatePresence } from 'framer-motion';
import { Swords, Trophy, TrendingUp, TrendingDown } from 'lucide-react';
import LiquidEther from '@/components/effects/LiquidEther';
import type { NicheType } from '@/lib/niche-keywords';
import { useToast } from '@/hooks/use-toast';

const HookLab: React.FC = () => {
  const { toast } = useToast();
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [hookA, setHookA] = useState('');
  const [hookB, setHookB] = useState('');
  const [fighting, setFighting] = useState(false);
  const [result, setResult] = useState<{
    scoreA: number;
    scoreB: number;
    winner: 'A' | 'B' | 'tie';
    delta: number;
    reason: string;
  } | null>(null);

  const weights: ScoringWeights = {
    hookWeight: 1.2,
    rhythmWeight: 0.8,
    bias: 10
  };

  const handleFight = () => {
    // Input Validation using validation utility
    const validation = validateHooks(hookA, hookB);
    
    if (!validation.isValid) {
      toast({
        variant: "destructive",
        title: "Validation Error",
        description: validation.error,
      });
      return;
    }

    setFighting(true);
    setResult(null);

    setTimeout(() => {
      const resultA = calculateViralScore(hookA, weights);
      const resultB = calculateViralScore(hookB, weights);
      
      const delta = Math.abs(resultA.score - resultB.score);
      let winner: 'A' | 'B' | 'tie' = 'tie';
      let reason = '';

      if (resultA.score > resultB.score) {
        winner = 'A';
        const hookAWords = hookA.split(/\s+/).length;
        const hookBWords = hookB.split(/\s+/).length;
        
        if (hookAWords < hookBWords) {
          reason = `Option A is ${delta}% better because it's shorter and punchier`;
        } else if (/\d+/.test(hookA) && !/\d+/.test(hookB)) {
          reason = `Option A is ${delta}% better because it uses numbers`;
        } else {
          reason = `Option A is ${delta}% better with stronger hook structure`;
        }
      } else if (resultB.score > resultA.score) {
        winner = 'B';
        const hookAWords = hookA.split(/\s+/).length;
        const hookBWords = hookB.split(/\s+/).length;
        
        if (hookBWords < hookAWords) {
          reason = `Option B is ${delta}% better because it's shorter and punchier`;
        } else if (/\d+/.test(hookB) && !/\d+/.test(hookA)) {
          reason = `Option B is ${delta}% better because it uses numbers`;
        } else {
          reason = `Option B is ${delta}% better with stronger hook structure`;
        }
      } else {
        reason = 'Both hooks score equally. Try adding numbers or POV to break the tie.';
      }

      setResult({
        scoreA: resultA.score,
        scoreB: resultB.score,
        winner,
        delta,
        reason
      });
      setFighting(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col cyber-grid relative">
      {/* Advanced Fluid Cursor Effect */}
      <LiquidEther 
        mouseForce={28}
        cursorSize={110}
        resolution={0.55}
        colors={['#EF4444', '#F59E0B', '#8B5CF6']}
        autoDemo={true}
        autoSpeed={0.7}
        autoIntensity={2.8}
        autoResumeDelay={2500}
      />
      
      <Header isAdminMode={isAdminMode} onAdminToggle={setIsAdminMode} />

      <main className="flex-1 container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-3">
              <Swords className="text-primary" size={32} />
              <h1 className="text-4xl font-bold">
                Hook <span className="gradient-text">A/B Testing Arena</span>
              </h1>
            </div>
            <p className="text-muted-foreground text-lg">
              Compete against yourself. Paste two hooks and let the AI declare the winner.
            </p>
          </div>

          {/* Split Screen Arena */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Option A */}
            <motion.div
              animate={{
                borderColor: result?.winner === 'A' ? 'hsl(var(--success))' : 
                            result?.winner === 'B' ? 'hsl(var(--destructive))' : 
                            'hsl(var(--border))'
              }}
              className="relative"
            >
              <Card className={`glass h-full ${fighting ? 'animate-pulse' : ''}`}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Option A</span>
                    {result && (
                      <Badge variant={result.winner === 'A' ? 'default' : 'outline'} className="text-mono">
                        {result.scoreA}%
                      </Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Textarea
                      placeholder="Paste Hook Option A here..."
                      value={hookA}
                      onChange={(e) => setHookA(e.target.value)}
                      className="min-h-[200px] glass text-base"
                      maxLength={200}
                    />
                    <div className="flex justify-between items-center text-xs text-muted-foreground">
                      <span>{hookA.length} / 200 characters</span>
                      {hookA.length > 180 && hookA.length <= 200 && (
                        <span className="text-warning">⚠️ Approaching limit</span>
                      )}
                      {hookA.length > 200 && (
                        <span className="text-destructive">❌ Too long</span>
                      )}
                    </div>
                  </div>
                  {result?.winner === 'A' && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="flex items-center gap-2 text-success"
                    >
                      <Trophy size={20} />
                      <span className="font-bold">WINNER!</span>
                    </motion.div>
                  )}
                </CardContent>
              </Card>
              {fighting && (
                <div className="absolute inset-0 bg-primary/10 backdrop-blur-sm rounded-lg flex items-center justify-center">
                  <div className="text-primary font-mono text-lg animate-pulse">Analyzing...</div>
                </div>
              )}
            </motion.div>

            {/* Option B */}
            <motion.div
              animate={{
                borderColor: result?.winner === 'B' ? 'hsl(var(--success))' : 
                            result?.winner === 'A' ? 'hsl(var(--destructive))' : 
                            'hsl(var(--border))'
              }}
              className="relative"
            >
              <Card className={`glass h-full ${fighting ? 'animate-pulse' : ''}`}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Option B</span>
                    {result && (
                      <Badge variant={result.winner === 'B' ? 'default' : 'outline'} className="text-mono">
                        {result.scoreB}%
                      </Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Textarea
                      placeholder="Paste Hook Option B here..."
                      value={hookB}
                      onChange={(e) => setHookB(e.target.value)}
                      className="min-h-[200px] glass text-base"
                      maxLength={200}
                    />
                    <div className="flex justify-between items-center text-xs text-muted-foreground">
                      <span>{hookB.length} / 200 characters</span>
                      {hookB.length > 180 && hookB.length <= 200 && (
                        <span className="text-warning">⚠️ Approaching limit</span>
                      )}
                      {hookB.length > 200 && (
                        <span className="text-destructive">❌ Too long</span>
                      )}
                    </div>
                  </div>
                  {result?.winner === 'B' && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      className="flex items-center gap-2 text-success"
                    >
                      <Trophy size={20} />
                      <span className="font-bold">WINNER!</span>
                    </motion.div>
                  )}
                </CardContent>
              </Card>
              {fighting && (
                <div className="absolute inset-0 bg-primary/10 backdrop-blur-sm rounded-lg flex items-center justify-center">
                  <div className="text-primary font-mono text-lg animate-pulse">Analyzing...</div>
                </div>
              )}
            </motion.div>
          </div>

          {/* Fight Button */}
          <div className="flex justify-center">
            <Button
              onClick={handleFight}
              disabled={fighting || !hookA.trim() || !hookB.trim()}
              size="lg"
              className="text-lg px-12 py-6 shadow-[0_0_30px_rgba(37,99,235,0.4)] hover:shadow-[0_0_50px_rgba(37,99,235,0.6)]"
            >
              <Swords className="mr-2" size={24} />
              {fighting ? 'Fighting...' : 'FIGHT!'}
            </Button>
          </div>

          {/* Result Panel */}
          <AnimatePresence>
            {result && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <Card className="glass border-primary/30 bg-primary/5">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="text-primary" />
                      Battle Results
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-4 rounded-lg bg-white/5">
                      <span className="text-lg font-semibold">Score Delta:</span>
                      <span className="text-2xl font-bold text-mono text-primary">
                        {result.delta}%
                      </span>
                    </div>
                    <div className="p-4 rounded-lg bg-white/5 border-l-4 border-success">
                      <p className="text-lg">{result.reason}</p>
                    </div>
                    {result.winner === 'tie' && (
                      <div className="text-center text-muted-foreground">
                        <p>💡 Try adding numbers, POV, or making one hook shorter to create differentiation.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
};

export default HookLab;

import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap, Loader2 } from 'lucide-react';
import LiquidEther from '@/components/effects/LiquidEther';
import { supabase } from '@/db/supabase';
import { getNicheLabel, type NicheType } from '@/lib/niche-keywords';

const Signup: React.FC = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    confirmPassword: '',
    full_name: '',
    email: '',
    followers_count: 0,
    role_title: '',
    industry: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const { signUp } = useAuth();
  const navigate = useNavigate();

  // All niche options
  const nicheOptions: NicheType[] = [
    'general',
    'b2b-marketing',
    'entrepreneurship',
    'career-branding',
    'leadership',
    'design-creative',
    'ai-data',
    'sales-revenue',
    'cybersecurity',
    'hr-future-work',
    'customer-success',
    'mental-health',
    'fintech-crypto',
    'real-estate',
    'operations',
    'logistics',
    'legal-compliance'
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'followers_count' ? parseInt(value) || 0 : value
    }));
  };

  const handleNicheChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      industry: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    if (!/^[a-zA-Z0-9_]+$/.test(formData.username)) {
      setError('Username can only contain letters, numbers, and underscores');
      return;
    }

    setLoading(true);

    try {
      await signUp(formData.username, formData.password, {
        full_name: formData.full_name,
        email: formData.email || undefined,
        followers_count: formData.followers_count,
        role_title: formData.role_title || undefined,
        industry: formData.industry || undefined
      });
      
      // Auto sign in after signup
      navigate('/');
    } catch (err: any) {
      setError(err.message || 'Failed to create account');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignUp = async () => {
    setError('');
    setGoogleLoading(true);
    
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/`,
        },
      });
      
      if (error) {
        // Check if it's a provider not enabled error
        if (error.message.includes('provider is not enabled') || error.message.includes('Unsupported provider')) {
          throw new Error('Google Sign-Up is not enabled yet. Please enable Google OAuth provider in Supabase Dashboard (Authentication → Providers → Google). See FIX_GOOGLE_SIGNIN_ERROR.md for detailed instructions.');
        }
        throw error;
      }
    } catch (err: any) {
      setError(err.message || 'Failed to sign up with Google');
      setGoogleLoading(false);
    }
  };

  return (
    <>
      {/* Advanced Fluid Cursor Effect - Outside main container */}
      <LiquidEther 
        mouseForce={15}
        cursorSize={90}
        resolution={0.45}
        colors={['#2563EB', '#8B5CF6', '#06B6D4']}
        autoDemo={true}
        autoSpeed={0.4}
        autoIntensity={1.8}
        autoResumeDelay={4000}
      />
      
      <div className="fixed inset-0 w-full h-full flex items-center justify-center p-4 cyber-grid overflow-auto">
        <div className="relative z-10 w-full max-w-2xl my-8">
          <Card className="w-full glass border-white/10">
        <CardHeader className="space-y-4">
          <div className="flex items-center justify-center gap-2">
            <div className="w-12 h-12 rounded-lg bg-primary flex items-center justify-center shadow-[0_0_20px_rgba(37,99,235,0.4)]">
              <Zap className="text-white fill-white" size={24} />
            </div>
          </div>
          <CardTitle className="text-2xl text-center">
            Join <span className="gradient-text">Xpell</span>
          </CardTitle>
          <CardDescription className="text-center">
            Create your account to start optimizing LinkedIn posts
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username *</Label>
                <Input
                  id="username"
                  name="username"
                  type="text"
                  placeholder="johndoe"
                  value={formData.username}
                  onChange={handleChange}
                  required
                  className="glass"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="full_name">Full Name *</Label>
                <Input
                  id="full_name"
                  name="full_name"
                  type="text"
                  placeholder="John Doe"
                  value={formData.full_name}
                  onChange={handleChange}
                  required
                  className="glass"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  minLength={6}
                  className="glass"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password *</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                  minLength={6}
                  className="glass"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email">Email (Optional)</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="john@example.com"
                value={formData.email}
                onChange={handleChange}
                className="glass"
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="role_title">Role/Title</Label>
                <Input
                  id="role_title"
                  name="role_title"
                  type="text"
                  placeholder="Content Creator"
                  value={formData.role_title}
                  onChange={handleChange}
                  className="glass"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="industry">Industry / Niche *</Label>
                <Select value={formData.industry} onValueChange={handleNicheChange}>
                  <SelectTrigger className="glass">
                    <SelectValue placeholder="Select Industry / Niche" />
                  </SelectTrigger>
                  <SelectContent className="glass max-h-[300px]">
                    {nicheOptions.map((niche) => (
                      <SelectItem key={niche} value={niche}>
                        {getNicheLabel(niche)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="followers_count">Current LinkedIn Followers</Label>
              <Input
                id="followers_count"
                name="followers_count"
                type="number"
                placeholder="0"
                value={formData.followers_count}
                onChange={handleChange}
                min={0}
                className="glass"
              />
            </div>
            
            <Button type="submit" className="w-full" disabled={loading || googleLoading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating account...
                </>
              ) : (
                'Create Account'
              )}
            </Button>

            {/* Divider */}
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t border-white/10" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-background px-2 text-muted-foreground">Or continue with</span>
              </div>
            </div>

            {/* Google Sign-Up Button */}
            <Button
              type="button"
              variant="outline"
              className="w-full glass border-white/20 hover:bg-white/10"
              onClick={handleGoogleSignUp}
              disabled={loading || googleLoading}
            >
              {googleLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
                    <path
                      fill="currentColor"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="currentColor"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="currentColor"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                    />
                    <path
                      fill="currentColor"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                    />
                  </svg>
                  Continue with Google
                </>
              )}
            </Button>
            
            <p className="text-center text-sm text-muted-foreground">
              Already have an account?{' '}
              <Link to="/login" className="text-primary hover:underline">
                Sign in
              </Link>
            </p>
          </form>
        </CardContent>
      </Card>
        </div>
      </div>
    </>
  );
};

export default Signup;

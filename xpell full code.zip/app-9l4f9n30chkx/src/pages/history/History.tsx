import React, { useState, useEffect } from 'react';
import { Header } from '@/components/dashboard/Header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/contexts/AuthContext';
import { getUserPosts, deletePost, searchUserPosts } from '@/db/api';
import { useToast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Trash2, Calendar, TrendingUp, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import type { Post } from '@/types/index';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import LiquidEther from '@/components/effects/LiquidEther';

const History: React.FC = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [postToDelete, setPostToDelete] = useState<string | null>(null);
  const [expandedPost, setExpandedPost] = useState<string | null>(null);

  useEffect(() => {
    loadPosts();
  }, [user]);

  const loadPosts = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const data = await getUserPosts(user.id);
      setPosts(data);
    } catch (error) {
      console.error('Failed to load posts:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to load your post history.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!user) return;

    try {
      setLoading(true);
      if (searchTerm.trim()) {
        const data = await searchUserPosts(user.id, searchTerm);
        setPosts(data);
      } else {
        await loadPosts();
      }
    } catch (error) {
      console.error('Failed to search posts:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to search posts.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!postToDelete) return;

    try {
      await deletePost(postToDelete);
      setPosts(posts.filter(p => p.id !== postToDelete));
      toast({
        title: 'Success',
        description: 'Post deleted successfully.',
      });
    } catch (error) {
      console.error('Failed to delete post:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to delete post.',
      });
    } finally {
      setDeleteDialogOpen(false);
      setPostToDelete(null);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-success';
    if (score >= 40) return 'text-warning';
    return 'text-destructive';
  };

  const getScoreBadgeVariant = (score: number): "default" | "secondary" | "destructive" | "outline" => {
    if (score >= 70) return 'default';
    if (score >= 40) return 'secondary';
    return 'destructive';
  };

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col cyber-grid relative">
        <LiquidEther 
          mouseForce={15}
          cursorSize={90}
          resolution={0.45}
          colors={['#2563EB', '#8B5CF6', '#06B6D4']}
          autoDemo={true}
          autoSpeed={0.4}
          autoIntensity={1.8}
          autoResumeDelay={4000}
        />
        <Header />
        <main className="flex-grow container mx-auto px-4 py-8 relative z-10">
          <Card className="glass max-w-2xl mx-auto">
            <CardContent className="p-8 text-center">
              <AlertCircle className="mx-auto mb-4 text-warning" size={48} />
              <h2 className="text-2xl font-bold mb-2">Sign In Required</h2>
              <p className="text-muted-foreground mb-4">
                Please sign in to view your post history.
              </p>
              <Button onClick={() => window.location.href = '/login'}>
                Sign In
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col cyber-grid relative">
      <LiquidEther 
        mouseForce={15}
        cursorSize={90}
        resolution={0.45}
        colors={['#2563EB', '#8B5CF6', '#06B6D4']}
        autoDemo={true}
        autoSpeed={0.4}
        autoIntensity={1.8}
        autoResumeDelay={4000}
      />
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Header Section */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold gradient-text mb-2">Post History</h1>
              <p className="text-muted-foreground">
                View and manage your analyzed LinkedIn posts
              </p>
            </div>
            <Badge variant="outline" className="text-mono w-fit">
              {posts.length} {posts.length === 1 ? 'Post' : 'Posts'}
            </Badge>
          </div>

          {/* Search Bar */}
          <Card className="glass">
            <CardContent className="p-4">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={18} />
                  <Input
                    placeholder="Search your posts..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                    className="pl-10 glass"
                  />
                </div>
                <Button onClick={handleSearch} disabled={loading}>
                  Search
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Posts List */}
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="glass">
                  <CardContent className="p-6">
                    <Skeleton className="h-4 w-1/4 mb-4 bg-muted" />
                    <Skeleton className="h-20 w-full mb-4 bg-muted" />
                    <Skeleton className="h-4 w-1/3 bg-muted" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : posts.length === 0 ? (
            <Card className="glass">
              <CardContent className="p-12 text-center">
                <TrendingUp className="mx-auto mb-4 text-muted-foreground" size={48} />
                <h3 className="text-xl font-bold mb-2">No Posts Yet</h3>
                <p className="text-muted-foreground mb-4">
                  {searchTerm ? 'No posts found matching your search.' : 'Start analyzing posts to build your history!'}
                </p>
                {searchTerm && (
                  <Button variant="outline" onClick={() => { setSearchTerm(''); loadPosts(); }}>
                    Clear Search
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <AnimatePresence mode="popLayout">
              <div className="space-y-4">
                {posts.map((post, index) => (
                  <motion.div
                    key={post.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Card className="glass hover:border-primary/50 transition-colors">
                      <CardHeader>
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <Badge variant={getScoreBadgeVariant(post.score)} className="text-mono">
                                {post.score}% Viral Score
                              </Badge>
                              {post.post_type && (
                                <Badge variant="outline" className="capitalize">
                                  {post.post_type}
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Calendar size={14} />
                              <span>{format(new Date(post.created_at), 'MMM dd, yyyy • h:mm a')}</span>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              setPostToDelete(post.id);
                              setDeleteDialogOpen(true);
                            }}
                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                          >
                            <Trash2 size={18} />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <p className={`text-sm whitespace-pre-wrap ${expandedPost === post.id ? '' : 'line-clamp-3'}`}>
                              {post.content}
                            </p>
                            {post.content.length > 200 && (
                              <Button
                                variant="link"
                                size="sm"
                                onClick={() => setExpandedPost(expandedPost === post.id ? null : post.id)}
                                className="px-0 h-auto mt-2"
                              >
                                {expandedPost === post.id ? 'Show less' : 'Show more'}
                              </Button>
                            )}
                          </div>

                          {/* Diagnostics Preview */}
                          {post.diagnostics && Array.isArray(post.diagnostics) && post.diagnostics.length > 0 && (
                            <div className="pt-4 border-t border-white/10">
                              <h4 className="text-sm font-semibold mb-2">Key Insights:</h4>
                              <div className="space-y-1">
                                {post.diagnostics.slice(0, 3).map((item: any, idx: number) => (
                                  <div key={idx} className="flex items-start gap-2 text-sm">
                                    <span className={item.passed ? 'text-success' : 'text-warning'}>
                                      {item.passed ? '✓' : '⚠'}
                                    </span>
                                    <span className="text-muted-foreground">{item.message}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </AnimatePresence>
          )}
        </motion.div>
      </main>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="glass">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Post</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this post from your history? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default History;

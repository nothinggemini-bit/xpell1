# 🚀 AI Search Quick Start Guide

## What is AI Search?

AI Search is an intelligent assistant that answers questions about your LinkedIn posts. It appears after you analyze a post and provides AI-powered insights based on your content and web knowledge.

## How to Use

### Step 1: Write and Analyze Your Post
1. Write your LinkedIn post in the Drafting Board
2. Click "Analyze Reach" button
3. Wait for analysis to complete

### Step 2: Find AI Search Panel
- Scroll to the bottom of the page
- Look for the "AI Search Assistant" section with sparkles icon (✨)

### Step 3: Ask Questions
**Option A - Use Suggested Questions**:
- Click any suggested question button
- Example: "How can I improve this post?"

**Option B - Type Your Own**:
- Type your question in the input field
- Press Enter or click Send button

### Step 4: Get Answers
- Wait 30-45 seconds for AI to search and analyze
- Read the answer and check sources
- Ask follow-up questions if needed

## Example Questions

### Post Improvement
- "How can I improve this post?"
- "What's missing from this post?"
- "How can I make this more engaging?"

### Hashtags
- "What hashtags should I use?"
- "Which hashtags are trending in my industry?"
- "How many hashtags should I include?"

### Timing
- "When is the best time to post this?"
- "What day should I publish this?"
- "How often should I post?"

### Engagement
- "How can I increase engagement?"
- "What CTA should I use?"
- "Should I ask a question at the end?"

### Hook Enhancement
- "How can I make the hook more engaging?"
- "Is my opening sentence strong enough?"
- "What's a better way to start this post?"

### Industry Insights
- "What are the latest trends in [your industry]?"
- "What topics are popular on LinkedIn right now?"
- "What are people talking about in [your niche]?"

## Tips for Better Answers

### ✅ Do This
- **Be specific**: "How can I improve the hook?" vs "Is this good?"
- **Reference your post**: "Should I add more data to this post?"
- **Ask one thing at a time**: Focus on one aspect per question
- **Wait for response**: Don't send multiple questions at once

### ❌ Avoid This
- Vague questions: "Is this okay?"
- Multiple questions in one: "How do I improve this and when should I post and what hashtags?"
- Unrelated questions: "What's the weather today?"

## Understanding Responses

### Answer Text
- Main AI-generated response
- Based on your post content and web search
- Typically 2-5 paragraphs

### Sources
- Links to websites used for the answer
- Click to open in new tab
- Verify information if needed

### Timestamp
- Shows when message was sent
- Helps track conversation flow

## Troubleshooting

### "API key not configured"
**Solution**: Contact administrator to configure AI Search API key

### "Failed to get AI response"
**Solution**: 
1. Check internet connection
2. Refresh page and try again
3. Try a different question

### Taking too long (>30 seconds)
**Solution**: This is normal! First response can take up to 30 seconds. Be patient.

### Answer not relevant
**Solution**: Try rephrasing your question to be more specific

## Features

### ✨ What AI Search Can Do
- Answer questions about your post
- Suggest improvements
- Recommend hashtags
- Provide timing advice
- Share industry insights
- Explain best practices

### 🚫 What AI Search Cannot Do
- Edit your post directly (you need to do that)
- Post to LinkedIn for you
- Guarantee viral success
- Predict exact engagement numbers

## Privacy & Security

### Your Data
- Post content is sent to AI Search API for context
- Conversations are not stored permanently
- No personal data is collected

### API Key
- Stored securely in Edge Function
- Never exposed to your browser
- Only accessible by server

## Need More Help?

### Documentation
- **Full Guide**: See `AI_SEARCH_FEATURE.md`
- **Technical Details**: Check Edge Function code

### Support
- **Error Messages**: Read the error message for guidance
- **Logs**: Developers can check Edge Function logs
- **Feedback**: Report issues to development team

---

**Quick Tips**:
- 💡 First response takes 30 seconds - be patient!
- 💡 Ask specific questions for better answers
- 💡 Use suggested questions to get started
- 💡 Check sources for more information
- 💡 Ask follow-up questions to dive deeper

**Status**: ✅ Ready to use after post analysis

---

**Last Updated**: 2026-02-28
